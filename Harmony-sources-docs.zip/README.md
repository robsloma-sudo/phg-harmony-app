# PHG Harmony Core — polished return

This package contains an editable Blender 5.2 LTS core, rendered assets for all 15 style/palette combinations, a complete supporting identity set, and an offline interface review. The original handoff is preserved under `reference/`; its draft settings and pending manifest describe the previous version. Use this README, `CHANGELOG.md`, `SPEC.txt`, and `SPEC.json` for the returned work.

Start with `reference/harmony-theme-preview.html`. It opens locally without a server or external fonts. Choose a style and palette to review the corresponding rendered core, mark, icon, background, and interface. The three app-state stills are explicitly labeled Calm / Midnight references. Actual animation playback is available through the Rendered loop control; the gentle CSS movement of a still is a separate preview convenience.

## Rendered deliverables

| Family | Location | Delivery |
|---|---|---|
| Orb animation | `orb/<style>_<palette>/` and the corresponding `_512/` folder | 120 transparent PNG frames at each size; 1024 native, 512 Blender downsample; 30 fps / 4 seconds |
| Palette beauty stills | `orb/<style>_<palette>_still.png` | 15 independent palette-specific 1024 renders |
| App states | `orb/states/` | Listening, Thinking, Speaking; transparent 1024, Calm / Midnight |
| Brand marks | `mark/mark_<style>_<palette>.png` | 15 transparent 1024 marks |
| App icons | `mark/icons/` | 60 opaque square icons at 1024, 512, 192, and 180 |
| Backgrounds | `backgrounds/` | 15 landscape 2560×1440 and 15 portrait 1290×2796 images |
| Map pins | `pins/` | Primary and secondary 256×256 pins for each palette |
| Review images | `previews/`, `comparisons/`, `palette_check/` | Frame checks, dark/cream/white composites, 128 px check, before/after comparisons |
| Playback review | `loop_check/` | Rendered Midnight videos for the three styles |

Styles are `calm`, `tech`, and `friendly`. Palettes are `midnight`, `aurora`, `ocean`, `ember`, and `ivory`. Frame playback uses `orb_0001.png` through `orb_0120.png`; frame 121 is an audit endpoint and must not be added to playback.

## Beauty and animation presets

The editable beauty master uses EEVEE, 64 render samples, 96 volume samples, and 2 px volume tiles. Delivered beauty stills were rendered independently in each palette with 16 render samples, 32 volume samples, and 4 px tiles. They preserve palette-specific lights, actual volume materials, and the Ivory pigment treatment.

The full animation delivery uses a separate optimized preset: Blender renders each of the three styles at native 1024 with four samples, replaces expensive volumes with three animated procedural atmosphere cards, and grades a temporary RGB token basis into the five palettes in the compositor. Blender also produces every 512 frame. The production export uses four render threads and Blender's GPU compositor through Mesa software / llvmpipe; this environment has no hardware GPU. These loops are rendered, graded derivatives; their colored reflections and light interactions approximate the independently lit beauty scene. The black basis does not encode separate background/panel illumination. Ivory retains independent coverage and a soft shadow so charcoal details remain visible on cream. See `source/harmony_batch_render_NOTES.md` for the exact grade and measured sampling comparison.

All still imagery and PNG sequences were generated with Blender. MP4s are playback encodes of the rendered frames. Review composites use Blender's scene-linear compositor. The source scene retains the seven original conceptual layers and their established names; the realtime preset preserves the original volume objects and can restore their visibility.

## Editable sources and rebuilds

Open `source/harmony_assets.blend` for the complete master: Orb, Mark, Background, and Pins. `source/harmony_animation.blend` opens the lighter atmosphere preset with actual Midnight materials; `source/harmony_supporting.blend` keeps the supporting scenes separately. These files require Blender 5.2 LTS. Scripts use package-relative paths and the original Blender file as a read-only seed. The master also contains its source scripts and this guide in the Text Editor.

```bash
blender --background --python source/harmony_core_build.py -- --mode build
blender --background --python source/harmony_core_build.py -- --mode previews --size 1024
blender --background --python source/harmony_batch_render.py -- --style all --samples 4 --audit-seams
blender --background --python source/harmony_supporting_build.py
blender --background --python source/harmony_review_build.py -- --mode review
blender --background --python source/harmony_spec_export.py
blender --background --python source/harmony_video_build.py -- --styles calm tech friendly
blender --background --python source/harmony_finalize.py
```

The same scripts run with the official Blender `bpy` Python package. Keep experiments in a separate output directory. The batch renderer supports `--output-root`, `--skip-existing`, `--start`, `--end`, and `--palettes`. It never saves the temporary token-basis scene over the beauty master. The core builder saves its selected beauty look; use that command only when intentionally rebuilding the master.

For higher-quality independent palette animation, call `load_seed()`, `apply_look(scene, style, palette)`, and `render(scene, output_path, frame, 1024)` from the core module. Keep those outputs separate from the optimized sequences. Preserve `(frame-1)/120`, integer animation cycles, and frame-121 key endpoints when adding motion. Recheck transparency and 128 px readability after changing the camera, emission, or opacity.

## Validation and performance

The source audit verifies object identities, material links, the palette system, and loop mathematics. The original edge-alpha defect was addressed with a finite atmosphere envelope and a feathered compositor margin. Blender clears invisible RGB before PNG encoding; dithering can leave a one-byte RGB value at zero alpha, which normal RGBA compositing discards. The 24 beauty/state/frame PNGs received a Blender finish with alpha preserved exactly and visible RGB error at most 1/255. The optimized loop's faintest RGB fringe is trimmed below alpha `1/256 − 10⁻⁹`, retaining coverage. `audit/` holds scene records, render timings, sampling comparisons, and endpoint references.

The offline interface was checked in Chromium at 320, 390, 768, and 1440 px across all 15 themes and four screens. Its normal text token contrast is at least 4.68:1 across the four interface surfaces; button text pairs exceed 8.43:1. These measurements apply to the interface tokens, not arbitrary text over artwork.

Rendering ran on an AMD EPYC 9V74 environment with five exposed logical CPUs and software Mesa EEVEE; no hardware GPU was available. During concurrent jobs, native beauty stills took approximately 25–52 seconds. Optimized animation frames produced ten exports each; the final timing report records both concurrent rendering and the faster four-thread export. These measurements do not establish the original ≤6-second GPU production target. Exact device/session timing records are supplied for later GPU benchmarking.

Midnight MP4 reviews play the complete four-second loop twice, for eight seconds at 30 fps. Blender composites their backgrounds; FFmpeg only encodes playback. In the before/after comparisons, the incoming render is on the left and the polished render is on the right.
