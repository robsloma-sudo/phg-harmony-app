import bpy, math, os, random
from mathutils import Vector, Euler, Matrix

ROOT = os.path.join(os.path.expanduser("~"), "Documents", "PHG-Theme-Renders")
BLEND = os.path.join(ROOT, "blend", "harmony_assets.blend")
FRAMES = 120

PALETTES = {
    "midnight": dict(bg="#070B18", panel="#111A33", accent="#D9B25F", accent2="#7F9CFF", line="#24304F", neb="#6A4BD8"),
    "aurora":   dict(bg="#06110F", panel="#0E2220", accent="#3FE0C0", accent2="#A684FF", line="#1F3B38", neb="#1B6F9E"),
    "ocean":    dict(bg="#05101F", panel="#0E2140", accent="#4FB3FF", accent2="#9EE7FF", line="#21406B", neb="#3A4FD8"),
    "ember":    dict(bg="#121012", panel="#221D1F", accent="#FF7A59", accent2="#FFC06B", line="#3A3135", neb="#C2316A"),
    "ivory":    dict(bg="#F6F2EA", panel="#FFFDF8", accent="#2B2A28", accent2="#B0875A", line="#DDD4C4", neb="#D9C3A0"),
}


# ------------------------------------------------------------------ colour
def _lin(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def rgba(h, a=1.0):
    h = h.lstrip("#")
    return (_lin(int(h[0:2], 16)), _lin(int(h[2:4], 16)), _lin(int(h[4:6], 16)), a)


def mix(c1, c2, t):
    return tuple(c1[i] * (1 - t) + c2[i] * t for i in range(3)) + (1.0,)


WHITE = (1.0, 1.0, 1.0, 1.0)


# ------------------------------------------------------------------ node graph helper
class G:
    def __init__(self, mat):
        mat.use_nodes = True
        self.nt = mat.node_tree
        self.nt.nodes.clear()
        self.N, self.L = self.nt.nodes, self.nt.links
        self._t = None

    def n(self, typ, name=None, **props):
        node = self.N.new(typ)
        if name:
            node.name = node.label = name
        for k, v in props.items():
            setattr(node, k, v)
        return node

    def put(self, sock, v):
        if isinstance(v, bpy.types.NodeSocket):
            self.L.new(v, sock)
        elif v is not None:
            sock.default_value = v

    def math(self, op, a, b=None, c=None, clamp=False, name=None):
        node = self.n("ShaderNodeMath", name, operation=op, use_clamp=clamp)
        self.put(node.inputs[0], a)
        self.put(node.inputs[1], b)
        self.put(node.inputs[2], c)
        return node.outputs[0]

    def value(self, v, name=None):
        node = self.n("ShaderNodeValue", name)
        node.outputs[0].default_value = v
        return node.outputs[0]

    def t(self):
        """Loop phase 0..1 over the animation (frame 121 == frame 1)."""
        if self._t is None:
            node = self.n("ShaderNodeValue", "LoopT")
            fc = node.outputs[0].driver_add("default_value")
            fc.driver.type = "SCRIPTED"
            fc.driver.expression = f"(frame-1)/{FRAMES}"
            for m in list(fc.modifiers):
                fc.modifiers.remove(m)
            self._t = node.outputs[0]
        return self._t

    def cos_sin(self, k=1.0):
        ang = self.math("MULTIPLY", self.t(), 2 * math.pi * k)
        return self.math("COSINE", ang), self.math("SINE", ang)

    def maprange(self, v, a, b, c=0.0, d=1.0, smooth=True):
        node = self.n("ShaderNodeMapRange", interpolation_type="SMOOTHSTEP" if smooth else "LINEAR")
        self.put(node.inputs[0], v)
        node.inputs[1].default_value, node.inputs[2].default_value = a, b
        node.inputs[3].default_value, node.inputs[4].default_value = c, d
        return node.outputs[0]

    def mixc(self, fac, a, b):
        node = self.n("ShaderNodeMix", data_type="RGBA")
        self.put(node.inputs[0], fac)
        self.put(node.inputs[6], a)
        self.put(node.inputs[7], b)
        return node.outputs[2]

    def ramp(self, fac, stops, interp="EASE", name=None):
        node = self.n("ShaderNodeValToRGB", name)
        cr = node.color_ramp
        cr.interpolation = interp
        while len(cr.elements) < len(stops):
            cr.elements.new(0.5)
        for el, (p, c) in zip(cr.elements, stops):
            el.position, el.color = p, c
        self.put(node.inputs[0], fac)
        return node.outputs[0]

    def sep(self, vec):
        node = self.n("ShaderNodeSeparateXYZ")
        self.put(node.inputs[0], vec)
        return node.outputs

    def vmath(self, op, a, b=None, sc=None):
        node = self.n("ShaderNodeVectorMath", operation=op)
        self.put(node.inputs[0], a)
        if b is not None:
            self.put(node.inputs[1], b)
        if sc is not None:
            self.put(node.inputs[3], sc)
        return node.outputs[1] if op in ("LENGTH", "DOT_PRODUCT", "DISTANCE") else node.outputs[0]

    def texco(self, out="Object"):
        return self.n("ShaderNodeTexCoord").outputs[out]

    def worldpos(self):
        return self.n("ShaderNodeNewGeometry").outputs["Position"]

    def uv(self):
        return self.sep(self.n("ShaderNodeUVMap").outputs["UV"])

    def noise4d(self, vec, w, scale, detail=4.0, rough=0.55, distortion=0.0):
        node = self.n("ShaderNodeTexNoise", noise_dimensions="4D")
        self.put(node.inputs["Vector"], vec)
        self.put(node.inputs["W"], w)
        node.inputs["Scale"].default_value = scale
        node.inputs["Detail"].default_value = detail
        node.inputs["Roughness"].default_value = rough
        node.inputs["Distortion"].default_value = distortion
        return node.outputs["Fac"], node.outputs["Color"]

    def looped_noise(self, vec, scale, radius=0.6, **kw):
        """Noise that churns and returns to its start: circle through (depth, W)."""
        c, s = self.cos_sin(1)
        off = self.n("ShaderNodeCombineXYZ")
        self.put(off.inputs[1], self.math("MULTIPLY", s, radius / scale))
        p = self.vmath("ADD", vec, off.outputs[0])
        return self.noise4d(p, self.math("MULTIPLY", c, radius), scale, **kw)

    def emission(self, color, strength):
        node = self.n("ShaderNodeEmission")
        self.put(node.inputs["Color"], color)
        self.put(node.inputs["Strength"], strength)
        return node.outputs[0]

    def additive(self, color, strength):
        tr = self.n("ShaderNodeBsdfTransparent")
        add = self.n("ShaderNodeAddShader")
        self.L.new(tr.outputs[0], add.inputs[0])
        self.L.new(self.emission(color, strength), add.inputs[1])
        return add.outputs[0]

    def out(self, surface=None, volume=None):
        o = self.n("ShaderNodeOutputMaterial")
        if surface is not None:
            self.L.new(surface, o.inputs["Surface"])
        if volume is not None:
            self.L.new(volume, o.inputs["Volume"])


def new_mat(name, method="BLENDED"):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.surface_render_method = method
    m.use_backface_culling = False
    return m


# ------------------------------------------------------------------ mesh helpers
def mesh_obj(scene, name, verts, faces, uvs=None, parent=None, smooth=True):
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.update()
    if smooth:
        me.shade_smooth()
    if uvs is not None:
        uvl = me.uv_layers.new(name="UVMap")
        flat = [0.0] * (len(me.loops) * 2)
        vi = [0] * len(me.loops)
        me.loops.foreach_get("vertex_index", vi)
        for li, v in enumerate(vi):
            flat[2 * li], flat[2 * li + 1] = uvs[v]
        uvl.data.foreach_set("uv", flat)
    ob = bpy.data.objects.new(name, me)
    scene.collection.objects.link(ob)
    if parent:
        ob.parent = parent
    return ob


def ico_template(subdiv=2):
    import bmesh
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=subdiv, radius=1.0)
    v = [tuple(x.co) for x in bm.verts]
    f = [tuple(x.index for x in face.verts) for face in bm.faces]
    bm.free()
    return v, f


def uv_sphere(name, scene, radius, seg=64, rings=32, parent=None):
    import bmesh
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=seg, v_segments=rings, radius=radius)
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    me.shade_smooth()
    ob = bpy.data.objects.new(name, me)
    scene.collection.objects.link(ob)
    if parent:
        ob.parent = parent
    return ob


def torus(name, scene, R, r, seg=384, minor=10, parent=None):
    verts, faces = [], []
    for i in range(seg):
        a = 2 * math.pi * i / seg
        ca, sa = math.cos(a), math.sin(a)
        for j in range(minor):
            b = 2 * math.pi * j / minor
            rr = R + r * math.cos(b)
            verts.append((rr * ca, rr * sa, r * math.sin(b)))
    for i in range(seg):
        for j in range(minor):
            i2, j2 = (i + 1) % seg, (j + 1) % minor
            faces.append((i * minor + j, i2 * minor + j, i2 * minor + j2, i * minor + j2))
    return mesh_obj(scene, name, verts, faces, parent=parent)


def empty(scene, name, parent=None, loc=(0, 0, 0), rot=(0, 0, 0)):
    e = bpy.data.objects.new(name, None)
    e.empty_display_size = 0.4
    e.location, e.rotation_euler = loc, rot
    scene.collection.objects.link(e)
    if parent:
        e.parent = parent
    return e


def fcurves_of(obj):
    ad = obj.animation_data
    try:
        return list(ad.action.fcurves)
    except Exception:
        from bpy_extras import anim_utils
        return list(anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot).fcurves)


def key_linear(obj, path, index, start, end):
    setattr_v = getattr(obj, path)
    setattr_v[index] = start
    obj.keyframe_insert(path, index=index, frame=1)
    setattr_v[index] = end
    obj.keyframe_insert(path, index=index, frame=FRAMES + 1)
    for fc in fcurves_of(obj):
        for kp in fc.keyframe_points:
            kp.interpolation = "LINEAR"
    setattr_v[index] = start


def key_breathe(obj, amount=0.05):
    for f, s in ((1, 1.0), (FRAMES // 2 + 1, 1.0 + amount), (FRAMES + 1, 1.0)):
        obj.scale = (s, s, s)
        obj.keyframe_insert("scale", frame=f)
    for fc in fcurves_of(obj):
        for kp in fc.keyframe_points:
            kp.interpolation = "BEZIER"
            kp.handle_left_type = kp.handle_right_type = "AUTO_CLAMPED"
        fc.update()
    obj.scale = (1, 1, 1)


def no_shadow(ob):
    ob.visible_shadow = False
    return ob


# ------------------------------------------------------------------ materials
def mat_shell(pal, emis=1.0):
    acc, acc2, bg = rgba(pal["accent"]), rgba(pal["accent2"]), rgba(pal["bg"])
    m = new_mat("M_Shell", "DITHERED")
    g = G(m)
    d = Vector((-0.5, -0.55, 0.68)).normalized()
    nrm = g.vmath("NORMALIZE", g.texco("Object"))
    t = g.math("MULTIPLY_ADD", g.vmath("DOT_PRODUCT", nrm, d), 0.5, 0.5)
    col = g.ramp(t, [(0.22, mix(acc, bg, 0.6)), (0.6, acc), (0.9, acc2), (1.0, mix(acc2, WHITE, 0.35))], name="Ramp")
    lw = g.n("ShaderNodeLayerWeight"); lw.inputs["Blend"].default_value = 0.4
    facing = lw.outputs["Facing"]
    # swirling energy veins on the shell surface
    nf, _ = g.looped_noise(g.texco("Object"), 3.2, radius=0.9, detail=6, rough=0.6, distortion=1.2)
    veins = g.maprange(g.math("ABSOLUTE", g.math("SUBTRACT", nf, 0.5)), 0.0, 0.035, 1.0, 0.0)
    bs = g.n("ShaderNodeBsdfPrincipled", "BSDF")
    bs.inputs["Roughness"].default_value = 0.15
    bs.inputs["Coat Weight"].default_value = 0.8
    bs.inputs["Coat Roughness"].default_value = 0.05
    g.put(bs.inputs["Base Color"], col)
    g.put(bs.inputs["Emission Color"], col)
    g.put(bs.inputs["Emission Strength"], g.math("MULTIPLY_ADD", veins, 2.2 * emis, 0.45 * emis, name="ShellEmit"))
    rim = g.emission(acc2, g.math("MULTIPLY", g.math("POWER", facing, 2.2), 2.0 * emis, name="RimStrength"))
    add = g.n("ShaderNodeAddShader")
    g.L.new(bs.outputs[0], add.inputs[0]); g.L.new(rim, add.inputs[1])
    alpha = g.math("MULTIPLY_ADD", g.math("POWER", facing, 1.4), 0.45, 0.5, name="ShellAlpha")
    mx = g.n("ShaderNodeMixShader")
    g.put(mx.inputs[0], alpha)
    g.L.new(g.n("ShaderNodeBsdfTransparent").outputs[0], mx.inputs[1])
    g.L.new(add.outputs[0], mx.inputs[2])
    g.out(surface=mx.outputs[0])
    return m


def mat_plasma(pal, emis=1.0):
    acc, acc2 = rgba(pal["accent"]), rgba(pal["accent2"])
    m = new_mat("M_Plasma")
    g = G(m)
    p = g.texco("Object")
    r = g.vmath("LENGTH", p)
    nf, _ = g.looped_noise(p, 2.4, radius=0.8, detail=5, rough=0.6, distortion=1.5)
    dens = g.math("MULTIPLY", g.maprange(nf, 0.45, 0.72), g.maprange(r, 0.95, 0.35))
    col = g.ramp(nf, [(0.4, acc2), (0.6, mix(acc, WHITE, 0.15)), (0.75, acc)])
    vol = g.n("ShaderNodeVolumePrincipled")
    g.put(vol.inputs["Density"], g.math("MULTIPLY", dens, 3.0))
    g.put(vol.inputs["Color"], acc2)
    g.put(vol.inputs["Emission Color"], col)
    g.put(vol.inputs["Emission Strength"], g.math("MULTIPLY", dens, 6.0 * emis, name="PlasmaEmit"))
    g.out(volume=vol.outputs[0])
    return m


def mat_nebula(pal, emis=1.0):
    acc, acc2, neb = rgba(pal["accent"]), rgba(pal["accent2"]), rgba(pal["neb"])
    m = new_mat("M_Nebula")
    g = G(m)
    p = g.worldpos()
    # ellipsoidal falloff, a bit wider than tall
    sp = g.vmath("MULTIPLY", p, (0.8, 0.9, 1.15))
    r = g.vmath("LENGTH", sp)
    mask = g.math("MULTIPLY", g.maprange(r, 3.3, 1.5), g.maprange(r, 0.95, 1.35))
    nf, _ = g.looped_noise(p, 0.55, radius=0.35, detail=7, rough=0.62, distortion=1.1)
    wisps = g.math("POWER", g.maprange(nf, 0.46, 0.78, smooth=False), 1.6)
    dens = g.math("MULTIPLY", wisps, mask)
    cf, _ = g.looped_noise(p, 0.9, radius=0.25, detail=3, rough=0.5)
    col = g.ramp(cf, [(0.3, neb), (0.5, acc2), (0.66, mix(acc2, WHITE, 0.2)), (0.78, acc)], name="NebRamp")
    vol = g.n("ShaderNodeVolumePrincipled")
    g.put(vol.inputs["Density"], g.math("MULTIPLY", dens, 0.9, name="NebDensity"))
    g.put(vol.inputs["Color"], col)
    g.put(vol.inputs["Anisotropy"], 0.35)
    g.put(vol.inputs["Emission Color"], col)
    g.put(vol.inputs["Emission Strength"], g.math("MULTIPLY", dens, 1.1 * emis, name="NebEmit"))
    g.out(volume=vol.outputs[0])
    return m


def mat_synapse(pal, emis=1.0, pulses_per_unit=0.55, cycles=2):
    acc, acc2 = rgba(pal["accent"]), rgba(pal["accent2"])
    m = new_mat("M_Synapse")
    g = G(m)
    u, v, _ = g.uv()
    x = g.math("FRACT", g.math("ADD", g.math("SUBTRACT", g.math("MULTIPLY", u, pulses_per_unit), g.math("MULTIPLY", g.t(), cycles)), v))
    pulse = g.math("POWER", g.maprange(x, 0.8, 1.0, smooth=False), 3.0)
    r = g.vmath("LENGTH", g.worldpos())
    fade = g.maprange(r, 3.4, 1.4)
    col = g.mixc(pulse, acc2, mix(acc, WHITE, 0.35))
    strength = g.math("MULTIPLY", g.math("MULTIPLY_ADD", pulse, 5.0, 0.45), g.math("MULTIPLY", fade, emis), name="SynStrength")
    g.out(surface=g.additive(col, strength))
    return m


def mat_trail(name, color, n, a0, direction, emis=1.0, dashes=0, tail=0.32):
    """Faint orbit + bright comet tail behind each of n evenly spaced electrons."""
    m = new_mat(name)
    g = G(m)
    grad = g.n("ShaderNodeTexGradient", gradient_type="RADIAL")
    g.put(grad.inputs[0], g.texco("Object"))
    a = grad.outputs["Fac"]
    ae = a0 / 360.0 + 0.5
    diff = g.math("SUBTRACT", ae, a) if direction > 0 else g.math("SUBTRACT", a, ae)
    x = g.math("FRACT", g.math("MULTIPLY", diff, n))
    tl = g.math("POWER", g.maprange(x, 0.0, tail, 1.0, 0.0, smooth=False), 2.2)
    base = 0.22
    if dashes:
        dm = g.math("LESS_THAN", g.math("FRACT", g.math("MULTIPLY", a, dashes)), 0.55)
        base = g.math("MULTIPLY", dm, 0.3)
    strength = g.math("MULTIPLY", g.math("MULTIPLY_ADD", tl, 3.2, base), emis, name="TrailStrength")
    g.out(surface=g.additive(g.mixc(g.math("MULTIPLY", tl, 0.35), color, WHITE), strength))
    return m


def mat_glow(name, color, strength):
    m = new_mat(name)
    g = G(m)
    g.out(surface=g.additive(color, g.value(strength, "Strength")))
    return m


def mat_stars(pal, emis=1.0):
    acc, acc2 = rgba(pal["accent"]), rgba(pal["accent2"])
    m = new_mat("M_Stars")
    g = G(m)
    u, v, _ = g.uv()
    ang = g.math("MULTIPLY", g.math("ADD", g.math("MULTIPLY", g.t(), 3), v), 2 * math.pi)
    tw = g.math("MULTIPLY_ADD", g.math("SINE", ang), 0.5, 0.5)
    tw = g.math("POWER", tw, 3.0)
    col = g.ramp(u, [(0.0, mix(acc2, WHITE, 0.5)), (0.55, WHITE), (0.85, mix(acc, WHITE, 0.3)), (1.0, acc)], interp="CONSTANT")
    r = g.vmath("LENGTH", g.worldpos())
    fade = g.maprange(r, 3.5, 2.2)
    strength = g.math("MULTIPLY", g.math("MULTIPLY_ADD", tw, 3.0, 0.35), g.math("MULTIPLY", fade, emis), name="StarStrength")
    g.out(surface=g.additive(col, strength))
    return m


# ------------------------------------------------------------------ geometry generators
def rnd_unit(rng):
    while True:
        v = Vector((rng.uniform(-1, 1), rng.uniform(-1, 1), rng.uniform(-1, 1)))
        if 0.01 < v.length <= 1:
            return v.normalized()


def grow_dendrites(seed=7, roots=26):
    rng = random.Random(seed)
    strands = []

    def grow(p, d, length, radius, depth, u0, sv):
        pts, rad, us = [p.copy()], [radius], [u0]
        turn = Vector((0, 0, 0))
        step = 0.04
        n = max(4, int(length / step))
        for i in range(n):
            turn = turn * 0.75 + rnd_unit(rng) * 0.28
            d = (d + turn * 0.45 + p.normalized() * 0.07).normalized()
            p = p + d * step
            f = (i + 1) / n
            pts.append(p.copy())
            rad.append(max(0.0016, radius * (1 - 0.88 * f)))
            us.append(us[-1] + step)
            if depth < 2 and 3 < i < n - 5 and rng.random() < (0.07 if depth == 0 else 0.05):
                nd = (d + rnd_unit(rng) * 1.0).normalized()
                grow(p.copy(), nd, length * rng.uniform(0.3, 0.6) * (1 - 0.5 * f), rad[-1] * 0.8, depth + 1, us[-1], rng.random())
        strands.append((pts, rad, us, sv, depth))

    golden = math.pi * (3 - math.sqrt(5))
    for k in range(roots):
        z = 1 - 2 * (k + 0.5) / roots
        rr = math.sqrt(1 - z * z)
        th = golden * k + rng.uniform(-0.3, 0.3)
        n = Vector((rr * math.cos(th), rr * math.sin(th), z)).normalized()
        grow(n * 0.96, (n + rnd_unit(rng) * 0.4).normalized(), rng.uniform(1.4, 2.4), rng.uniform(0.011, 0.016), 0, 0.0, rng.random())
    return strands


def build_dendrite_mesh(scene, strands, sides=6, parent=None):
    verts, faces, uvs = [], [], []
    iv, if_ = ico_template(1)
    for pts, rad, us, sv, depth in strands:
        if len(pts) < 2:
            continue
        tans = []
        for i in range(len(pts)):
            a = pts[max(i - 1, 0)]
            b = pts[min(i + 1, len(pts) - 1)]
            tans.append((b - a).normalized())
        nrm = tans[0].orthogonal().normalized()
        base = len(verts)
        for i, p in enumerate(pts):
            t = tans[i]
            nrm = (nrm - t * nrm.dot(t)).normalized()
            bn = t.cross(nrm)
            for s in range(sides):
                ph = 2 * math.pi * s / sides
                verts.append(tuple(p + (nrm * math.cos(ph) + bn * math.sin(ph)) * rad[i]))
                uvs.append((us[i], sv))
        for i in range(len(pts) - 1):
            for s in range(sides):
                s2 = (s + 1) % sides
                a, b = base + i * sides + s, base + i * sides + s2
                faces.append((a, b, b + sides, a + sides))
        # synaptic bulb at the tip, shares the tip's pulse coordinate
        tip, br = pts[-1], (0.022 if depth == 0 else 0.015)
        b0 = len(verts)
        for v in iv:
            verts.append(tuple(tip + Vector(v) * br))
            uvs.append((us[-1], sv))
        faces.extend(tuple(b0 + i for i in f) for f in if_)
    return mesh_obj(scene, "Synapses", verts, faces, uvs, parent=parent)


def build_stars(scene, n=650, seed=3, parent=None):
    rng = random.Random(seed)
    iv, if_ = ico_template(1)
    verts, faces, uvs = [], [], []
    for _ in range(n):
        r = rng.uniform(1.15, 3.5) ** 1.0
        p = rnd_unit(rng) * r
        p.x *= 1.15
        s = 0.004 + 0.016 * rng.random() ** 4
        b0 = len(verts)
        col, ph = rng.random(), rng.random()
        for v in iv:
            verts.append(tuple(p + Vector(v) * s))
            uvs.append((col, ph))
        faces.extend(tuple(b0 + i for i in f) for f in if_)
    return mesh_obj(scene, "StarDust", verts, faces, uvs, parent=parent)


def build_nucleus(scene, pal, parent, emis=1.0):
    acc, acc2 = rgba(pal["accent"]), rgba(pal["accent2"])
    mp = mat_glow("M_Proton", mix(acc, WHITE, 0.1), 2.4 * emis)
    mn = mat_glow("M_Neutron", mix(acc2, WHITE, 0.1), 2.0 * emis)
    phi = (1 + math.sqrt(5)) / 2
    pts = [(0, 0, 0)]
    for a in (-1, 1):
        for b in (-phi, phi):
            pts += [(0, a, b), (a, b, 0), (b, 0, a)]
    nuc = empty(scene, "Nucleus", parent=parent, rot=(0.4, 0.2, 0))
    for i, p in enumerate(pts):
        v = Vector(p)
        if v.length:
            v = v.normalized() * 0.2
        o = uv_sphere(f"Nucleon{i:02d}", scene, 0.13, 24, 12, parent=nuc)
        o.location = v
        o.data.materials.append(mp if i % 2 == 0 else mn)
        no_shadow(o)
    key_linear(nuc, "rotation_euler", 2, 0, 2 * math.pi)
    return nuc


# ------------------------------------------------------------------ render / compositor
def setup_render(scene, w, h, transparent, frames=None, samples=64):
    r = scene.render
    r.engine = "BLENDER_EEVEE"
    e = scene.eevee
    e.taa_render_samples = samples
    e.volumetric_tile_size = "2"
    e.volumetric_samples = 96
    e.volumetric_sample_distribution = 0.8
    e.use_volumetric_shadows = True
    e.volumetric_start, e.volumetric_end = 13.0, 27.0
    r.resolution_x, r.resolution_y, r.resolution_percentage = w, h, 100
    r.fps = 30
    if frames:
        scene.frame_start, scene.frame_end = frames
    r.film_transparent = transparent
    im = r.image_settings
    im.file_format = "PNG"
    im.color_mode = "RGBA" if transparent else "RGB"
    im.color_depth = "8"
    im.compression = 15
    vs = scene.view_settings
    vs.view_transform, vs.look, vs.exposure, vs.gamma = "Standard", "None", 0, 1


def setup_bloom(scene, strength=1.0, threshold=0.7, size=0.7):
    """Bloom on top of the render; any additive light is also written into alpha
    (alpha = max(alpha, brightest channel)) so glows survive in transparent PNGs."""
    name = scene.name + " Comp"
    old = bpy.data.node_groups.get(name)
    if old:
        bpy.data.node_groups.remove(old)
    ng = bpy.data.node_groups.new(name, "CompositorNodeTree")
    scene.compositing_node_group = ng
    ng.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
    N, L = ng.nodes, ng.links
    rl = N.new("CompositorNodeRLayers"); rl.scene = scene
    gl = N.new("CompositorNodeGlare"); gl.name = "Bloom"
    gl.inputs["Type"].default_value = "Bloom"
    gl.inputs["Quality"].default_value = "High"
    gl.inputs["Threshold"].default_value = threshold
    gl.inputs["Strength"].default_value = strength
    gl.inputs["Size"].default_value = size
    L.new(rl.outputs["Image"], gl.inputs["Image"])
    s1 = N.new("CompositorNodeSeparateColor"); L.new(rl.outputs["Image"], s1.inputs[0])
    s2 = N.new("CompositorNodeSeparateColor"); L.new(gl.outputs["Glare"], s2.inputs[0])

    def M(op, a, b):
        n = N.new("ShaderNodeMath"); n.operation = op
        for sock, v in ((n.inputs[0], a), (n.inputs[1], b)):
            if isinstance(v, (int, float)):
                sock.default_value = v
            else:
                L.new(v, sock)
        return n.outputs[0]

    cc = N.new("CompositorNodeCombineColor")
    ch = []
    for c in ("Red", "Green", "Blue"):
        s = M("ADD", s1.outputs[c], s2.outputs[c])
        ch.append(s)
        L.new(s, cc.inputs[c])
    bright = M("MINIMUM", M("MAXIMUM", M("MAXIMUM", ch[0], ch[1]), ch[2]), 1.0)
    L.new(M("MAXIMUM", s1.outputs["Alpha"], bright), cc.inputs["Alpha"])
    go = N.new("NodeGroupOutput")
    L.new(cc.outputs["Image"], go.inputs[0])
    return ng


# ------------------------------------------------------------------ the scene
def look_at(obj, target=(0, 0, 0)):
    obj.rotation_euler = (Vector(target) - obj.location).to_track_quat("-Z", "Y").to_euler()


def clear_scene(scene):
    for o in list(scene.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for coll in (bpy.data.meshes, bpy.data.cameras, bpy.data.lights, bpy.data.materials):
        for d in list(coll):
            if d.users == 0:
                coll.remove(d)


def build_core(scene, palette="midnight", emis=1.0, ring_mul=1.0, dot_mul=1.0, spinA=360):
    pal = PALETTES[palette]
    acc, acc2, neb = rgba(pal["accent"]), rgba(pal["accent2"]), rgba(pal["neb"])

    cd = bpy.data.cameras.new("OrbCam"); cd.type = "ORTHO"; cd.ortho_scale = 7.2; cd.clip_end = 100
    cam = bpy.data.objects.new("OrbCam", cd); scene.collection.objects.link(cam)
    t8 = math.radians(8)
    cam.location = (0, -20 * math.cos(t8), 20 * math.sin(t8))
    cam.rotation_euler = (math.radians(82), 0, 0)
    scene.camera = cam

    w = bpy.data.worlds.get("OrbWorld") or bpy.data.worlds.new("OrbWorld")
    w.use_nodes = True
    w.node_tree.nodes["Background"].inputs["Color"].default_value = rgba(pal["panel"])
    w.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.35
    scene.world = w

    def light(name, kind, loc, energy, color, size=1.0):
        ld = bpy.data.lights.new(name, kind)
        ld.energy, ld.color = energy, color[:3]
        if kind == "AREA":
            ld.shape, ld.size = "DISK", size
        else:
            ld.shadow_soft_size = size
        ob = bpy.data.objects.new(name, ld); scene.collection.objects.link(ob)
        ob.location = loc
        look_at(ob)
        return ob

    light("KeyLight", "AREA", (-5, -5, 6), 120, (1.0, 0.93, 0.84), 3)
    light("RimLight", "AREA", (2.5, 6, 3), 150, acc2, 4)
    light("CoreLight", "POINT", (0, 0, 0), 900 * emis, mix(acc, WHITE, 0.5), 0.3)

    core = empty(scene, "Core")
    key_breathe(core, 0.05)
    shell = uv_sphere("Shell", scene, 1.0, 96, 48, parent=core)
    shell.data.materials.append(mat_shell(pal, emis)); no_shadow(shell)
    plasma = uv_sphere("Plasma", scene, 0.94, 32, 16, parent=core)
    plasma.data.materials.append(mat_plasma(pal, emis)); no_shadow(plasma)
    build_nucleus(scene, pal, core, emis)

    syn = build_dendrite_mesh(scene, grow_dendrites())
    syn.data.materials.append(mat_synapse(pal, emis)); no_shadow(syn)

    stars = build_stars(scene)
    stars.data.materials.append(mat_stars(pal, emis)); no_shadow(stars)

    dom = bpy.data.objects.new("Nebula", bpy.data.meshes.new("Nebula"))
    import bmesh
    bm = bmesh.new(); bmesh.ops.create_cube(bm, size=8.0); bm.to_mesh(dom.data); bm.free()
    scene.collection.objects.link(dom)
    dom.data.materials.append(mat_nebula(pal, emis)); no_shadow(dom)

    # electron orbits, atom style
    orbits = [
        # name, radius, thickness, roll, colour, electrons at, dot radius, spin degrees, dashes
        ("A", 2.30, 0.008, -15, acc,  [0, 90, 180, 270], 0.045, spinA, 0),
        ("B", 1.75, 0.007, 45,  acc2, [45, 225],        0.040, -360, 64),
        ("C", 2.70, 0.006, 105, mix(acc, acc2, 0.35), [20, 140, 260], 0.035, 120, 0),
    ]
    for nm, R, th, roll, col, angs, dr, deg, dashes in orbits:
        tilt = empty(scene, f"Orbit{nm}", rot=(math.radians(14), math.radians(roll), 0))
        spin = empty(scene, f"Spin{nm}", parent=tilt)
        ring = torus(f"Ring{nm}", scene, R, th * ring_mul, parent=spin)
        ring.data.materials.append(mat_trail(f"M_Trail{nm}", col, len(angs), angs[0], 1 if deg > 0 else -1, emis, dashes))
        no_shadow(ring)
        dm = mat_glow(f"M_Electron{nm}", mix(col, WHITE, 0.25), 3.0 * emis)
        for k, a in enumerate(angs):
            ar = math.radians(a)
            d = uv_sphere(f"Electron{nm}{k}", scene, dr * dot_mul, 24, 12, parent=spin)
            d.location = (R * math.cos(ar), R * math.sin(ar), 0)
            d.data.materials.append(dm); no_shadow(d)
        key_linear(spin, "rotation_euler", 2, 0, math.radians(deg))
    return core


def preview_over(src, dst, bg_hex):
    import numpy as np
    img = bpy.data.images.load(src, check_existing=False)
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    px = px.reshape(-1, 4)
    h_ = bg_hex.lstrip("#")
    bg = np.array([int(h_[i:i + 2], 16) / 255 for i in (0, 2, 4)], dtype=np.float32)
    a = px[:, 3:4]
    px[:, :3] = px[:, :3] * a + bg * (1 - a)
    px[:, 3] = 1
    out = bpy.data.images.new("preview_tmp", w, h, alpha=True)
    out.pixels.foreach_set(px.ravel())
    out.filepath_raw = dst
    out.file_format = "PNG"
    out.save()
    bpy.data.images.remove(out)
    bpy.data.images.remove(img)


def render_preview(scene, frames, tag, bg_hex):
    import time
    outdir = r"C:\Users\robsl\AppData\Local\Temp\harmony_prev"
    os.makedirs(outdir, exist_ok=True)
    times = {}
    for f in frames:
        scene.frame_set(f)
        p = os.path.join(outdir, f"{tag}_f{f}.png")
        scene.render.filepath = p
        t = time.time()
        bpy.ops.render.render(write_still=True, scene=scene.name)
        times[f] = round(time.time() - t, 1)
        preview_over(p, os.path.join(outdir, f"{tag}_f{f}_onbg.png"), bg_hex)
    return times
