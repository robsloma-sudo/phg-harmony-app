"""Harmony Core • Blender-native palette-multiplex animation export.

The polished geometry is rendered once per frame and style at native 1024px.
A linear RGB token basis is then graded into each palette inside Blender's
compositor. These are optimized graded loops, not five independent PBR beauty
renders. Direct palette beauty stills and the editable beauty scene remain the
reference for palette-specific lighting, volumes, and the ivory shadow.

Examples (Blender 5.2 LTS bpy Python or Blender --background --python):
    python harmony_batch_render.py --style calm --start 1 --end 120 --samples 8
    python harmony_batch_render.py --style all --audit-seams
    python harmony_batch_render.py --style calm --start 1 --end 3 \
        --output-root ./harmony-batch-proof

The renderer never overwrites harmony_assets.blend and never saves a basis
scene. All delivered PNG pixels, including grading and 512px downsampling, are
produced by Blender. Temporary ordinary animation output is removed on exit.
"""
import os
import tempfile
from pathlib import Path
os.environ.setdefault('MESA_SHADER_CACHE_DIR', str(Path(tempfile.gettempdir()) / 'harmony-mesa-cache'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(tempfile.gettempdir()) / 'harmony-cache'))
os.environ.setdefault('LP_NUM_THREADS', os.environ.get('HARMONY_RENDER_THREADS', '4'))

import argparse
import datetime
import json
import shutil
import struct
import sys
import time

import bpy

SOURCE = Path(__file__).resolve().parent
sys.path.insert(0, str(SOURCE))
import harmony_core_build as C
import harmony_realtime as RT

ROOT = SOURCE.parent
COMPOSITOR_DEVICE = os.environ.get('HARMONY_COMPOSITOR_DEVICE', 'GPU').upper()
if COMPOSITOR_DEVICE not in ('GPU', 'CPU'):
    raise ValueError('HARMONY_COMPOSITOR_DEVICE must be GPU or CPU.')
ALPHA_CLEANUP_THRESHOLD = 1 / 256 - 1e-9
RENDER_THREADS = int(os.environ.get('HARMONY_RENDER_THREADS', '4'))
if RENDER_THREADS < 1:
    raise ValueError('HARMONY_RENDER_THREADS must be a positive integer.')
BASIS_NAME = '_animation_token_basis'
BASIS = dict(bg='#000000', panel='#000000', line='#000000',
             accent='#FF0000', accent2='#0000FF', neb='#00FF00')
TARGET_PALETTES = tuple(name for name in C.PALETTES if not name.startswith('_'))


def _math(group, operation, a, b=0, name=None):
    n = group.nodes.new('ShaderNodeMath')
    n.operation = operation
    if name:
        n.name = n.label = name
    for socket, value in ((n.inputs[0], a), (n.inputs[1], b)):
        if isinstance(value, (int, float)):
            socket.default_value = value
        else:
            group.links.new(value, socket)
    return n.outputs[0]


def _file_output(group, image, directory, name):
    node = group.nodes.new('CompositorNodeOutputFile')
    node.name = node.label = name
    # Blender 5.2 separates media_type from file_format. Without IMAGE, the
    # default is MULTI_LAYER_IMAGE and only multilayer EXR is accepted.
    node.format.media_type = 'IMAGE'
    node.format.file_format = 'PNG'
    node.format.color_mode = 'RGBA'
    node.format.color_depth = '8'
    node.format.compression = 80
    node.save_as_render = True
    node.use_file_extension = True
    node.directory = str(directory)
    node.file_name = 'orb_'
    # A blank item name avoids a suffix being appended to the exported name.
    item = node.file_output_items.new('RGBA', '')
    item.save_as_render = True
    group.links.new(image, node.inputs[0])
    return node


def _gray_image(group, value, name):
    node = group.nodes.new('CompositorNodeCombineColor')
    node.name = node.label = name
    for channel in ('Red', 'Green', 'Blue'):
        group.links.new(value, node.inputs[channel])
    node.inputs['Alpha'].default_value = 1
    return node.outputs['Image']


def _color_math(group, operation, a, b, name):
    node = group.nodes.new('ShaderNodeMix')
    node.name = node.label = name
    node.data_type = 'RGBA'
    node.blend_type = operation
    node.clamp_factor = False
    node.clamp_result = False
    node.inputs[0].default_value = 1
    for socket, value in ((node.inputs[6], a), (node.inputs[7], b)):
        if isinstance(value, (tuple, list)):
            socket.default_value = value
        else:
            group.links.new(value, socket)
    return node.outputs[2]


def _ivory_shadow(group, foreground, tokens):
    """Finite soft charcoal coverage under the ivory orb, in premultiplied RGBA."""
    ellipse = group.nodes.new('CompositorNodeEllipseMask')
    ellipse.name = ellipse.label = 'Ivory • finite soft shadow'
    ellipse.inputs['Position'].default_value = (.50, .48)
    ellipse.inputs['Size'].default_value = (.32, .32)
    blur = group.nodes.new('CompositorNodeBlur')
    blur.inputs['Type'].default_value = 'Gaussian'
    blur.inputs['Size'].default_value = (20, 20)
    group.links.new(ellipse.outputs[0], blur.inputs['Image'])
    alpha = _math(group, 'MULTIPLY', blur.outputs[0], .10)
    shadow = group.nodes.new('CompositorNodeCombineColor')
    charcoal = C.rgba(tokens['accent'])
    for i, channel in enumerate(('Red', 'Green', 'Blue')):
        group.links.new(_math(group, 'MULTIPLY', alpha, charcoal[i]),
                        shadow.inputs[channel])
    group.links.new(alpha, shadow.inputs['Alpha'])
    over = group.nodes.new('CompositorNodeAlphaOver')
    over.name = over.label = 'Ivory shadow beneath graded loop'
    over.inputs['Straight Alpha'].default_value = False
    group.links.new(shadow.outputs['Image'], over.inputs['Background'])
    group.links.new(foreground, over.inputs['Foreground'])
    return over.outputs['Image']


def _clean_transparent_rgb(group, image, name):
    """Zero RGB that will quantize to transparent in the delivered 8-bit PNG."""
    sep = group.nodes.new('CompositorNodeSeparateColor')
    group.links.new(image, sep.inputs[0])
    # Trim sub-byte coverage in this optimized export. Some alpha-one fringe
    # pixels retain coverage but have RGB zeroed; their appearance change is
    # bounded by 1/255 opacity. Color dithering may subsequently add 1/255 RGB
    # residue, which carries no visible color at zero alpha.
    visible = _math(group, 'GREATER_THAN', sep.outputs['Alpha'], ALPHA_CLEANUP_THRESHOLD,
                    name + ' • visible alpha quantum')
    combine = group.nodes.new('CompositorNodeCombineColor')
    combine.name = combine.label = name + ' • clean transparent pixels'
    for channel in ('Red', 'Green', 'Blue'):
        group.links.new(_math(group, 'MULTIPLY', sep.outputs[channel], visible),
                        combine.inputs[channel])
    group.links.new(sep.outputs['Alpha'], combine.inputs['Alpha'])
    return combine.outputs['Image']


def add_palette_outputs(scene, style, palettes, output_root):
    """Append palette grades to the existing safe-margin bloom compositor."""
    group = scene.compositing_node_group
    nodes, links = group.nodes, group.links
    output = next(n for n in nodes if n.type == 'GROUP_OUTPUT')
    source = output.inputs[0].links[0].from_socket
    rl = next(n for n in nodes if n.type == 'R_LAYERS')

    sep = nodes.new('CompositorNodeSeparateColor')
    sep.name = sep.label = 'Token basis • linear RGB'
    links.new(source, sep.inputs[0])
    raw = nodes.new('CompositorNodeSeparateColor')
    raw.name = raw.label = 'Unbloomed coverage'
    links.new(rl.outputs['Image'], raw.inputs[0])

    common = _math(group, 'MINIMUM',
                   _math(group, 'MINIMUM', sep.outputs['Red'],
                         sep.outputs['Green']), sep.outputs['Blue'],
                   'Shared white reflection component')
    token_sources = {
        'accent': _math(group, 'MAXIMUM',
                        _math(group, 'SUBTRACT', sep.outputs['Red'], common), 0),
        'neb': _math(group, 'MAXIMUM',
                     _math(group, 'SUBTRACT', sep.outputs['Green'], common), 0),
        'accent2': _math(group, 'MAXIMUM',
                         _math(group, 'SUBTRACT', sep.outputs['Blue'], common), 0),
    }
    # Each basis signal becomes one gray image shared by all palettes. Color
    # multiply/add nodes operate on RGB together, avoiding three independent
    # scalar grade graphs per palette in the CPU compositor.
    token_images = {key: _gray_image(group, value, f'{key} • shared basis image')
                    for key, value in token_sources.items()}
    common_image = _gray_image(group, common, 'Shared white reflections')
    files = []
    first_grade = None
    for palette in palettes:
        tokens = C.PALETTES[palette]
        linear_tokens = {key: C.rgba(tokens[key])
                         for key in ('accent', 'accent2', 'neb')}
        emission_grade = .4 if palette == 'ivory' else 1.0
        color = common_image
        for key in ('accent', 'accent2', 'neb'):
            weight = tuple(linear_tokens[key][i] * emission_grade for i in range(3)) + (1,)
            contribution = _color_math(group, 'MULTIPLY', token_images[key], weight,
                                       f'{palette} • {key} linear token')
            color = _color_math(group, 'ADD', color, contribution,
                                f'{palette} • add {key}')
        grade = nodes.new('CompositorNodeSeparateColor')
        links.new(color, grade.inputs[0])
        combine = nodes.new('CompositorNodeCombineColor')
        combine.name = combine.label = f'{palette} • optimized graded loop'
        channels = []
        for channel in ('Red', 'Green', 'Blue'):
            links.new(grade.outputs[channel], combine.inputs[channel])
            channels.append(grade.outputs[channel])

        # Preserve real geometry/atmosphere coverage; reduce additional glow
        # coverage with the ivory grade. The original gated alpha provides the
        # finite transparent margin in all target palettes.
        brightness = _math(group, 'MINIMUM',
                           _math(group, 'MAXIMUM',
                                 _math(group, 'MAXIMUM', channels[0], channels[1]),
                                 channels[2]), 1)
        if palette == 'ivory':
            # Dark ink needs independent coverage on a pale interface. Mapping
            # alpha from dark RGB brightness would erase the charcoal orbits.
            coverage = sep.outputs['Alpha']
        else:
            coverage = _math(group, 'MAXIMUM', raw.outputs['Alpha'], brightness)
            coverage = _math(group, 'MINIMUM', sep.outputs['Alpha'], coverage)
        links.new(coverage, combine.inputs['Alpha'])
        image = combine.outputs['Image']
        if palette == 'ivory':
            image = _ivory_shadow(group, image, tokens)
        image = _clean_transparent_rgb(group, image, palette)
        if first_grade is None:
            first_grade = image
        directory = output_root / 'orb' / f'{style}_{palette}'
        files.append((palette, 1024, _file_output(
            group, image, directory, f'Export {style}/{palette} • native')))

        scale = nodes.new('CompositorNodeScale')
        scale.name = scale.label = f'{palette} • 512px Blender downsample'
        scale.inputs['Type'].default_value = 'Absolute'
        scale.inputs['X'].default_value = 512
        scale.inputs['Y'].default_value = 512
        scale.inputs['Interpolation'].default_value = 'Bicubic'
        links.new(image, scale.inputs['Image'])
        directory512 = output_root / 'orb' / f'{style}_{palette}_512'
        image512 = _clean_transparent_rgb(group, scale.outputs['Image'],
                                         palette + ' 512px')
        files.append((palette, 512, _file_output(
            group, image512, directory512,
            f'Export {style}/{palette} • 512px')))

    # The temporary normal animation output shows a finished palette, avoiding
    # any visible token-basis preview. It is deleted after the render job.
    if first_grade is not None:
        links.new(first_grade, output.inputs[0])
    return files


def configure_basis(scene, style, samples, size):
    C.PALETTES[BASIS_NAME] = BASIS.copy()
    C.apply_look(scene, style, BASIS_NAME)
    RT.enable(scene, BASIS, enabled=True, style=style)
    # Colored lights would multiply token channels rather than preserve a
    # reusable basis. Neutral lights retain the polished lighting energies.
    for light in bpy.data.lights:
        light.color = (1, 1, 1)
    scene.world.node_tree.nodes['Background'].inputs['Color'].default_value = (0, 0, 0, 1)
    scene.world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0
    scene.render.engine = 'BLENDER_EEVEE'
    scene.render.resolution_x = scene.render.resolution_y = size
    scene.render.resolution_percentage = 100
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = RENDER_THREADS
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'
    scene.render.image_settings.color_depth = '8'
    scene.render.image_settings.compression = 60
    scene.render.use_file_extension = True
    scene.render.film_transparent = True
    scene.render.compositor_device = COMPOSITOR_DEVICE
    scene.eevee.taa_render_samples = samples
    scene.eevee.use_raytracing = False
    scene['HarmonyLoopPipeline'] = 'Blender RGB-token basis + linear compositor palette grade'
    scene['HarmonyBasisTokens'] = json.dumps(BASIS, sort_keys=True)
    scene['HarmonyLook'] = style + '_optimized_graded_loop'
    C.PALETTES.pop(BASIS_NAME, None)


def _complete_png(path, size):
    """Fast resume guard: expected RGBA8 header and a completed PNG IEND chunk."""
    try:
        with path.open('rb') as image:
            header = image.read(33)
            image.seek(-12, 2)
            ending = image.read(12)
        return (header[:8] == b'\x89PNG\r\n\x1a\n'
                and header[12:16] == b'IHDR'
                and struct.unpack('>II', header[16:24]) == (size, size)
                and header[24:26] == bytes((8, 6))
                and ending == b'\x00\x00\x00\x00IEND\xaeB\x60\x82')
    except (OSError, ValueError, struct.error):
        return False


def _missing_spans(frames, style, palettes, root, skip, native_size=1024):
    missing = []
    for frame in frames:
        complete = all(_complete_png(root / 'orb' / f'{style}_{p}{suffix}' /
                                    f'orb_{frame:04d}.png',
                                    512 if suffix else native_size)
                       for p in palettes for suffix in ('', '_512'))
        if not skip or not complete:
            missing.append(frame)
    spans = []
    for frame in missing:
        if spans and frame == spans[-1][1] + 1:
            spans[-1][1] = frame
        else:
            spans.append([frame, frame])
    return spans


def render_style(scene, style, args):
    configure_basis(scene, style, args.samples, args.size)
    files = add_palette_outputs(scene, style, args.palettes, args.output_root)
    audit_dir = args.output_root / 'audit'
    audit_dir.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix='harmony-animation-'))
    scene.render.filepath = str(temp / 'frame_')
    started = {}
    seam_mode = [False]

    def set_destinations(s, depsgraph=None):
        frame = s.frame_current
        for palette, size, node in files:
            if seam_mode[0]:
                node.directory = str(audit_dir / 'loop' /
                                     f'{style}_{palette}{"_512" if size == 512 else ""}')
                node.file_name = f'loop_f{frame:03d}'
            else:
                node.directory = str(args.output_root / 'orb' /
                                     f'{style}_{palette}{"_512" if size == 512 else ""}')
                # Animation=True appends a four-digit frame index itself.
                # A per-frame explicit index would be appended a second time.
                node.file_name = 'orb_'

    def mark_start(s):
        started[s.frame_current] = time.perf_counter()
        set_destinations(s)

    def mark_finish(s):
        duration = time.perf_counter() - started.get(s.frame_current, time.perf_counter())
        record = dict(style=style, frame=s.frame_current, native_size=args.size,
                      samples=args.samples, seconds=round(duration, 3),
                      target_palettes=args.palettes, outputs=len(files),
                      pipeline='optimized graded loop',
                      compositor_device=s.render.compositor_device,
                      png_compression=files[0][2].format.compression,
                      alpha_cleanup_threshold=ALPHA_CLEANUP_THRESHOLD,
                      render_threads=s.render.threads,
                      llvmpipe_threads=os.environ.get('LP_NUM_THREADS'),
                      seam_reference=seam_mode[0], blender=bpy.app.version_string)
        with (audit_dir / 'animation-render-times.jsonl').open('a') as out:
            out.write(json.dumps(record) + '\n')
        print(f'BATCH_RENDERED {style} frame={s.frame_current:03d} '
              f'{duration:.3f}s outputs={len(files)}', flush=True)

    def remove_temporary_output(s):
        # Animation=True writes the group output as well as File Outputs. Keep
        # only the delivered palette images; never add token-basis images to
        # the handoff package.
        path = Path(s.render.frame_path(frame=s.frame_current))
        if path.parent == temp:
            path.unlink(missing_ok=True)

    handlers = ((bpy.app.handlers.frame_change_pre, set_destinations),
                (bpy.app.handlers.render_pre, mark_start),
                (bpy.app.handlers.render_post, mark_finish),
                (bpy.app.handlers.render_write, remove_temporary_output))
    for collection, handler in handlers:
        collection.append(handler)
    try:
        spans = _missing_spans(range(args.start, args.end + 1), style,
                               args.palettes, args.output_root, args.skip_existing,
                               args.size)
        for start, end in spans:
            scene.frame_start, scene.frame_end = start, end
            scene.frame_set(start)
            # One animation operation retains the EEVEE renderer across all
            # frames in a span, rather than initializing it for every still.
            bpy.ops.render.render(animation=True, scene=scene.name)
        if args.audit_seams and args.end == 120:
            seam_mode[0] = True
            scene.frame_set(121)
            set_destinations(scene)
            bpy.ops.render.render(write_still=False, scene=scene.name)
    finally:
        for collection, handler in handlers:
            if handler in collection:
                collection.remove(handler)
        shutil.rmtree(temp, ignore_errors=True)
        scene.frame_start, scene.frame_end = 1, 120
        scene.frame_set(1)


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--style', choices=(*C.STYLES, 'all'), default='calm')
    p.add_argument('--palettes', nargs='+', choices=TARGET_PALETTES,
                   default=list(TARGET_PALETTES))
    p.add_argument('--start', type=int, default=1)
    p.add_argument('--end', type=int, default=120)
    p.add_argument('--samples', type=int, default=8)
    p.add_argument('--size', type=int, default=1024,
                   help='Native render size; use a separate --output-root for proofs.')
    p.add_argument('--output-root', type=Path, default=ROOT)
    p.add_argument('--skip-existing', action='store_true')
    p.add_argument('--audit-seams', action='store_true')
    args = p.parse_args(argv)
    if not (1 <= args.start <= args.end <= 120):
        p.error('Frames must be an inclusive range within 1–120.')
    if args.samples < 4:
        p.error('Use at least 4 EEVEE samples to preserve thin electron trails.')
    if args.size < 128:
        p.error('Native render size must be at least 128px.')
    args.output_root = args.output_root.resolve()
    styles = C.STYLES if args.style == 'all' else (args.style,)
    audit_dir = args.output_root / 'audit'
    audit_dir.mkdir(parents=True, exist_ok=True)
    metadata = {
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'renderer': 'Blender EEVEE + scene-linear Blender compositor',
        'blender': bpy.app.version_string,
        'pipeline': 'optimized graded loop',
        'styles': list(styles), 'palettes': args.palettes,
        'frames': [args.start, args.end], 'playback_fps': 30,
        'native_render_size': [args.size, args.size],
        'companion_size': [512, 512], 'downsample': 'Blender bicubic',
        'samples': args.samples, 'compositor_device': COMPOSITOR_DEVICE,
        'render_threads': RENDER_THREADS,
        'llvmpipe_threads': os.environ.get('LP_NUM_THREADS'),
        'png': {'mode': 'RGBA', 'bits': 8, 'compression': 80},
        'temporary_basis_tokens': BASIS,
        'white_component': 'min(R,G,B), retained unchanged',
        'ivory': {'color_multiplier': .4, 'coverage': 'independent source alpha',
                  'soft_shadow_alpha': .10},
        'alpha_cleanup': {'threshold': ALPHA_CLEANUP_THRESHOLD,
                          'low_alpha_fringe': 'sub-byte RGB trim; visible change bounded by 1/255 opacity',
                          'dither': 'retained; zero-alpha RGB may contain 1/255 residue'},
        'atmosphere': 'three procedural camera-facing realtime cards',
        'palette_lighting': 'neutral basis; palette interactions are approximated',
        'seam_references': bool(args.audit_seams and args.end == 120),
        'notes': 'source/harmony_batch_render_NOTES.md',
    }
    (audit_dir / 'optimized-loop-export.json').write_text(json.dumps(metadata, indent=2) + '\n')
    scene = C.load_seed()
    for style in styles:
        render_style(scene, style, args)


if __name__ == '__main__':
    main()
