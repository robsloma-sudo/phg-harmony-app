"""Export exact compact material and geometry specifications without rendering."""
import sys,json,math,hashlib
from pathlib import Path
import bpy
SOURCE=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
import harmony_core_build as C
import harmony_realtime as RT
import harmony_supporting_build as S
ROOT=SOURCE.parent

def val(v):
    if isinstance(v,(str,int,float,bool)):return v
    try:return [float(x) for x in v]
    except Exception:return str(v)

def hexcolor(v):
    def srgb(x):
        x=max(0,min(1,float(x)))
        return 12.92*x if x<=.0031308 else 1.055*x**(1/2.4)-.055
    return '#'+''.join(f'{round(srgb(x)*255):02X}' for x in list(v)[:3])

CONTROLS={'ShellEmit','RimStrength','ShellAlpha','PlasmaEmit','NebEmit','NebDensity',
          'SynStrength','TrailStrength','StarStrength','Strength'}
SURFACE={'Roughness','Metallic','IOR','Coat Weight','Coat Roughness','Subsurface Weight',
         'Emission Strength','Specular IOR Level'}

def material(m):
    d={'surface_render_method':m.surface_render_method,'colors':[],'ramps':{},
       'strength_controls':{},'surfaces':{},'noise':[]}
    for n in m.node_tree.nodes:
        for i,s in enumerate(n.inputs):
            if s.type=='RGBA' and hasattr(s,'default_value') and not s.is_linked and s.enabled:
                d['colors'].append({'node':n.name,'socket':s.name,'index':i,
                                    'hex':hexcolor(s.default_value),'linear_rgba':val(s.default_value)})
        if hasattr(n,'color_ramp'):
            d['ramps'][n.name]={'interpolation':n.color_ramp.interpolation,
                'stops':[{'position':e.position,'hex':hexcolor(e.color),
                          'linear_rgba':val(e.color)} for e in n.color_ramp.elements]}
        if n.name in CONTROLS:
            d['strength_controls'][n.name]={'operation':getattr(n,'operation','VALUE'),
                'constants':[{'index':i,'value':val(s.default_value)} for i,s in enumerate(n.inputs)
                             if hasattr(s,'default_value') and not s.is_linked],
                'inputs':[{'index':i,'from_node':s.links[0].from_node.name,
                           'from_socket':s.links[0].from_socket.name} for i,s in enumerate(n.inputs) if s.is_linked]}
            if n.type=='VALUE':d['strength_controls'][n.name]['value']=n.outputs[0].default_value
        if n.type=='BSDF_PRINCIPLED':
            d['surfaces'][n.name]={s.name:val(s.default_value) for s in n.inputs
                                   if s.name in SURFACE and not s.is_linked}
        if n.type=='TEX_NOISE':
            d['noise'].append({'node':n.name,'dimensions':n.noise_dimensions,
                'parameters':{s.name:val(s.default_value) for s in n.inputs
                              if s.name in ('Scale','Detail','Roughness','Distortion')},
                'time':'LoopT circular 4D offset; one integer cycle per 120 frames'})
    ad=m.node_tree.animation_data
    d['drivers']=[{'path':f.data_path,'expression':f.driver.expression} for f in ad.drivers] if ad else []
    return d

def geometry(s,style):
    return {'camera':{'type':s.camera.data.type,'ortho_scale':s.camera.data.ortho_scale,
                     'position':list(s.camera.location),'rotation_degrees':[math.degrees(x) for x in s.camera.rotation_euler]},
            'shell_radius':1,'plasma_radius':.94,
            'nucleus':{'count':13,'particle_radius':.145,'center_radius':.285,
                       'turn_degrees_per_loop':360,'initial_tilt_radians':[.4,.2,0]},
            'breathing':{'min':1,'max':1.05,'keyframes':[1,61,121]},
            'orbits':[{ 'name':nm,'radius':r,'tube_radius':t*({'calm':1,'tech':.8,'friendly':2.5}[style]),
                        'tilt_x_degrees':14,'roll_y_degrees':roll,'electron_angles_degrees':angles,
                        'electron_radius':dr*({'calm':1,'tech':.85,'friendly':1.6}[style]),
                        'rotation_degrees_per_loop':deg,'dash_count':dash,'dash_on_fraction':.55 if dash else 1,
                        'trail_fraction_of_electron_spacing':.22 if style=='tech' else .44}
                       for nm,r,t,roll,angles,dr,deg,dash in
                       [('A',2.3,.008,-15,[0,90,180,270],.045,720 if style=='tech' else 360,0),
                        ('B',1.75,.007,45,[45,225],.040,-360,64),
                        ('C',2.70,.006,105,[20,140,260],.035,120,0)]],
            'star_count':380,'synapse_root_count':26,
            'tech_ticks':{'count':24,'spacing_degrees':15,'radial_range':[2.265,2.335],
                          'tangential_width':.006,'parent':'SpinA','visible':style=='tech'},
            'tech_wire':{'ico_subdivisions':3,'scale':1.003,'thickness':.0011,'visible':style=='tech'}}

def main():
    s=C.load_seed()
    spec={'blender_version':bpy.app.version_string,'date':'2026-10-04','palette_tokens':C.PALETTES,
          'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(SOURCE.glob('*.py'))},
          'render_presets':{'editable_beauty_master':{'engine':'EEVEE','render_samples':64,'volume_samples':96,'volume_tile_px':2},
                            'delivered_beauty_stills':{'engine':'EEVEE','render_samples':16,'volume_samples':32,'volume_tile_px':4,'native_size':1024,'direct_palette_lighting':True},
                            'editable_animation_master':{'engine':'EEVEE','render_samples':8,'native_size':1024,'atmosphere':'procedural cards','palette':'actual Midnight colors, ungraded'},
                            'delivered_animation':{'engine':'EEVEE','render_samples':4,'native_size':1024,'downsample_size':512,'downsample':'Blender Bicubic','atmosphere':'procedural cards','palette_method':'RGB token basis + linear compositor grade','direct_palette_lighting':False,'compositor_device':'GPU','device_implementation':'Mesa software / llvmpipe; no hardware GPU','render_threads':4,'alpha_rgb_cleanup_threshold':1/256-1e-9,'png_dither_residue_max_byte':1}},
          'color_management':{'view_transform':'Standard','look':'None','exposure':0,'gamma':1,'hex_conversion':'sRGB hex to scene-linear Rec.709 before shader/compositor use'},
          'timing':{'fps':30,'frames':120,'frame_start':1,'frame_end':120,'endpoint_reference':121,'duration_seconds':4,'shader_phase':'(frame-1)/120'},
          'state_references':{'style':'calm','palette':'midnight','size':[1024,1024],'frame':1,
                              'sphere_accent_hex':{'listening':'#FF5C5C','thinking':'#A684FF','speaking':'#3FE0C0'},
                              'affected_materials':['M_Shell','M_Plasma'],
                              'retained_palette_materials':['M_Proton','M_Neutron','M_TrailA','M_TrailB','M_TrailC','M_ElectronA','M_ElectronB','M_ElectronC','M_Synapse','M_Nebula','M_Stars']},
          'shared_formulas':{'emission_multiplier':'e = (ivory ? 0.4 : 1.0) * (friendly ? 0.5 : 1.0)',
              'shell_emission':'e * (0.30 + 0.34 * veins)',
              'shell_rim':'e * 0.58 * facing^3.2',
              'shell_alpha':'0.28 + 0.62 * facing^1.65',
              'nucleus_emission':'e * (0.18 + 0.62 * (1-facing))',
              'synapse_strength':'e * fade * back_mask * ((1.10 + 1.20*hero)*pulse + 0.18 + 0.24*hero)',
              'synapse_hero':'UV phase v < 0.26',
              'synapse_pulse':'pow(map_linear(fract(0.55*u - 2*LoopT + v),0.73,1),3.5)',
              'trail_strength':'e * back_mask * (1.4*tail + base); base=0.10 on A/C, 0.16*dash_mask on B',
              'electron_strength':'e * 1.05 * back_mask; emission color = orbit color + 2.5% white',
              'stars_strength':'e * fade * (0.10 + 1.10 * twinkle^4); twinkle=(sin(2*pi*(3*LoopT+phase))+1)/2',
              'ivory_synapse_coverage':'fade * (0.20 + 0.44*pulse), brightness floor 0.30',
              'ivory_trail_coverage':'back_mask * (0.38 + 0.50*tail), brightness floor 0.40',
              'ivory_electron_coverage':'0.88 * back_mask',
              'glow_alpha':'max(render_alpha,min(max(final_R,final_G,final_B),1)) then multiply RGBA by finite margin mask'},
          'beauty_looks':{},'realtime_atmosphere':{},'supporting_assets':{},
          'playback_reviews':{'styles':['calm','tech','friendly'],'palette':'midnight','frame_count':240,'fps':30,'duration_seconds':8,'source':'Complete 120-frame Blender PNG loop repeated twice','background_compositor':'Blender','mp4_encoder':'FFmpeg'}}
    for style in C.STYLES:
        for pal in C.PALETTES:
            C.apply_look(s,style,pal)
            look=style+'_'+pal
            gl=s.compositing_node_group.nodes['Bloom']
            lights={o.name:{'type':o.data.type,'energy_watts':o.data.energy,'color_hex':hexcolor(o.data.color),
                            'color_linear':list(o.data.color),'position':list(o.location),
                            'size':o.data.size if o.data.type=='AREA' else o.data.shadow_soft_size}
                    for o in s.objects if o.type=='LIGHT'}
            spec['beauty_looks'][look]={'style':style,'palette':pal,'emission_multiplier':(.4 if pal=='ivory' else 1)*(.5 if style=='friendly' else 1),
                'geometry':geometry(s,style),'lights':lights,
                'world':{'panel_hex':C.PALETTES[pal]['panel'],'strength':.22},
                'bloom':{k:gl.inputs[k].default_value for k in ('Threshold','Strength','Size','Saturation')},
                'safe_margin':{'mask':'Box','size':[.89,.89],'blur':'Gaussian','radius_px':[18,18],'gates':'RGBA','invisible_rgb_alpha_threshold':.5/255},
                'materials':{m.name:material(m) for m in bpy.data.materials if m.name.startswith('M_') and not m.name.startswith('M_Atmosphere')},
                'ivory_shadow':{'visible':pal=='ivory','alpha_peak':.12,'plane_size':[2.8,2.8],'position':[0,2,-.16]}}
            RT.enable(s,pal,True,style)
            spec['realtime_atmosphere'][look]={n:material(bpy.data.materials[n]) for n in RT.MATERIAL_NAMES}
            RT.enable(s,pal,False,style)
    spec['animation_palette_grade']={'temporary_basis':{'accent':'#FF0000','accent2':'#0000FF','neb':'#00FF00','world':'#000000','lights':'#FFFFFF'},
        'white':'min(R,G,B)','signals':{'accent':'max(R-white,0)','accent2':'max(B-white,0)','neb':'max(G-white,0)'},
        'result':'white + accent_signal*linear(accent)*e_grade + accent2_signal*linear(accent2)*e_grade + neb_signal*linear(neb)*e_grade',
        'e_grade':'ivory=0.4; others=1.0; friendly emission already included in style basis',
        'ivory_shadow':{'ellipse_position':[.50,.48],'ellipse_size':[.32,.32],'blur_radius_px':[20,20],'alpha_peak':.10},
        'limitations':['Palette-colored PBR interactions are approximate','Black basis does not encode separate bg or panel token','Realtime cards replace full volumes in animation']}
    mark=S.build_mark();background=S.build_background();pins=S.build_pins()
    support={'mark':{},'background':{},'pins':{}}
    for style in S.STYLES:
        for pal,palvalues in S.PALETTES.items():
            S.apply_mark(*mark,style,palvalues)
            support['mark'][style+'_'+pal]={'core_radius':.79,'camera_scale':3.7,'orbit_radius':1.27,
                'orbit_projected_axis_ratio':.47,'orbit_diagonal_degrees':25,'orbit_tube_radius':mark[2].data.bevel_depth,
                'electron_radius':.105*mark[3].scale.x,'electron_angle_degrees':318,
                'materials':{m.name:material(m) for ob in mark[1:] for m in ob.data.materials},
                'transparent_size':[1024,1024],'opaque_icon_sizes':[1024,512,192,180]}
            support['background'][style+'_'+pal]={}
            for portrait in [False,True]:
                S.apply_background(*background,style,palvalues,portrait)
                key='portrait' if portrait else 'landscape'
                support['background'][style+'_'+pal][key]={'size':[1290,2796] if portrait else [2560,1440],
                    'material':material(background[1].data.materials[0]),'bg_hex':palvalues['bg'],
                    'cool_center':[.99,.98],'warm_center':[-.03,.02],
                    'cool_gain':(.036 if pal=='ivory' else .105)*{'calm':1,'tech':.93,'friendly':1.1}[style],
                    'warm_gain':(.023 if pal=='ivory' else .057)*{'calm':1,'tech':.93,'friendly':1.1}[style]}
    for pal,palvalues in S.PALETTES.items():
        for variant in ['primary','secondary']:
            S.apply_pin(*pins,palvalues,variant)
            support['pins'][pal+'_'+variant]={'size':[256,256],'dot_radius':.51,'outline_radius':.543,'outline_tube_radius':.0085,
                'halo_plane_size':1.85,'materials':{m.name:material(m) for ob in pins[1:] for m in ob.data.materials}}
    spec['supporting_assets']=support
    (ROOT/'SPEC.json').write_text(json.dumps(spec,indent=2))
    print('WROTE SPEC.json', (ROOT/'SPEC.json').stat().st_size,'bytes; no renders, no blend saved')

if __name__=='__main__':main()
