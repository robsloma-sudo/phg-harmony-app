"""Blender compositor finish for existing beauty PNGs.

Preserve coverage and visible colors while clearing invisible RGB in exports.
No drawing, recoloring, or enlargement takes place. Original renders stay in a
temporary input directory until Blender has decoded every output successfully.
"""
import os,tempfile
from pathlib import Path
os.environ.setdefault('MESA_SHADER_CACHE_DIR',str(Path(tempfile.gettempdir()) / 'harmony-mesa-cache'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir()) / 'harmony-cache'))
import sys,json,shutil,time
import bpy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
from harmony_review_build import _scene,ReviewGraph

def finish():
    paths=sorted((ROOT/'orb').glob('*_still.png'))+sorted((ROOT/'orb/states').glob('*.png'))+sorted((ROOT/'previews').glob('*transparent.png'))
    temp=Path(tempfile.mkdtemp(prefix='harmony-finish-'))
    s,nt=_scene();s.render.resolution_x=s.render.resolution_y=1024
    g=ReviewGraph(s,nt,temp);out=nt.nodes.new('NodeGroupOutput');first=None
    for path in paths:
        image=g.image(path);sep=nt.nodes.new('CompositorNodeSeparateColor');nt.links.new(image,sep.inputs[0])
        gate=nt.nodes.new('ShaderNodeMath');gate.operation='GREATER_THAN';nt.links.new(sep.outputs['Alpha'],gate.inputs[0]);gate.inputs[1].default_value=.5/255
        cc=nt.nodes.new('CompositorNodeCombineColor')
        for c in ['Red','Green','Blue']:
            n=nt.nodes.new('ShaderNodeMath');n.operation='MULTIPLY';nt.links.new(sep.outputs[c],n.inputs[0]);nt.links.new(gate.outputs[0],n.inputs[1]);nt.links.new(n.outputs[0],cc.inputs[c])
        nt.links.new(sep.outputs['Alpha'],cc.inputs['Alpha'])
        g.output(cc.outputs[0],path.relative_to(ROOT),(1024,1024))
        if first is None:first=cc.outputs[0]
    nt.links.new(first,out.inputs[0]);start=time.perf_counter();bpy.ops.render.render(scene=s.name)
    for original in paths:
        final=temp/original.relative_to(ROOT)
        if not final.is_file():raise RuntimeError('Missing finished PNG '+str(final))
        im=bpy.data.images.load(str(final),check_existing=False)
        if tuple(im.size)!=(1024,1024):raise RuntimeError('Bad finished size '+str(final))
        bpy.data.images.remove(im)
    for original in paths:
        staged=original.with_suffix('.finished.png')
        shutil.copy2(temp/original.relative_to(ROOT),staged);staged.replace(original)
    shutil.rmtree(temp)
    report={'blender':bpy.app.version_string,'outputs':len(paths),'seconds':round(time.perf_counter()-start,3),'renderer':'Blender scene-linear compositor; visible color and alpha coverage preserved','paths':[str(p.relative_to(ROOT)) for p in paths]}
    (ROOT/'audit/png-finish.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':finish()
