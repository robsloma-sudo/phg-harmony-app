"""Harmony supporting assets. All pixels rendered by Blender 5.2 EEVEE.

Run with Blender 5.2 LTS: blender --background --python source/harmony_supporting_build.py
Use --preview to build scenes and render one specimen per asset family.
No source handoff files are modified. Geometry, palette and shaders are editable.
"""
import bpy, bmesh, math, os, sys, time, json
from mathutils import Vector

ROOT = os.path.abspath(os.environ.get('HARMONY_OUTPUT', os.path.join(os.path.dirname(__file__), '..')))
PALETTES = {
    'midnight': dict(bg='#070B18', panel='#111A33', accent='#D9B25F', accent2='#7F9CFF', line='#24304F', neb='#6A4BD8'),
    'aurora': dict(bg='#06110F', panel='#0E2220', accent='#3FE0C0', accent2='#A684FF', line='#1F3B38', neb='#1B6F9E'),
    'ocean': dict(bg='#05101F', panel='#0E2140', accent='#4FB3FF', accent2='#9EE7FF', line='#21406B', neb='#3A4FD8'),
    'ember': dict(bg='#121012', panel='#221D1F', accent='#FF7A59', accent2='#FFC06B', line='#3A3135', neb='#C2316A'),
    'ivory': dict(bg='#F6F2EA', panel='#FFFDF8', accent='#2B2A28', accent2='#B0875A', line='#DDD4C4', neb='#D9C3A0', light=True),
}
STYLES = ['calm', 'tech', 'friendly']
TAU = 2 * math.pi
TIMINGS = []

def palette_label(pal):
    return next((k for k,v in PALETTES.items() if v==pal),str(pal.get('name','custom')))

def lin(v):
    return v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4

def rgba(h, alpha=1):
    h=h.lstrip('#'); return tuple(lin(int(h[i:i+2],16)/255) for i in (0,2,4))+(alpha,)

def mix(a,b,t):
    return tuple(a[i]*(1-t)+b[i]*t for i in range(3))+(1,)

class Nodes:
    def __init__(self, material):
        material.use_nodes=True
        self.nt=material.node_tree; self.nt.nodes.clear()
        self.n=self.nt.nodes; self.l=self.nt.links
    def new(self, typ, name=None, **kw):
        n=self.n.new(typ)
        if name: n.name=n.label=name
        for k,v in kw.items(): setattr(n,k,v)
        return n
    def put(self,sock,value):
        if isinstance(value,bpy.types.NodeSocket): self.l.new(value,sock)
        else: sock.default_value=value
    def math(self,op,a,b=0,name=None):
        n=self.new('ShaderNodeMath',name,operation=op)
        self.put(n.inputs[0],a);self.put(n.inputs[1],b);return n.outputs[0]
    def mix(self,f,a,b,name=None):
        n=self.new('ShaderNodeMixRGB',name,blend_type='MIX')
        self.put(n.inputs[0],f);self.put(n.inputs[1],a);self.put(n.inputs[2],b)
        return n.outputs[0]
    def uv(self):
        n=self.new('ShaderNodeTexCoord');s=self.new('ShaderNodeSeparateXYZ')
        self.l.new(n.outputs['UV'],s.inputs[0]);return s.outputs[0],s.outputs[1]
    def gaussian(self,u,v,x,y,sx,sy,name):
        du=self.math('DIVIDE',self.math('SUBTRACT',u,x),sx)
        dv=self.math('DIVIDE',self.math('SUBTRACT',v,y),sy)
        q=self.math('ADD',self.math('MULTIPLY',du,du),self.math('MULTIPLY',dv,dv))
        return self.math('EXPONENT',self.math('MULTIPLY',q,-2),name=name)
    def emission(self,color,strength=1):
        n=self.new('ShaderNodeEmission');self.put(n.inputs['Color'],color)
        self.put(n.inputs['Strength'],strength);return n.outputs[0]
    def out(self,s):
        n=self.new('ShaderNodeOutputMaterial');self.l.new(s,n.inputs['Surface'])

def mat(name):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes=True; m.surface_render_method='DITHERED'
    return m

def sphere(scene,name,radius,segments=96,rings=48):
    bm=bmesh.new();bmesh.ops.create_uvsphere(bm,u_segments=segments,v_segments=rings,radius=radius)
    mesh=bpy.data.meshes.new(name);bm.to_mesh(mesh);bm.free();mesh.shade_smooth()
    ob=bpy.data.objects.new(name,mesh);scene.collection.objects.link(ob);return ob

def plane(scene,name,w,h,y):
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata([(-w/2,y,-h/2),(w/2,y,-h/2),(w/2,y,h/2),(-w/2,y,h/2)],[],[(0,1,2,3)])
    mesh.update();uv=mesh.uv_layers.new(name='UVMap')
    for i,co in enumerate([(0,0),(1,0),(1,1),(0,1)]):uv.data[i].uv=co
    ob=bpy.data.objects.new(name,mesh);scene.collection.objects.link(ob);return ob

def curve(scene,name,coords,thickness,closed=False):
    c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=2
    c.bevel_depth=thickness;c.bevel_resolution=5
    s=c.splines.new('POLY');s.points.add(len(coords)-1)
    for p,co in zip(s.points,coords):p.co=(*co,1)
    s.use_cyclic_u=closed
    ob=bpy.data.objects.new(name,c);scene.collection.objects.link(ob);return ob

def aim(ob,pt=(0,0,0)):
    ob.rotation_euler=(Vector(pt)-ob.location).to_track_quat('-Z','Y').to_euler()

def camera(scene,scale):
    d=bpy.data.cameras.new(scene.name+'_Camera');d.type='ORTHO';d.ortho_scale=scale
    ob=bpy.data.objects.new(d.name,d);scene.collection.objects.link(ob)
    ob.location=(0,-8,0);aim(ob);scene.camera=ob;return ob

def light(scene,name,location,power,size,color='#FFFFFF'):
    d=bpy.data.lights.new(name,'AREA');d.energy=power;d.shape='DISK';d.size=size
    d.color=rgba(color)[:3];ob=bpy.data.objects.new(name,d)
    scene.collection.objects.link(ob);ob.location=location;aim(ob);return ob

def rig(scene,name,objects):
    root=bpy.data.objects.new(name,None);root.empty_display_type='PLAIN_AXES';root.empty_display_size=.2
    scene.collection.objects.link(root)
    for ob in objects:ob.parent=root
    root['loop_frames']=120;root['loop_fps']=30
    return root

def setup(scene,w,h,transparent,samples=24):
    engines=scene.render.bl_rna.properties['engine'].enum_items.keys()
    scene.render.engine='BLENDER_EEVEE_NEXT' if 'BLENDER_EEVEE_NEXT' in engines else 'BLENDER_EEVEE'
    scene.eevee.taa_render_samples=samples
    scene.render.resolution_x=w;scene.render.resolution_y=h;scene.render.resolution_percentage=100
    scene.render.film_transparent=transparent
    scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA' if transparent else 'RGB'
    scene.render.image_settings.color_depth='8';scene.render.image_settings.compression=45
    if hasattr(scene.render,'dither_intensity'):scene.render.dither_intensity=1.0
    scene.render.threads_mode='FIXED';scene.render.threads=4
    scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
    scene.view_settings.exposure=0;scene.view_settings.gamma=1
    scene.render.fps=30
    scene.frame_start=1;scene.frame_end=120

def world(scene,pal):
    w=bpy.data.worlds.get(scene.name+'_World') or bpy.data.worlds.new(scene.name+'_World')
    w.use_nodes=True;n=w.node_tree.nodes.get('Background')
    n.inputs['Color'].default_value=rgba(pal['bg']);n.inputs['Strength'].default_value=.32
    scene.world=w;return w

def princ_material(name,color,rough=.2,metal=.18,emission=.0):
    m=mat(name);g=Nodes(m);p=g.new('ShaderNodeBsdfPrincipled','Surface')
    p.inputs['Base Color'].default_value=color
    p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
    p.inputs['Coat Weight'].default_value=.75;p.inputs['Coat Roughness'].default_value=.09
    p.inputs['Emission Color'].default_value=color;p.inputs['Emission Strength'].default_value=emission
    g.out(p.outputs[0]);return m

def mark_material(style,pal):
    m=mat('Mark_Core');g=Nodes(m)
    tex=g.new('ShaderNodeTexCoord','CoreCoordinates')
    sep=g.new('ShaderNodeSeparateXYZ');g.l.new(tex.outputs['Generated'],sep.inputs[0])
    x=g.math('SUBTRACT',sep.outputs[0],.5);z=g.math('SUBTRACT',sep.outputs[2],.5)
    angle=g.math('ADD',g.math('DIVIDE',g.math('ARCTAN2',z,x),TAU),.5)
    ramp=g.new('ShaderNodeValToRGB','Conic_Palette_Sweep');ramp.color_ramp.interpolation='EASE'
    stops=[(0,rgba(pal['accent'])),(.24,rgba(pal['accent'])),(.53,rgba(pal['accent'])),(.73,rgba(pal['accent2'])),(.86,mix(rgba(pal['accent2']),(1,1,1,1),.10)),(1,rgba(pal['accent']))]
    for _ in range(len(stops)-2):ramp.color_ramp.elements.new(.5)
    for e,(f,c) in zip(ramp.color_ramp.elements,stops):e.position=f;e.color=c
    g.l.new(angle,ramp.inputs[0])
    # A wide directional sweep avoids a sharp conic cusp at tiny app sizes;
    # a restrained angular component retains the original rotating palette idea.
    direction=g.math('ADD',g.math('MULTIPLY',x,-.65),g.math('MULTIPLY',z,.76))
    dr=g.new('ShaderNodeMapRange','Upper_Left_Blue_Sweep',interpolation_type='SMOOTHSTEP',clamp=True)
    g.put(dr.inputs[0],direction);dr.inputs[1].default_value=-.12;dr.inputs[2].default_value=.34
    sweep=g.mix(dr.outputs[0],rgba(pal['accent']),rgba(pal['accent2']),'Broad_Palette_Sweep')
    conic=g.mix(.12,sweep,ramp.outputs[0],'Restrained_Angular_Accent')
    # The darker lower quarter provides depth without muddying token hues.
    lower=g.math('MULTIPLY',g.math('SUBTRACT',1,sep.outputs[2]),.10 if pal.get('light',False) else .35)
    base=g.mix(lower,conic,mix(rgba(pal['accent']),rgba(pal['bg']),.68),'Lower_Pole_Depth')
    p=g.new('ShaderNodeBsdfPrincipled','Jewel_Surface');g.put(p.inputs['Base Color'],base)
    p.inputs['Metallic'].default_value={'calm':.19,'tech':.31,'friendly':.05}[style]
    p.inputs['Roughness'].default_value={'calm':.25,'tech':.27,'friendly':.48}[style]
    p.inputs['Coat Weight'].default_value=.65 if style!='friendly' else .3
    p.inputs['Coat Roughness'].default_value=.18 if style!='friendly' else .3
    g.put(p.inputs['Emission Color'],base)
    p.inputs['Emission Strength'].default_value=(.55 if style!='friendly' else .28)*(.4 if pal.get('light',False) else 1)
    g.out(p.outputs[0]);return m

def ring_point(a):
    # 25-degree diagonal, 0.47 projected axis ratio; genuine depth, no fake overlap.
    x=1.27*math.cos(a);z=1.27*.47*math.sin(a);y=1.27*.883*math.sin(a)
    t=math.radians(25)
    return (x*math.cos(t)-z*math.sin(t),y,x*math.sin(t)+z*math.cos(t))

def build_mark():
    s=bpy.data.scenes.new('Mark');setup(s,1024,1024,True);camera(s,3.7)
    core=sphere(s,'Mark_Central_Jewel',.79)
    ring=curve(s,'Mark_Single_Orbit',[ring_point(i*TAU/512) for i in range(512)],.041,True)
    dot=sphere(s,'Mark_One_Electron',.105,64,32);dot.location=ring_point(math.radians(318))
    rig(s,'Mark_Rig',[core,ring,dot])
    light(s,'Mark_Key',(-3,-4,4),130,5,'#F9F6F0')
    light(s,'Mark_Rim',(-2,1,3),90,4)
    light(s,'Mark_Lower_Fill',(-2,-2,-3),20,4)
    s['design']='One jewel, one continuous orbit, one electron. Designed for 32 px clarity.'
    return s,core,ring,dot

def apply_mark(s,core,ring,dot,style,pal):
    world(s,pal)
    core.data.materials.clear();core.data.materials.append(mark_material(style,pal))
    ring.data.bevel_depth={'calm':.041,'tech':.034,'friendly':.067}[style]
    rcol=rgba(pal['accent'])
    rm=princ_material('Mark_Orbit',rcol,rough=.28 if style=='friendly' else .22,metal=.18 if style=='friendly' else .30,emission=.30 if style=='friendly' else .60)
    ring.data.materials.clear();ring.data.materials.append(rm)
    dot.scale=(1.15,)*3 if style=='friendly' else ((.86,)*3 if style=='tech' else (1,)*3)
    dm=princ_material('Mark_Electron',mix(rgba(pal['accent2']),(1,1,1,1),.11),rough=.24,metal=.14,emission=.42)
    dot.data.materials.clear();dot.data.materials.append(dm)
    s['style']=style;s['palette']=palette_label(pal)

def build_background():
    s=bpy.data.scenes.new('Background');setup(s,2560,1440,False,4);camera(s,2)
    ob=plane(s,'Background_Quiet_Color_Field',2,2,0)
    s['design']='Quiet field. Corner light leaves the central reading area calm. No baked text.'
    return s,ob

def background_material(style,pal,portrait):
    m=mat('Background_Field');g=Nodes(m);u,v=g.uv()
    cool=g.gaussian(u,v,.99,.98,.52 if portrait else .43,.31 if portrait else .57,'Top_Right_Cool_Light')
    warm=g.gaussian(u,v,-.03,.02,.57 if portrait else .53,.31 if portrait else .61,'Bottom_Left_Warm_Light')
    is_ivory=pal.get('light',False)
    gain={'calm':1,'tech':.93,'friendly':1.1}[style]
    cool=g.math('MULTIPLY',cool,(.036 if is_ivory else .105)*gain)
    warm=g.math('MULTIPLY',warm,(.023 if is_ivory else .057)*gain)
    col=g.mix(cool,rgba(pal['bg']),rgba(pal['accent2']),'Palette_Cool_Mix')
    col=g.mix(warm,col,rgba(pal['accent']),'Palette_Warm_Mix')
    # Broad, restrained contour rhythm, not a noisy texture or visible grid.
    du=g.math('SUBTRACT',u,.90);dv=g.math('MULTIPLY',g.math('SUBTRACT',v,.12),.8 if portrait else .5625)
    rad=g.math('SQRT',g.math('ADD',g.math('MULTIPLY',du,du),g.math('MULTIPLY',dv,dv)))
    wave=g.math('SINE',g.math('MULTIPLY',rad,76 if style=='tech' else 44))
    line=g.math('GREATER_THAN',wave,.995 if style!='friendly' else .998)
    fade=g.math('MULTIPLY',g.math('POWER',u,3),g.math('SUBTRACT',1,v))
    line=g.math('MULTIPLY',g.math('MULTIPLY',line,fade),.035 if style=='tech' else .018)
    col=g.mix(line,col,rgba(pal['line']),'Subtle_Contour_Lines')
    g.out(g.emission(col));return m

def apply_background(s,ob,style,pal,portrait):
    w,h=(1290,2796) if portrait else (2560,1440)
    s.render.resolution_x=w;s.render.resolution_y=h
    # Ortho scale is width when landscape, height when portrait. Plane fits both.
    ratio=w/h
    ob.scale=(ratio if ratio<1 else 1,1,1 if ratio<1 else 1/ratio)
    s.camera.data.ortho_scale=2
    ob.data.materials.clear();ob.data.materials.append(background_material(style,pal,portrait))
    world(s,pal);s['style']=style;s['palette']=palette_label(pal)
    s['orientation']='portrait' if portrait else 'landscape'

def glow_material(name,color,ivory=False):
    m=mat(name);m.surface_render_method='BLENDED';g=Nodes(m);u,v=g.uv()
    gauss=g.gaussian(u,v,.5,.5,.39,.39,'Soft_Falloff')
    # Exact zero in the outer 12% of the plane keeps alpha margins clean.
    du=g.math('SUBTRACT',u,.5);dv=g.math('SUBTRACT',v,.5)
    radius=g.math('SQRT',g.math('ADD',g.math('MULTIPLY',du,du),g.math('MULTIPLY',dv,dv)))
    fade=g.new('ShaderNodeMapRange','Finite_Transparent_Edge',interpolation_type='SMOOTHSTEP',clamp=True)
    g.put(fade.inputs[0],radius);fade.inputs[1].default_value=.33;fade.inputs[2].default_value=.46
    fade.inputs[3].default_value=1;fade.inputs[4].default_value=0
    alpha=g.math('MULTIPLY',g.math('MULTIPLY',gauss,fade.outputs[0]),.13 if ivory else .24)
    tr=g.new('ShaderNodeBsdfTransparent');mixsh=g.new('ShaderNodeMixShader')
    g.put(mixsh.inputs[0],alpha);g.l.new(tr.outputs[0],mixsh.inputs[1]);g.l.new(g.emission(color),mixsh.inputs[2]);g.out(mixsh.outputs[0])
    return m

def build_pins():
    s=bpy.data.scenes.new('Pins');setup(s,256,256,True,24);camera(s,2.0)
    dot=sphere(s,'Pin_Glossy_Dot',.51,80,40)
    outline=curve(s,'Pin_Pale_Outline',[(.543*math.cos(i*TAU/384),-.02,.543*math.sin(i*TAU/384)) for i in range(384)],.0085,True)
    halo=plane(s,'Pin_Soft_Glow',1.85,1.85,.65)
    rig(s,'Pin_Rig',[dot,outline,halo])
    light(s,'Pin_Key',(-3,-4,4),160,5)
    light(s,'Pin_Rim',(-2,1,3),85,4)
    light(s,'Pin_Fill',(0,-3,-3),15,4)
    s['design']='Glossy dot, thin pale outline, finite soft halo. Transparent Atlas marker.'
    return s,dot,outline,halo

def apply_pin(s,dot,outline,halo,pal,variant):
    world(s,pal);color=rgba(pal['accent' if variant=='primary' else 'accent2'])
    ivory=pal.get('light',False)
    dot.data.materials.clear();dot.data.materials.append(princ_material('Pin_Surface',color,.25,.15,.40 if not ivory else .06))
    linecolor=mix(color,(1,1,1,1),.8 if not ivory else .56)
    outline.data.materials.clear();outline.data.materials.append(princ_material('Pin_Outline',linecolor,.22,.02,.18))
    halo.data.materials.clear();halo.data.materials.append(glow_material('Pin_Halo',color,ivory))
    s['variant']=variant;s['palette']=palette_label(pal)

def render(scene,path):
    os.makedirs(os.path.dirname(path),exist_ok=True)
    scene.render.filepath=path
    started=time.monotonic();bpy.ops.render.render(write_still=True,scene=scene.name)
    sec=time.monotonic()-started
    TIMINGS.append({'path':os.path.relpath(path,ROOT),'seconds':round(sec,3),'width':scene.render.resolution_x,'height':scene.render.resolution_y})
    print('HARMONY_SUPPORT '+json.dumps(TIMINGS[-1]),flush=True)

def prepare_viewports(scene):
    if not bpy.context.window:return
    bpy.context.window.scene=scene
    for area in bpy.context.window.screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.type='RENDERED'
            area.spaces.active.overlay.show_overlays=False

def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    # Empty factory scene can be removed once the three named production scenes exist.
    mark=build_mark();background=build_background();pins=build_pins()
    for scene in list(bpy.data.scenes):
        if scene.name not in ('Mark','Background','Pins'):bpy.data.scenes.remove(scene)
    preview='--preview' in sys.argv
    combinations=[('calm','midnight')] if preview else [(s,p) for s in STYLES for p in PALETTES]
    for style,palette in combinations:
        pal=PALETTES[palette]
        apply_mark(*mark,style,pal)
        s=mark[0];setup(s,1024,1024,True)
        render(s,os.path.join(ROOT,'mark',f'mark_{style}_{palette}.png'))
        if not preview:
            # A true Blender shader backdrop, rather than postcompositing the PNG.
            backdrop=plane(s,'Icon_Token_Background',4,4,2)
            bgmat=mat('Icon_Background');g=Nodes(bgmat);g.out(g.emission(rgba(pal['bg'])))
            backdrop.data.materials.append(bgmat)
            for size in [1024,512,192,180]:
                setup(s,size,size,False)
                render(s,os.path.join(ROOT,'mark','icons',f'mark_{style}_{palette}_{size}.png'))
            bpy.data.objects.remove(backdrop,do_unlink=True)
        for portrait in [False,True]:
            apply_background(*background,style,pal,portrait)
            suffix='_portrait' if portrait else ''
            render(background[0],os.path.join(ROOT,'backgrounds',f'bg_{style}_{palette}{suffix}.png'))
    for palette in (['midnight'] if preview else PALETTES):
        for variant in ['primary','secondary']:
            apply_pin(*pins,PALETTES[palette],variant)
            render(pins[0],os.path.join(ROOT,'pins',f'pin_{palette}_{variant}.png'))
    # Save source in its representative default state, with clean production settings.
    apply_mark(*mark,'calm',PALETTES['midnight']);setup(mark[0],1024,1024,True)
    apply_background(*background,'calm',PALETTES['midnight'],False)
    apply_pin(*pins,PALETTES['midnight'],'primary')
    prepare_viewports(mark[0])
    for sc in (mark[0],background[0],pins[0]):
        sc.render.filepath='//'+{'Mark':'../mark/mark_calm_midnight.png','Background':'../backgrounds/bg_calm_midnight.png','Pins':'../pins/pin_midnight_primary.png'}[sc.name]
    # Keep the reproducible source inside the .blend as well as beside it.
    block=bpy.data.texts.get('harmony_supporting_build.py') or bpy.data.texts.new('harmony_supporting_build.py')
    block.clear();block.use_fake_user=True
    with open(__file__,'r') as f:block.write(f.read())
    if hasattr(bpy.data,'orphans_purge'):bpy.data.orphans_purge(do_recursive=True)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(ROOT,'source','harmony_supporting.blend'),compress=True)
    with open(os.path.join(ROOT,'docs','supporting-render-times.json'),'w') as f:json.dump(TIMINGS,f,indent=2)
    print('HARMONY_SUPPORT_DONE '+str(len(TIMINGS)),flush=True)

if __name__=='__main__':main()
