"""Fast, deterministic EEVEE atmosphere for Harmony Core animation.

The beauty scene keeps the original volumetric objects. This optional animation
preset substitutes three camera-facing procedural nebula cards, avoiding costly
software-rasterized volume integration. All pixels are rendered by Blender.

Usage after harmony_core_build.apply_look(scene, style, palette):
    from harmony_realtime import set_realtime_atmosphere
    set_realtime_atmosphere(scene, palette, enabled=True, style=style)

Call with enabled=False to restore the original volume visibility. Existing
object and material names stay intact; new objects belong to Designer.
"""
import math, json
import bpy
from mathutils import Vector, Quaternion
import harmony_scene_tools as T

CARD_NAMES = ('AtmosphereDepth', 'AtmosphereFilaments', 'AtmosphereKnots')
MATERIAL_NAMES = tuple('M_' + name for name in CARD_NAMES)
BLACK = (0.0, 0.0, 0.0, 1.0)


def _palette(palette):
    return T.PALETTES[palette].copy() if isinstance(palette, str) else dict(palette)


def _collection(scene):
    c = bpy.data.collections.get('Designer') or bpy.data.collections.new('Designer')
    if c.name not in scene.collection.children:
        scene.collection.children.link(c)
    return c


def _card(scene, name, half_width, depth, roll):
    ob = bpy.data.objects.get(name)
    if ob is None:
        me = bpy.data.meshes.new(name)
        me.from_pydata([(-half_width,-half_width,0),(half_width,-half_width,0),
                       (half_width,half_width,0),(-half_width,half_width,0)], [],
                      [(0,1,2,3)])
        me.update()
        ob = bpy.data.objects.new(name, me)
        _collection(scene).objects.link(ob)
    # Local XY lies parallel to the 8-degree orthographic image plane.
    tilt = math.radians(82.0)
    ob.rotation_mode = 'QUATERNION'
    ob.rotation_quaternion = Quaternion((1,0,0),tilt) @ Quaternion((0,0,1),roll)
    ob.location = Vector((0,math.cos(math.radians(8)),-math.sin(math.radians(8)))) * depth
    ob.visible_shadow = False
    ob['HarmonyPurpose'] = 'Procedural realtime atmosphere; seamless 120-frame loop'
    return ob


def _noise(g, p, scale, radius, detail, distortion, phase):
    # Phase is constant per card. Every time-dependent term completes one full
    # circle; frame 121 is mathematically equivalent to frame 1.
    angle = g.math('ADD',g.math('MULTIPLY',g.t(),2*math.pi),phase)
    cs = g.math('COSINE',angle)
    sn = g.math('SINE',angle)
    offset = g.n('ShaderNodeCombineXYZ')
    g.put(offset.inputs[1],g.math('MULTIPLY',sn,radius/scale))
    vec = g.vmath('ADD',p,offset.outputs[0])
    return g.noise4d(vec,g.math('MULTIPLY',cs,radius),scale,
                     detail=detail,rough=.63,distortion=distortion)[0]


def _material(name, pal, index, emission_multiplier):
    m = T.new_mat(name,'BLENDED')
    m.use_backface_culling = False
    g = T.G(m)
    p = g.texco('Object')
    aspect = ((1.00,1.19,1),(.99,1.12,1),(1.03,1.17,1))[index]
    r = g.vmath('LENGTH',g.vmath('MULTIPLY',p,aspect))
    outer = g.maprange(r,(2.78,2.67,2.58)[index],(1.30,1.45,1.40)[index])
    inner = g.maprange(r,(.77,.91,1.01)[index],(1.19,1.31,1.37)[index])
    envelope = g.math('MULTIPLY',outer,inner,name='AtmosphereEnvelope')

    # Two complementary spatial frequencies produce wisps separated by dark
    # dust lanes. Only two 4D noises are needed per card.
    phase = (0.0,2.0943951024,4.1887902048)[index]
    broad = _noise(g,p,(.68,.87,.74)[index],(.23,.20,.19)[index],
                   (3,3,2)[index],(.85,1.15,.67)[index],phase)
    fine = _noise(g,p,(1.62,2.04,1.55)[index],.13,2,.35,phase+.63)
    ridge = g.maprange(broad,(.39,.43,.49)[index],(.73,.70,.69)[index],smooth=False)
    ridge = g.math('POWER',ridge,(1.75,2.15,2.9)[index])
    lanes = g.maprange(fine,.30,.60,.035,1)
    density = g.math('MULTIPLY',g.math('MULTIPLY',ridge,lanes),envelope)

    neb = T.rgba(pal['neb'])
    cool = T.rgba(pal['accent2'])
    warm = T.rgba(pal['accent'])
    # Darkened token mixes preserve spectral separation without white haze.
    stops = [(.22,T.mix(neb,BLACK,.42)),(.43,neb),
             (.57,T.mix(cool,neb,.20)),(.70,T.mix(warm,cool,.12))]
    if index == 2:
        stops = [(.30,T.mix(neb,BLACK,.25)),(.47,T.mix(neb,cool,.35)),
                 (.57,cool),(.67,T.mix(warm,cool,.14))]
    color = g.ramp(fine,stops,interp='EASE',name='NebRamp')
    strength = g.math('MULTIPLY',density,(.30,.34,.38)[index]*emission_multiplier,
                      name='NebEmit')
    g.out(surface=g.additive(color,strength))
    m['HarmonyPaletteTokens'] = json.dumps(pal,sort_keys=True)
    m['HarmonyShaderLoop'] = 'Circular 4D noise, one integer cycle / 120 frames'
    return m


def set_realtime_atmosphere(scene, palette='midnight', enabled=True, style='calm'):
    """Enable/disable the fast atmosphere without touching saved beauty settings.

    `palette` may be a palette name or token dictionary. The ivory/friendly
    multipliers match the main scene. Repeated calls reuse object identities.
    """
    pal = _palette(palette)
    multiplier = (.4 if isinstance(palette,str) and palette=='ivory' else 1.0)
    if pal['bg'].upper() == T.PALETTES['ivory']['bg']:
        multiplier = .4
    if style == 'friendly':
        multiplier *= .5

    for name in ('Nebula','Plasma'):
        ob = bpy.data.objects.get(name)
        if ob is None:
            continue
        if enabled:
            if '_HarmonyBeautyHideRender' not in ob:
                ob['_HarmonyBeautyHideRender'] = ob.hide_render
                ob['_HarmonyBeautyHideViewport'] = ob.hide_viewport
            ob.hide_render = ob.hide_viewport = True
        else:
            ob.hide_render = bool(ob.get('_HarmonyBeautyHideRender',False))
            ob.hide_viewport = bool(ob.get('_HarmonyBeautyHideViewport',False))

    if enabled:
        for i,name in enumerate(CARD_NAMES):
            ob = _card(scene,name,2.90,(3.0,2.84,2.69)[i],
                       math.radians((17,-24,51)[i]))
            m = _material(MATERIAL_NAMES[i],pal,i,multiplier)
            ob.data.materials.clear()
            ob.data.materials.append(m)
            ob.hide_render = ob.hide_viewport = False
    else:
        for name in CARD_NAMES:
            ob = bpy.data.objects.get(name)
            if ob:
                ob.hide_render = ob.hide_viewport = True
    scene['HarmonyAtmospherePreset'] = 'realtime-cards' if enabled else 'beauty-volumes'
    return tuple(bpy.data.objects.get(n) for n in CARD_NAMES)


# Short alias for batch render scripts.
enable = set_realtime_atmosphere
