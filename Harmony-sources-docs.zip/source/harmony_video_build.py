#!/usr/bin/env python3
"""Build opaque Harmony review loops from the actual 512 px RGBA frame sets.

Every on-background PNG is composited and written by Blender in scene-linear
light. FFmpeg only encodes those completed RGB frames as H.264; it performs no
scaling, recoloring, or compositing. A four-second 120-frame loop is repeated
once for an eight-second, 240-frame review movie at 30 fps.

Run only after the requested input sequences contain all 120 complete frames:

    python harmony_video_build.py --styles calm
    blender --background --python harmony_video_build.py -- --styles calm

Requires Blender 5.2 / its bpy package, harmony_review_build.py, and FFmpeg.
``--mode check`` inventories real inputs without importing Blender or rendering.
Use ``--styles calm tech friendly --palettes midnight`` for the three UI loops.
Other palette movies can be requested explicitly. Inputs and output paths stay
relative to the handoff; temporary frames use the operating system's temp directory.
"""
from __future__ import annotations

import argparse
from array import array
from datetime import datetime, timezone
from fractions import Fraction
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

os.environ.setdefault('MESA_SHADER_CACHE_DIR', str(Path(tempfile.gettempdir()) / 'harmony-mesa-cache'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(tempfile.gettempdir()) / 'harmony-cache'))
SOURCE = Path(__file__).resolve().parent
ROOT = SOURCE.parent
sys.path.insert(0, str(SOURCE))
STYLES = ('calm', 'tech', 'friendly')
PALETTES = ('midnight', 'aurora', 'ocean', 'ember', 'ivory')
FRAMES = 120
FPS = 30
REPEAT = 2
SIZE = (512, 512)


def input_sequence(root, style, palette):
    directory = root / 'orb' / f'{style}_{palette}_512'
    return [directory / f'orb_{frame:04d}.png' for frame in range(1, FRAMES + 1)]


def missing_inputs(root, styles, palettes):
    return [str(path.relative_to(root))
            for style in styles for palette in palettes
            for path in input_sequence(root, style, palette)
            if not path.is_file() or path.stat().st_size < 100]


def movie_path(root, style, palette):
    name = ('orb_loop_preview.mp4' if style == 'calm' and palette == 'midnight'
            else f'{style}_{palette}.mp4')
    return root / 'loop_check' / name


def temp_directory(base, style, palette):
    return base / (style if palette == 'midnight' else f'{style}_{palette}')


def image_difference(bpy, first, second):
    """Read native image pixels for QA; never draw or edit source pixels."""
    images = []
    try:
        for path in (first, second):
            image = bpy.data.images.load(str(path), check_existing=False)
            images.append(image)
            if tuple(image.size) != SIZE:
                raise ValueError(f'{path}: expected native {SIZE}, got {tuple(image.size)}')
        a = array('f', [0.0]) * len(images[0].pixels)
        b = array('f', [0.0]) * len(images[1].pixels)
        images[0].pixels.foreach_get(a)
        images[1].pixels.foreach_get(b)
        differences = [abs(x - y) for x, y in zip(a, b)]
        maximum = max(differences)
        changed = sum(value > 1e-6 for value in differences)
        if not changed:
            raise ValueError(f'Frames 1 and 2 are pixel-identical: {first.parent}')
        return {'changed_channel_samples': changed, 'maximum_channel_difference': maximum}
    finally:
        for image in images:
            bpy.data.images.remove(image)


def composite_frames(root, style, palette, directory):
    import bpy
    from harmony_review_build import _scene, ReviewGraph, PALETTE_BG

    source = input_sequence(root, style, palette)
    source_difference = image_difference(bpy, source[0], source[1])
    # _scene creates an independent empty Blender scene and the native 5.2
    # compositor group. No production blend file is opened or saved.
    scene, group = _scene()
    scene.name = f'Harmony {style} {palette} movie compositor'
    render = scene.render
    render.resolution_x, render.resolution_y = SIZE
    render.resolution_percentage = 100
    render.fps = FPS
    render.fps_base = 1
    render.film_transparent = False
    render.image_settings.file_format = 'PNG'
    render.image_settings.color_mode = 'RGB'
    render.image_settings.color_depth = '8'
    render.image_settings.compression = 30
    render.use_file_extension = True
    render.use_compositing = True
    render.threads_mode = 'FIXED'
    render.threads = max(1, int(os.environ.get('HARMONY_VIDEO_THREADS', '2')))
    render.compositor_device = 'CPU'
    scene.eevee.taa_render_samples = 4
    scene.frame_start, scene.frame_end = 1, FRAMES
    directory.mkdir(parents=True, exist_ok=True)
    render.filepath = str(directory / 'frame_')

    graph = ReviewGraph(scene, group, root)
    foreground = graph.image(source[0], size=SIZE)
    node = foreground.node
    node.image.source = 'SEQUENCE'
    # Source filenames already enumerate orb_0001.png … orb_0120.png. Frame
    # start 1 and zero offset keep scene frame N mapped to source frame N.
    # Blender 5.2 moved sequence timing onto the Image node itself.
    # Older supported compositor APIs expose the same fields via image_user.
    user = getattr(node, 'image_user', node)
    user.frame_start = 1
    user.frame_offset = 0
    user.frame_duration = FRAMES
    user.use_auto_refresh = True
    user.use_cyclic = False
    composite = graph.over(foreground, PALETTE_BG[palette])
    output = group.nodes.new('NodeGroupOutput')
    group.links.new(composite, output.inputs[0])
    scene.frame_set(1)
    started = time.perf_counter()
    print(f'BLENDER_COMPOSITE: {style}/{palette}, {FRAMES} native {SIZE[0]}px frames', flush=True)
    bpy.ops.render.render(scene=scene.name, animation=True)
    elapsed = time.perf_counter() - started

    outputs = [directory / f'frame_{frame:04d}.png' for frame in range(1, FRAMES + 1)]
    missing = [str(path) for path in outputs if not path.is_file() or path.stat().st_size < 100]
    if missing:
        raise FileNotFoundError('Blender compositor outputs are incomplete: ' + '\n'.join(missing))
    extra = set(directory.glob('frame_*.png')) - set(outputs)
    if extra:
        raise ValueError('Unexpected extra movie frames in temporary directory: ' + ', '.join(str(p) for p in sorted(extra)))
    output_difference = image_difference(bpy, outputs[0], outputs[1])
    # The changing first two outputs prove that Image User refreshed the
    # sequence rather than compositing the same still 120 times.
    return {'blender': bpy.app.version_string, 'compositor_device': 'CPU',
            'source_first_two_difference': source_difference,
            'output_first_two_difference': output_difference,
            'composited_frames': len(outputs), 'compositor_seconds': round(elapsed, 3)}


def probe_movie(path):
    ffprobe = shutil.which('ffprobe')
    if not ffprobe:
        raise RuntimeError('ffprobe is required to verify the encoded movie')
    result = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'v:0',
                             '-show_entries',
                             'stream=width,height,codec_name,pix_fmt,avg_frame_rate,nb_frames:format=duration',
                             '-of', 'json', str(path)], capture_output=True, text=True,
                            timeout=30, check=True)
    data = json.loads(result.stdout)
    stream = data['streams'][0]
    result = {'width': stream['width'], 'height': stream['height'],
              'codec': stream['codec_name'], 'pixel_format': stream['pix_fmt'],
              'fps': float(Fraction(stream['avg_frame_rate'])),
              'frames': int(stream.get('nb_frames', 0)),
              'duration': float(data['format']['duration'])}
    if (result['width'], result['height']) != SIZE:
        raise ValueError(f'{path}: movie dimensions changed during encoding')
    if result['fps'] != FPS or result['frames'] != FRAMES * REPEAT:
        raise ValueError(f'{path}: expected 30 fps / 240 frames, got {result}')
    if abs(result['duration'] - FRAMES * REPEAT / FPS) > .03:
        raise ValueError(f'{path}: expected eight seconds, got {result["duration"]}')
    if result['codec'] != 'h264' or result['pixel_format'] != 'yuv420p':
        raise ValueError(f'{path}: expected browser-compatible H.264 / yuv420p')
    return result


def encode_frames(directory, target):
    ffmpeg = shutil.which('ffmpeg')
    if not ffmpeg:
        raise RuntimeError('FFmpeg is required to encode the Blender-composited RGB frames')
    inputs = [directory / f'frame_{frame:04d}.png' for frame in range(1, FRAMES + 1)]
    missing = [str(path) for path in inputs if not path.is_file() or path.stat().st_size < 100]
    if missing:
        raise FileNotFoundError('Composited inputs are incomplete: ' + '\n'.join(missing))
    extra = set(directory.glob('frame_*.png')) - set(inputs)
    if extra:
        raise ValueError('Encoding requires exactly 120 composited frames; unexpected files: ' + ', '.join(str(p) for p in sorted(extra)))
    target.parent.mkdir(parents=True, exist_ok=True)
    # Encode one extra playback of the exact 120-frame source. There is no
    # scale/filter/composite operation in FFmpeg; Blender authored every pixel.
    temporary_target = target.with_name(target.stem + '.encoding.mp4')
    command = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'warning',
               '-stream_loop', str(REPEAT - 1), '-framerate', str(FPS),
               '-start_number', '1', '-i', str(directory / 'frame_%04d.png'),
               '-frames:v', str(FRAMES * REPEAT), '-t', str(FRAMES * REPEAT / FPS),
               '-an', '-c:v', 'libx264', '-preset', 'medium', '-crf', '18',
               '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(temporary_target)]
    print('ENCODE: ' + str(target), flush=True)
    started = time.perf_counter()
    try:
        subprocess.run(command, check=True, timeout=180)
        result = probe_movie(temporary_target)
        temporary_target.replace(target)
    except Exception:
        temporary_target.unlink(missing_ok=True)
        raise
    result['encoding_seconds'] = round(time.perf_counter() - started, 3)
    result['bytes'] = target.stat().st_size
    return result


def main():
    argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--styles', nargs='+', choices=STYLES, default=list(STYLES))
    parser.add_argument('--palettes', nargs='+', choices=PALETTES, default=['midnight'])
    parser.add_argument('--temp-root', type=Path, default=Path(tempfile.gettempdir()) / 'harmony-movie-frames')
    parser.add_argument('--wait-inputs', type=float, default=0,
                        help='Seconds to wait for the requested actual 120-frame sequences')
    parser.add_argument('--mode', choices=('check', 'render', 'encode', 'all'), default='all')
    args = parser.parse_args(argv)
    root = args.root.resolve()
    missing = missing_inputs(root, args.styles, args.palettes)
    deadline = time.monotonic() + args.wait_inputs
    while missing and time.monotonic() < deadline:
        print(f'WAITING_INPUTS: {len(missing)} actual frames remain', flush=True)
        time.sleep(min(15, max(0, deadline - time.monotonic())))
        missing = missing_inputs(root, args.styles, args.palettes)
    if missing:
        print(json.dumps({'status': 'waiting_for_rendered_inputs',
                          'missing_frames': len(missing), 'missing_paths': missing}, indent=2), flush=True)
        return 2
    if args.mode == 'check':
        print(json.dumps({'status': 'inputs_ready', 'styles': args.styles,
                          'palettes': args.palettes, 'frames_per_sequence': FRAMES}, indent=2))
        return 0
    if args.mode in ('encode', 'all') and (not shutil.which('ffmpeg') or not shutil.which('ffprobe')):
        raise RuntimeError('FFmpeg and ffprobe must be available before encoding')
    report_path = root / 'audit/video-build.json'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        report = json.loads(report_path.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        report = {'renderer': 'Blender scene-linear CPU compositor; FFmpeg H.264 encode only',
                  'outputs': []}
    for style in args.styles:
        for palette in args.palettes:
            directory = temp_directory(args.temp_root, style, palette)
            entry = {'style': style, 'palette': palette,
                     'checked_at_utc': datetime.now(timezone.utc).isoformat(),
                     'source_sequence': f'orb/{style}_{palette}_512/orb_####.png',
                     'on_background_frames': str(directory),
                     'source_loop_frames': FRAMES, 'source_fps': FPS,
                     'playbacks': REPEAT}
            if args.mode in ('render', 'all'):
                entry.update(composite_frames(root, style, palette, directory))
            if args.mode in ('encode', 'all'):
                target = movie_path(root, style, palette)
                entry['path'] = str(target.relative_to(root))
                entry['movie'] = encode_frames(directory, target)
            report['outputs'] = [old for old in report['outputs']
                                 if (old['style'], old['palette']) != (style, palette)] + [entry]
            report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'complete', 'mode': args.mode,
                      'outputs': len(args.styles) * len(args.palettes),
                      'report': str(report_path)}, indent=2))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print(json.dumps({'status': 'failed', 'error': f'{type(error).__name__}: {error}'}, indent=2), file=sys.stderr)
        sys.exit(1)
