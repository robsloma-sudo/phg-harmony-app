"""Harmony Core • polished, deterministic Blender 5.2 LTS scene and renderer.

Run with Blender --background --python this_file -- --mode previews
or with the Blender bpy Python package. All paths are relative to this package.
The included original blend is a read-only seed, preserving the approved geometry.
"""
import os, tempfile
from pathlib import Path
os.environ.setdefault('MESA_SHADER_CACHE_DIR', str(Path(tempfile.gettempdir()) / 'harmony-mesa-cache'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(tempfile.gettempdir()) / 'harmony-cache'))
import bpy, math, sys, json, time, argparse
from mathutils import Vector
sys.path.insert(0, str(Path(__file__).resolve().parent))
import harmony_scene_tools as T

ROOT = Path(__file__).resolve().parents[1]
FRAMES = 120
PALETTES = T.PALETTES
STYLES = ('calm','tech','friendly')
WHITE = T.WHITE
G, rgba, mix = T.G, T.rgba, T.mix
SETTINGS = {
    'shell': {'roughness':.18,'coat':.85,'vein_scale':1.85,'vein_detail':3,'vein_distortion':.65,'base_emission':.30,'vein_emission':.34,'rim_strength':.58,'center_alpha':.28,'rim_alpha':.90},
    'nucleus': {'radius':.145,'distance':.285,'roughness':.16,'metallic':.24,'emission_base':.18,'emission_center_add':.62},
    'nebula': {'density':.16,'emission':1.15,'scale':.72,'detail':4,'outer_fade':2.90},
    'plasma': {'density':.15,'emission':.22},
    'synapses': {'quiet_base':.18,'hero_base':.42,'quiet_pulse':1.1,'hero_pulse':2.3,'cycles':2,'fade_end':3.05},
    'stars': {'count':380,'base':.10,'peak':1.10},
    'bloom': {'threshold':.90,'strength':.26,'size':.40},
}

def shell(pal, style='calm', emis=1):
    acc,acc2,bg=rgba(pal['accent']),rgba(pal['accent2']),rgba(pal['bg'])
    m=T.new_mat('M_Shell','BLENDED');g=G(m)
    n=g.vmath('NORMALIZE',g.texco('Object'))
    dr=Vector((-.5,-.55,.68)).normalized()
    t=g.math('MULTIPLY_ADD',g.vmath('DOT_PRODUCT',n,dr),.5,.5)
    col=g.ramp(t,[(.20,mix(acc,bg,.70)),(.57,acc),(.88,acc2),(1,mix(acc2,WHITE,.08))],name='Ramp')
    lw=g.n('ShaderNodeLayerWeight');lw.inputs['Blend'].default_value=.35
    f=lw.outputs['Facing']
    nf,_=g.looped_noise(g.texco('Object'),1.85,radius=.45,detail=3,rough=.52,distortion=.65)
    veins=g.maprange(g.math('ABSOLUTE',g.math('SUBTRACT',nf,.50)),.006,.027,1,0)
    bs=g.n('ShaderNodeBsdfPrincipled','BSDF')
    bs.inputs['Roughness'].default_value=.6 if style=='friendly' else .18
    bs.inputs['Metallic'].default_value=.08
    bs.inputs['Coat Weight'].default_value=.16 if style=='friendly' else .85
    bs.inputs['Coat Roughness'].default_value=.06
    g.put(bs.inputs['Base Color'],col);g.put(bs.inputs['Emission Color'],col)
    g.put(bs.inputs['Emission Strength'],g.math('MULTIPLY_ADD',veins,.34*emis,.30*emis,name='ShellEmit'))
    rim=g.emission(acc2,g.math('MULTIPLY',g.math('POWER',f,3.2),.58*emis,name='RimStrength'))
    add=g.n('ShaderNodeAddShader');g.L.new(bs.outputs[0],add.inputs[0]);g.L.new(rim,add.inputs[1])
    alpha=g.math('MULTIPLY_ADD',g.math('POWER',f,1.65),.62,.28,name='ShellAlpha')
    mx=g.n('ShaderNodeMixShader');g.put(mx.inputs[0],alpha)
    g.L.new(g.n('ShaderNodeBsdfTransparent').outputs[0],mx.inputs[1]);g.L.new(add.outputs[0],mx.inputs[2]);g.out(surface=mx.outputs[0])
    return m

def jewel(name,color,emis):
    m=T.new_mat(name,'DITHERED');g=G(m)
    lw=g.n('ShaderNodeLayerWeight');lw.inputs['Blend'].default_value=.4
    facing=lw.outputs['Facing']
    shade=g.math('MULTIPLY_ADD',g.math('SUBTRACT',1,facing),.56,.44)
    base=g.mixc(shade,mix(color,(0,0,0,1),.68),color)
    bs=g.n('ShaderNodeBsdfPrincipled','BSDF');g.put(bs.inputs['Base Color'],base)
    bs.inputs['Roughness'].default_value=.16;bs.inputs['Metallic'].default_value=.24
    bs.inputs['Coat Weight'].default_value=1;bs.inputs['Coat Roughness'].default_value=.035
    bs.inputs['Subsurface Weight'].default_value=.04
    g.put(bs.inputs['Emission Color'],color)
    g.put(bs.inputs['Emission Strength'],g.math('MULTIPLY',g.math('MULTIPLY_ADD',g.math('SUBTRACT',1,facing),.62,.18),emis,name='Strength'))
    g.out(surface=bs.outputs[0]);return m

def plasma(pal,emis):
    m=T.new_mat('M_Plasma');g=G(m);p=g.texco('Object');r=g.vmath('LENGTH',p)
    nf,_=g.looped_noise(p,2.1,radius=.6,detail=3,rough=.55,distortion=.7)
    dens=g.math('MULTIPLY',g.maprange(nf,.52,.76),g.maprange(r,.91,.40))
    col=g.ramp(nf,[(.4,rgba(pal['accent2'])),(.70,rgba(pal['accent']))])
    v=g.n('ShaderNodeVolumePrincipled');g.put(v.inputs['Density'],g.math('MULTIPLY',dens,.15))
    g.put(v.inputs['Color'],col);g.put(v.inputs['Emission Color'],col)
    g.put(v.inputs['Emission Strength'],g.math('MULTIPLY',dens,.22*emis,name='PlasmaEmit'))
    g.out(volume=v.outputs[0]);return m

def nebula(pal,emis):
    m=T.new_mat('M_Nebula');g=G(m);p=g.worldpos()
    r=g.vmath('LENGTH',g.vmath('MULTIPLY',p,(1.02,.95,1.14)))
    mask=g.math('MULTIPLY',g.maprange(r,2.90,1.55),g.maprange(r,1.05,1.48))
    nf,_=g.looped_noise(p,.72,radius=.24,detail=4,rough=.62,distortion=.75)
    dust,_=g.looped_noise(p,1.1,radius=.24,detail=2,rough=.55,distortion=.25)
    wisps=g.math('POWER',g.maprange(nf,.46,.72,0,1,smooth=False),1.8)
    lanes=g.maprange(dust,.30,.56,.1,1)
    dens=g.math('MULTIPLY',g.math('MULTIPLY',wisps,lanes),mask)
    cf,_=g.looped_noise(p,.60,radius=.25,detail=2,rough=.55)
    col=g.ramp(cf,[(.30,mix(rgba(pal['neb']),rgba(pal['bg']),.40)),(.47,rgba(pal['neb'])),(.63,rgba(pal['accent2'])),(.76,rgba(pal['accent']))],name='NebRamp')
    v=g.n('ShaderNodeVolumePrincipled');g.put(v.inputs['Density'],g.math('MULTIPLY',dens,.16,name='NebDensity'))
    g.put(v.inputs['Color'],col);v.inputs['Anisotropy'].default_value=.20
    g.put(v.inputs['Emission Color'],col);g.put(v.inputs['Emission Strength'],g.math('MULTIPLY',dens,1.15*emis,name='NebEmit'))
    g.out(volume=v.outputs[0]);return m

def ink(g,color,strength,opacity):
    """Light-theme pigment has coverage independent of emitted brightness."""
    mx=g.n('ShaderNodeMixShader');g.put(mx.inputs[0],opacity)
    g.L.new(g.n('ShaderNodeBsdfTransparent').outputs[0],mx.inputs[1]);g.L.new(g.emission(color,strength),mx.inputs[2])
    return mx.outputs[0]

def synapse(pal,emis):
    m=T.new_mat('M_Synapse');g=G(m);u,v,_=g.uv()
    hero=g.math('LESS_THAN',v,.26)
    x=g.math('FRACT',g.math('ADD',g.math('SUBTRACT',g.math('MULTIPLY',u,.55),g.math('MULTIPLY',g.t(),2)),v))
    pulse=g.math('POWER',g.maprange(x,.73,1,0,1,smooth=False),3.5)
    fade=g.maprange(g.vmath('LENGTH',g.worldpos()),3.05,1.30)
    col=g.mixc(pulse,rgba(pal['accent2']),mix(rgba(pal['accent']),WHITE,.08))
    amp=g.math('MULTIPLY_ADD',hero,1.2,1.1);base=g.math('MULTIPLY_ADD',hero,.24,.18)
    strength=g.math('MULTIPLY',g.math('ADD',g.math('MULTIPLY',pulse,amp),base),g.math('MULTIPLY',fade,emis),name='SynStrength')
    strength=back_mask(g,strength)
    surface=ink(g,col,g.math('MAXIMUM',strength,.30),g.math('MULTIPLY',fade,g.math('MULTIPLY_ADD',pulse,.44,.20))) if pal['bg']=='#F6F2EA' else g.additive(col,strength)
    g.out(surface=surface);return m

def trail(name,color,n,a0,direction,emis,dashes=0,tail=.44,paint=False):
    m=T.new_mat(name);g=G(m);grad=g.n('ShaderNodeTexGradient',gradient_type='RADIAL');g.put(grad.inputs[0],g.texco('Object'))
    a=grad.outputs['Fac'];ae=a0/360+.5
    diff=g.math('SUBTRACT',ae,a) if direction>0 else g.math('SUBTRACT',a,ae)
    x=g.math('FRACT',g.math('MULTIPLY',diff,n));tl=g.math('POWER',g.maprange(x,0,tail,1,0,smooth=False),2.8)
    base=.10
    if dashes:base=g.math('MULTIPLY',g.math('LESS_THAN',g.math('FRACT',g.math('MULTIPLY',a,dashes)),.55),.16)
    st=g.math('MULTIPLY',g.math('MULTIPLY_ADD',tl,1.4,base),emis,name='TrailStrength')
    surface=ink(g,color,g.math('MAXIMUM',st,.4),back_mask(g,g.math('MULTIPLY_ADD',tl,.50,.38))) if paint else g.additive(color,back_mask(g,st))
    g.out(surface=surface);return m

def back_mask(g,strength):
    """Hide far-side filaments inside the projected shell silhouette.
    This preserves atom occlusion while allowing a transparent front shell.
    """
    p=g.sep(g.worldpos())
    z=g.math('ADD',g.math('MULTIPLY',p[2],math.cos(math.radians(8))),g.math('MULTIPLY',p[1],math.sin(math.radians(8))))
    r=g.math('SQRT',g.math('ADD',g.math('MULTIPLY',p[0],p[0]),g.math('MULTIPLY',z,z)))
    disk=g.maprange(r,1.03,.94)
    rear=g.maprange(p[1],-.05,.24)
    mask=g.math('SUBTRACT',1,g.math('MULTIPLY',disk,rear))
    return g.math('MULTIPLY',strength,mask)

def electron(name,color,strength,paint=False):
    m=T.new_mat(name);g=G(m);st=g.value(strength,'Strength')
    g.out(surface=ink(g,color,st,back_mask(g,.88)) if paint else g.additive(color,back_mask(g,st)));return m

def stars(pal,emis):
    m=T.new_mat('M_Stars');g=G(m);u,v,_=g.uv()
    ang=g.math('MULTIPLY',g.math('ADD',g.math('MULTIPLY',g.t(),3),v),2*math.pi)
    tw=g.math('POWER',g.math('MULTIPLY_ADD',g.math('SINE',ang),.5,.5),4)
    col=g.ramp(u,[(0,mix(rgba(pal['accent2']),WHITE,.18)),(.65,rgba(pal['accent2'])),(.86,rgba(pal['accent']))],interp='CONSTANT')
    fade=g.maprange(g.vmath('LENGTH',g.worldpos()),3.15,2.0)
    st=g.math('MULTIPLY',g.math('MULTIPLY_ADD',tw,1.1,.10),g.math('MULTIPLY',fade,emis),name='StarStrength')
    g.out(surface=g.additive(col,st));return m

def designer_collection(scene):
    c=bpy.data.collections.get('Designer') or bpy.data.collections.new('Designer')
    if c.name not in scene.collection.children:scene.collection.children.link(c)
    return c

def shadow_material(pal):
    m=T.new_mat('M_IvoryShadow');g=G(m);p=g.texco('Generated');xyz=g.sep(p)
    dx=g.math('SUBTRACT',xyz[0],.5);dy=g.math('SUBTRACT',xyz[2],.5)
    r=g.math('SQRT',g.math('ADD',g.math('MULTIPLY',dx,dx),g.math('MULTIPLY',dy,dy)))
    alpha=g.math('MULTIPLY',g.maprange(r,.48,.08,0,1),.12)
    mx=g.n('ShaderNodeMixShader');g.put(mx.inputs[0],alpha)
    g.L.new(g.n('ShaderNodeBsdfTransparent').outputs[0],mx.inputs[1]);g.L.new(g.emission(rgba(pal['accent']),1),mx.inputs[2]);g.out(surface=mx.outputs[0]);return m

def load_seed():
    bpy.ops.wm.open_mainfile(filepath=str(ROOT/'reference/harmony_assets-original.blend'),use_scripts=False)
    s=bpy.data.scenes['Orb'];s.frame_set(1)
    s.render.threads_mode='FIXED';s.render.threads=4
    s.render.compositor_device=os.environ.get('HARMONY_COMPOSITOR_DEVICE','CPU')
    s.render.image_settings.compression=30
    s.render.use_file_extension=True
    s.render.resolution_percentage=100
    # Original geometry and object identities remain intact.
    for i in range(13):
        o=bpy.data.objects[f'Nucleon{i:02d}'];o.scale=(.145/.13,)*3
        if o.location.length:o.location=o.location.normalized()*.285
    # Fewer dust points preserve the orb silhouette at 128px.
    old=bpy.data.objects['StarDust'];tmp=T.build_stars(s,n=380)
    mesh=tmp.data;old.data=mesh;bpy.data.objects.remove(tmp,do_unlink=True);mesh.name='StarDust'
    c=designer_collection(s)
    ld=bpy.data.lights.new('NucleusSoftbox','AREA');ld.energy=160;ld.shape='DISK';ld.size=.85
    ob=bpy.data.objects.new('NucleusSoftbox',ld);c.objects.link(ob);ob.location=(-1.2,-3.8,1.9);T.look_at(ob)
    # Optional tech overlay is geometry, with a material following palette tokens.
    sh=bpy.data.objects['Shell'];vv,ff=T.ico_template(3);me=bpy.data.meshes.new('TechWire');me.from_pydata(vv,[],ff);me.update();wire=bpy.data.objects.new('TechWire',me);c.objects.link(wire);wire.parent=sh.parent;wire.scale=(1.003,)*3
    mod=wire.modifiers.new('Precision lattice','WIREFRAME');mod.thickness=.0011;mod.use_replace=True
    # Twenty-four restrained tick marks make the tech orbit read as an instrument.
    vv,ff=[],[]
    for k in range(24):
        a=2*math.pi*k/24;radial=Vector((math.cos(a),math.sin(a),0));tangent=Vector((-math.sin(a),math.cos(a),0))
        base=len(vv)
        for rr,tt in [(2.265,-.003),(2.335,-.003),(2.335,.003),(2.265,.003)]:vv.append(tuple(radial*rr+tangent*tt))
        ff.append((base,base+1,base+2,base+3))
    me=bpy.data.meshes.new('TechTicks');me.from_pydata(vv,[],ff);me.update();ticks=bpy.data.objects.new('TechTicks',me);c.objects.link(ticks);ticks.parent=bpy.data.objects['SpinA'];ticks.visible_shadow=False
    # Palette-specific shadow remains completely inside the safe canvas.
    verts=[(-1.4,0,-1.4),(1.4,0,-1.4),(1.4,0,1.4),(-1.4,0,1.4)]
    me=bpy.data.meshes.new('IvoryShadow');me.from_pydata(verts,[],[(0,1,2,3)]);me.update()
    ob=bpy.data.objects.new('IvoryShadow',me);c.objects.link(ob);ob.location=(0,2,-.16)
    return s

def apply_look(s,style,palette,state=None):
    pal=PALETTES[palette].copy();emis=(.4 if palette=='ivory' else 1)*(.5 if style=='friendly' else 1)
    shellpal=pal.copy()
    if state:shellpal['accent']=state
    shell(shellpal,style,emis);plasma(shellpal,emis);nebula(pal,emis);synapse(pal,emis);stars(pal,emis)
    starob=bpy.data.objects['StarDust'];starob.data.materials.clear();starob.data.materials.append(bpy.data.materials['M_Stars'])
    jewel('M_Proton',rgba(pal['accent']),emis);jewel('M_Neutron',rgba(pal['accent2']),emis)
    acc,acc2=rgba(pal['accent']),rgba(pal['accent2'])
    for nm,n,a0,di,col,da in [('A',4,0,1,acc,0),('B',2,45,-1,acc2,64),('C',3,20,1,mix(acc,acc2,.35),0)]:
        trail('M_Trail'+nm,col,n,a0,di,emis,da,.22 if style=='tech' else .44,paint=palette=='ivory')
        electron('M_Electron'+nm,mix(col,WHITE,.025),1.05*emis,paint=palette=='ivory')
        ring=bpy.data.objects['Ring'+nm];ring.scale=(.8 if style=='tech' else 2.5 if style=='friendly' else 1,)*3
        # Scale cross-section only: keep orbit radii unchanged.
        ring.scale=(1,1,1)
        R={'A':2.3,'B':1.75,'C':2.7}[nm];th={'A':.008,'B':.007,'C':.006}[nm]*(.8 if style=='tech' else 2.5 if style=='friendly' else 1)
        oldmesh=ring.data;tmp=T.torus('_ring',s,R,th,parent=ring.parent);ring.data=tmp.data;bpy.data.objects.remove(tmp,do_unlink=True)
        if oldmesh.users==0:bpy.data.meshes.remove(oldmesh)
        ring.data.materials.append(bpy.data.materials['M_Trail'+nm])
        for ob in s.objects:
            if ob.name.startswith('Electron'+nm):ob.scale=(.85 if style=='tech' else 1.6 if style=='friendly' else 1,)*3
    T.key_linear(bpy.data.objects['SpinA'],'rotation_euler',2,0,math.radians(720 if style=='tech' else 360))
    bpy.data.objects['TechWire'].hide_render=style!='tech';bpy.data.objects['TechWire'].hide_viewport=style!='tech'
    wm=T.mat_glow('M_TechWire',acc,.16*emis);wire=bpy.data.objects['TechWire'];wire.data.materials.clear();wire.data.materials.append(wm)
    ticks=bpy.data.objects['TechTicks'];ticks.hide_render=ticks.hide_viewport=style!='tech';ticks.data.materials.clear();ticks.data.materials.append(T.mat_glow('M_TechTicks',acc,.28*emis))
    bpy.data.objects['IvoryShadow'].hide_render=palette!='ivory';bpy.data.objects['IvoryShadow'].hide_viewport=palette!='ivory'
    ob=bpy.data.objects['IvoryShadow'];ob.data.materials.clear();ob.data.materials.append(shadow_material(pal))
    bpy.data.lights['KeyLight'].energy=100;bpy.data.lights['KeyLight'].color=mix(acc,WHITE,.88)[:3]
    bpy.data.lights['RimLight'].energy=75;bpy.data.lights['RimLight'].color=acc2[:3]
    bpy.data.lights['CoreLight'].energy=28*emis;bpy.data.lights['CoreLight'].color=mix(acc,WHITE,.2)[:3]
    bpy.data.lights['NucleusSoftbox'].color=mix(acc2,WHITE,.55)[:3]
    s.world.node_tree.nodes['Background'].inputs['Color'].default_value=rgba(pal['panel'])
    s.world.node_tree.nodes['Background'].inputs['Strength'].default_value=.22
    ng=T.setup_bloom(s,strength=.025 if style=='friendly' else .38 if style=='tech' else .26,threshold=.90,size=.40)
    # Finite transparent margin after glare. Gate both RGB and alpha with a
    # softened 90% box; the glow-to-alpha maximum itself is preserved.
    N,L=ng.nodes,ng.links;go=next(n for n in N if n.type=='GROUP_OUTPUT');src=go.inputs[0].links[0].from_socket
    box=N.new('CompositorNodeBoxMask');box.inputs['Size'].default_value=(.89,.89)
    blur=N.new('CompositorNodeBlur');blur.inputs['Type'].default_value='Gaussian';blur.inputs['Size'].default_value=(18,18)
    L.new(box.outputs[0],blur.inputs[0])
    sep=N.new('CompositorNodeSeparateColor');L.new(src,sep.inputs[0]);cc=N.new('CompositorNodeCombineColor')
    for nm in ['Red','Green','Blue','Alpha']:
        mu=N.new('ShaderNodeMath');mu.operation='MULTIPLY';L.new(sep.outputs[nm],mu.inputs[0]);L.new(blur.outputs[0],mu.inputs[1]);L.new(mu.outputs[0],cc.inputs[nm])
    # Clear invisible RGB before PNG encoding; alpha remains the same maximum
    # coverage and finite feathered margin. This also makes thumbnails reliable.
    cleansep=N.new('CompositorNodeSeparateColor');L.new(cc.outputs[0],cleansep.inputs[0])
    visible=N.new('ShaderNodeMath');visible.operation='GREATER_THAN';L.new(cleansep.outputs['Alpha'],visible.inputs[0]);visible.inputs[1].default_value=.5/255
    clean=N.new('CompositorNodeCombineColor')
    for nm in ['Red','Green','Blue']:
        mu=N.new('ShaderNodeMath');mu.operation='MULTIPLY';L.new(cleansep.outputs[nm],mu.inputs[0]);L.new(visible.outputs[0],mu.inputs[1]);L.new(mu.outputs[0],clean.inputs[nm])
    L.new(cleansep.outputs['Alpha'],clean.inputs['Alpha']);L.new(clean.outputs[0],go.inputs[0])
    s['HarmonyLook']=style+'_'+palette;s['HarmonyPaletteTokens']=json.dumps(pal);s['HarmonyPolishSettings']=json.dumps(SETTINGS)
    s.frame_set(1)

def render(s,path,frame=1,size=1024):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    s.render.resolution_x=s.render.resolution_y=size;s.render.resolution_percentage=100;s.frame_set(frame);s.render.filepath=str(path)
    t=time.perf_counter();bpy.ops.render.render(write_still=True,scene=s.name)
    duration=time.perf_counter()-t
    with (ROOT/'audit/render-times.jsonl').open('a') as f:f.write(json.dumps({'path':str(path.relative_to(ROOT)),'frame':frame,'size':size,'seconds':round(duration,3),'look':s.get('HarmonyLook'),'blender':bpy.app.version_string})+'\n')
    print('RENDERED',path.name,round(duration,3),flush=True);return duration

def main():
    argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['build','previews','stills','loops','check'],default='previews');p.add_argument('--style',default='calm');p.add_argument('--palette',default='midnight');p.add_argument('--size',type=int,default=1024);p.add_argument('--start',type=int,default=1);p.add_argument('--end',type=int,default=120)
    args=p.parse_args(argv);s=load_seed();apply_look(s,args.style,args.palette)
    s.render.resolution_x=s.render.resolution_y=1024;s.frame_set(1)
    s.render.filepath=f'//../orb/{args.style}_{args.palette}_still.png'
    bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'source/harmony_assets.blend'),compress=True)
    if args.mode=='build':return
    if args.mode=='previews':
        for f in [1,30,45,60,90,120]:render(s,ROOT/f'previews/core_{args.style}_{args.palette}_f{f:03d}_transparent.png',f,args.size)
    elif args.mode=='stills':
        for style in STYLES:
            for pal in PALETTES:
                apply_look(s,style,pal);render(s,ROOT/f'orb/{style}_{pal}_still.png',1,args.size)
    elif args.mode=='loops':
        for f in range(args.start,args.end+1):render(s,ROOT/f'orb/{args.style}_{args.palette}{"_512" if args.size==512 else ""}/orb_{f:04d}.png',f,args.size)
    elif args.mode=='check':
        for f in [119,120,1,121]:render(s,ROOT/f'audit/loop_f{f:03d}.png',f,args.size)

if __name__=='__main__':main()
