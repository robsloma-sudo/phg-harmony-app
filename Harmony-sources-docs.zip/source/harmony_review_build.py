"""Blender 5.2 compositor-only review images for the Harmony delivery.

Run after native 1024 beauty renders are ready:
    blender --background --python harmony_review_build.py -- --mode review
or:
    python harmony_review_build.py --mode review

No asset pixels are drawn by Pillow or an external image generator. Blender
decodes the rendered PNGs, composites in linear light, scales, combines the
comparisons, and writes every review PNG through File Output nodes.
"""
import os,tempfile
from pathlib import Path
os.environ.setdefault('MESA_SHADER_CACHE_DIR',str(Path(tempfile.gettempdir()) / 'harmony-mesa-cache'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir()) / 'harmony-cache'))
import argparse, json, math, sys, time
from array import array
import bpy

ROOT = Path(__file__).resolve().parents[1]
PALETTE_BG = {'midnight':'#070B18','aurora':'#06110F','ocean':'#05101F',
              'ember':'#121012','ivory':'#F6F2EA'}
PREVIEW_FRAMES = (1,30,45,60,90,120)


def rgba(hex_color):
    h=hex_color.lstrip('#')
    rgb=[int(h[i:i+2],16)/255 for i in (0,2,4)]
    return tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in rgb)+(1.0,)


def _scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    s=bpy.context.scene;s.name='Harmony Review Compositor'
    s.render.engine='BLENDER_EEVEE'
    s.eevee.taa_render_samples=4
    s.render.threads_mode='FIXED';s.render.threads=4
    s.render.resolution_x=2048;s.render.resolution_y=1024
    s.render.resolution_percentage=100
    s.render.film_transparent=True
    s.render.image_settings.file_format='PNG'
    s.render.image_settings.color_mode='RGBA'
    s.render.image_settings.color_depth='8'
    if hasattr(s.render,'compositor_device'):
        s.render.compositor_device='CPU'
    s.view_settings.view_transform='Standard'
    s.view_settings.look='None'
    s.view_settings.exposure=0;s.view_settings.gamma=1
    cd=bpy.data.cameras.new('ReviewCam');cd.type='ORTHO';cd.ortho_scale=7.2
    cam=bpy.data.objects.new('ReviewCam',cd);s.collection.objects.link(cam)
    cam.location=(0,0,10);s.camera=cam
    nt=bpy.data.node_groups.new('Harmony Review Comp','CompositorNodeTree')
    nt.interface.new_socket('Image',in_out='OUTPUT',socket_type='NodeSocketColor')
    s.compositing_node_group=nt
    return s,nt


class ReviewGraph:
    def __init__(self,scene,nt,root):
        self.scene,self.nt,self.root=scene,nt,Path(root)
        self.N,self.L=nt.nodes,nt.links
        self.images={};self.outputs=[]

    def image(self,path,size=(1024,1024)):
        path=Path(path).resolve()
        if path in self.images:return self.images[path]
        im=bpy.data.images.load(str(path),check_existing=True)
        if tuple(im.size)!=size:
            raise ValueError(f'{path}: expected native {size}, got {tuple(im.size)}')
        # Blender image nodes deliver premultiplied scene-linear pixels. Keep
        # Straight Alpha disabled on Alpha Over to avoid multiplying twice.
        node=self.N.new('CompositorNodeImage');node.name=path.name;node.image=im
        self.images[path]=node.outputs['Image']
        return node.outputs['Image']

    def over(self,foreground,bg,background_socket=None):
        node=self.N.new('CompositorNodeAlphaOver')
        node.inputs['Type'].default_value='Over'
        node.inputs['Straight Alpha'].default_value=False
        node.inputs['Factor'].default_value=1
        if background_socket is None:node.inputs['Background'].default_value=rgba(bg)
        else:self.L.new(background_socket,node.inputs['Background'])
        self.L.new(foreground,node.inputs['Foreground'])
        return node.outputs['Image']

    def scale(self,image,width,height):
        node=self.N.new('CompositorNodeScale')
        node.inputs['Type'].default_value='Absolute'
        node.inputs['X'].default_value=width;node.inputs['Y'].default_value=height
        node.inputs['Interpolation'].default_value='Bicubic'
        self.L.new(image,node.inputs['Image'])
        return node.outputs['Image']

    def canvas(self,width,height,bg):
        # This blank Blender image only supplies the comparison's output domain.
        # The source assets remain Image-node inputs throughout the graph.
        color=rgba(bg)
        im=bpy.data.images.new(f'Comparison canvas {width}x{height}',width,height,
                               alpha=True,float_buffer=True)
        im.colorspace_settings.name='Linear Rec.709'
        im.pixels.foreach_set(array('f',color)*(width*height))
        im.update()
        node=self.N.new('CompositorNodeImage');node.image=im
        return node.outputs['Image']

    def translate(self,image,x,y=0):
        node=self.N.new('CompositorNodeTranslate')
        node.inputs['X'].default_value=x;node.inputs['Y'].default_value=y
        node.inputs['Interpolation'].default_value='Bicubic'
        self.L.new(image,node.inputs['Image'])
        return node.outputs['Image']

    def comparison(self,before,after):
        canvas=self.canvas(2048,1024,PALETTE_BG['midnight'])
        left=self.translate(before,-512)
        right=self.translate(after,512)
        combined=self.over(left,PALETTE_BG['midnight'],canvas)
        return self.over(right,PALETTE_BG['midnight'],combined)

    def output(self,image,relative_path,size):
        target=self.root/relative_path;target.parent.mkdir(parents=True,exist_ok=True)
        node=self.N.new('CompositorNodeOutputFile')
        node.name='Write '+str(relative_path)
        node.directory=str(target.parent)
        node.file_name=target.stem
        node.use_file_extension=True;node.save_as_render=True
        node.format.media_type='IMAGE';node.format.file_format='PNG'
        node.format.color_mode='RGBA';node.format.color_depth='8'
        node.format.compression=60
        node.file_output_items.new('RGBA','')
        self.L.new(image,node.inputs[0])
        self.outputs.append({'path':str(target),'size':list(size)})


def build_review(root=ROOT,original_previews=None,allow_partial=False):
    """Create the review compositor and return `(scene, output_records)`.

    Full review requires six native beauty frames, four native palette stills,
    and original on-background frames 1 and 45. No input is silently enlarged.
    `allow_partial=True` is useful for inspecting already completed inputs.
    """
    root=Path(root)
    original_previews=Path(original_previews) if original_previews else root/'reference/previews-original'
    paths={f:root/f'previews/core_calm_midnight_f{f:03d}_transparent.png' for f in PREVIEW_FRAMES}
    pals={p:root/f'orb/calm_{p}_still.png' for p in ('aurora','ocean','ember','ivory')}
    before={f:original_previews/f'core_calm_midnight_f{f:03d}_on-bg.png' for f in (1,45)}
    missing=[str(p) for p in list(paths.values())+list(pals.values())+list(before.values()) if not p.is_file()]
    if missing and not allow_partial:
        raise FileNotFoundError('Review inputs are not ready:\n'+'\n'.join(missing))
    s,nt=_scene();g=ReviewGraph(s,nt,root)
    first_output=None
    for frame,path in paths.items():
        if not path.is_file():continue
        foreground=g.image(path)
        on_bg=g.over(foreground,PALETTE_BG['midnight'])
        g.output(on_bg,f'previews/core_calm_midnight_f{frame:03d}_on-bg.png',(1024,1024))
        if first_output is None:first_output=on_bg
        if frame==1:
            g.output(g.over(foreground,PALETTE_BG['ivory']),
                     'previews/core_calm_midnight_f001_on-ivory.png',(1024,1024))
            g.output(g.over(foreground,'#FFFFFF'),
                     'previews/core_calm_midnight_f001_on-white.png',(1024,1024))
            g.output(g.scale(on_bg,128,128),
                     'previews/core_calm_midnight_f001_128px.png',(128,128))
        if frame in before and before[frame].is_file():
            combined=g.comparison(g.image(before[frame]),on_bg)
            g.output(combined,f'comparisons/before-after_f{frame:03d}.png',(2048,1024))
    for palette,path in pals.items():
        if not path.is_file():continue
        colored=g.over(g.image(path),PALETTE_BG[palette])
        g.output(colored,f'palette_check/{palette}.png',(1024,1024))
        if first_output is None:first_output=colored
    if first_output is None:raise FileNotFoundError('No native review inputs exist yet')
    output=nt.nodes.new('NodeGroupOutput');nt.links.new(first_output,output.inputs[0])
    s.frame_set(1)
    s['HarmonyReviewOutputs']=json.dumps(g.outputs)
    return s,g.outputs


def render_review(root=ROOT,original_previews=None,allow_partial=False):
    s,outputs=build_review(root,original_previews,allow_partial)
    t=time.perf_counter()
    bpy.ops.render.render(scene=s.name)
    elapsed=time.perf_counter()-t
    for entry in outputs:
        target=Path(entry['path'])
        if not target.is_file():
            # Exact file_name + blank File Output item emits no frame suffix in
            # Blender 5.2. Handle a future version that does append one.
            alternatives=list(target.parent.glob(target.stem+'*.png'))
            if len(alternatives)==1:alternatives[0].replace(target)
            else:raise FileNotFoundError(f'Expected review output missing: {target}')
        im=bpy.data.images.load(str(target),check_existing=False)
        actual=list(im.size);bpy.data.images.remove(im)
        if actual!=entry['size']:
            raise ValueError(f'{target}: expected {entry["size"]}, got {actual}')
    report={'blender':bpy.app.version_string,'seconds':round(elapsed,3),
            'renderer':'Blender EEVEE empty scene + scene-linear compositor',
            'outputs':outputs}
    audit=Path(root)/'audit/review-render.json';audit.parent.mkdir(parents=True,exist_ok=True)
    audit.write_text(json.dumps(report,indent=2))
    print(json.dumps({'review_outputs':len(outputs),'seconds':round(elapsed,3)},indent=2),flush=True)
    return outputs


def main():
    argv=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:]
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=('review','build'),default='review')
    p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--original-previews',type=Path)
    p.add_argument('--allow-partial',action='store_true')
    args=p.parse_args(argv)
    if args.mode=='build':
        scene,outputs=build_review(args.root,args.original_previews,args.allow_partial)
        path=args.root/'source/harmony_review.blend'
        bpy.ops.file.pack_all()
        bpy.ops.wm.save_as_mainfile(filepath=str(path),compress=True)
        print(json.dumps({'scene':str(path),'outputs':len(outputs)},indent=2))
    else:render_review(args.root,args.original_previews,args.allow_partial)


if __name__=='__main__':main()
