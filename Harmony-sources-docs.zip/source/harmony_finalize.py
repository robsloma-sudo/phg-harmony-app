"""Pack the polished scenes and portable source into one Blender master.

This does not render or alter the supplied seed. Run after supporting builds.
The separate realtime master makes the animation atmosphere easy to inspect.
"""
from pathlib import Path
import sys, json
import bpy
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'source'))
import harmony_core_build as C
import harmony_realtime as RT

def finalize():
    master=ROOT/'source/harmony_assets.blend'
    bpy.ops.wm.open_mainfile(filepath=str(master),use_scripts=False)
    s=bpy.data.scenes['Orb'];C.apply_look(s,'calm','midnight')
    RT.enable(s,'midnight',True,'calm');RT.enable(s,'midnight',False,'calm')
    s.render.resolution_x=s.render.resolution_y=1024
    s.render.resolution_percentage=100;s.eevee.taa_render_samples=64
    s.eevee.volumetric_samples=96;s.eevee.volumetric_tile_size='2'
    s.render.compositor_device='CPU'
    s.frame_start=1;s.frame_end=120;s.frame_set(1)
    with bpy.data.libraries.load(str(ROOT/'source/harmony_supporting.blend'),link=False) as (src,dst):
        dst.scenes=[x for x in src.scenes if x in ('Mark','Background','Pins') and x not in bpy.data.scenes]
    for scene in bpy.data.scenes:
        scene.frame_start=1;scene.frame_end=120;scene.render.fps=30;scene.frame_set(1)
        scene.render.compositor_device='CPU'
    for path in (ROOT/'source').glob('*.py'):
        text=bpy.data.texts.get(path.name) or bpy.data.texts.new(path.name)
        text.clear();text.write(path.read_text());text.use_fake_user=True
    txt=bpy.data.texts.get('START HERE') or bpy.data.texts.new('START HERE')
    txt.clear();txt.write((ROOT/'README.md').read_text());txt.use_fake_user=True
    if bpy.context.window:bpy.context.window.scene=s
    s['HarmonyDelivery']='PHG Harmony Core polished return; see embedded START HERE'
    s['HarmonyLoopContract']='120 frames at30fps; endpoint121==1; integer shader cycles'
    s.render.filepath='//../orb/calm_midnight_still.png'
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(master),compress=True)
    RT.enable(s,'midnight',True,'calm');s.eevee.taa_render_samples=8
    s['HarmonyDelivery']='Realtime atmosphere master; actual palette colors, ungraded'
    s.render.filepath='//../orb/calm_midnight/orb_'
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'source/harmony_animation.blend'),compress=True)
    return {'blender':bpy.app.version_string,'scenes':[x.name for x in bpy.data.scenes],
            'beauty_master':str(master),'animation_master':str(ROOT/'source/harmony_animation.blend')}

if __name__=='__main__':
    result=finalize();(ROOT/'audit/finalize.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
