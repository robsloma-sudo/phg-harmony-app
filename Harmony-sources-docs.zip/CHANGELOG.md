# Harmony Core polish changelog

**PHG designer return · CDX · 4 October 2026 · Blender 5.2.2 LTS**

The finishing direction restores a legible gold/blue shell, shaded jewel-like nucleus particles, and a calmer atmospheric frame. The nucleus and shell carry the large bright forms; a smaller number of prominent synaptic pulses and colored electron heads carry the motion. The nebula gains spectral separation and darker lanes, while a finite envelope preserves breathing room around the image. Three distinct styles, a complete supporting identity set, and an offline interface review extend the same palette system across the product.

Values below use the **saved incoming Blender scene** as the baseline, rather than the older build script. Original audit records are in `audit/ORIGINAL_SCENE_AUDIT.md` and `original-scene.json`. Final per-look colors and node controls are in `SPEC.json`.

## Core geometry and material changes

| Object / material / node | Incoming → returned | Purpose |
|---|---|---|
| Nucleon00–12 · particle radius | 0.169 effective radius → 0.145; mesh radius 0.13 retained, object scale 1.30 → 1.1153846 | Separate the particle silhouettes inside the shell |
| Nucleon01–12 · center radius | 0.27 → 0.285 | Give the cluster more internal air |
| M_Proton / M_Neutron · body | Constant accent / accent2 → facing-modulated dark body blended into the same token | Add curved material depth without new hues |
| Nucleus BSDF · roughness / metallic | 0.25 / 0 → 0.16 / 0.24 | Tighter polished highlights |
| Nucleus BSDF · coat | Weight 1.00 retained; roughness 0.03 → 0.035 | Keep a crisp, controlled highlight |
| Nucleus BSDF · subsurface | 0 → 0.04 | Subtle inner softness |
| Nucleus emission | Proton 1.80 / neutron 1.60 constant → `e × (0.18 + 0.62 × (1-facing))` | Preserve shading and reduce chalky flat light |
| M_Shell · render method | DITHERED → BLENDED | Smoother glass coverage in software EEVEE |
| M_Shell · Ramp stops | 0.22 / 0.60 / 0.90 / 1.00 → 0.20 / 0.57 / 0.88 / 1.00 | Redistribute the gold body and blue upper highlight |
| M_Shell · Ramp lower mix | 40% accent + 60% bg → 30% accent + 70% bg | More lower-pole depth in dark palettes |
| M_Shell · Ramp white mix | Accent2 + 35% white → accent2 + 8% white | Retain blue instead of milky lavender |
| M_Shell · BSDF | Roughness 0.15 → 0.18; metallic 0 → 0.08; coat 0.80 → 0.85; coat roughness 0.05 → 0.06 | Controlled glass/jewel reflections |
| M_Shell · Layer Weight | Blend 0.40 → 0.35 | Refine edge falloff |
| Shell vein noise | Scale 3.2 → 1.85; detail 6 → 3; roughness 0.60 → 0.52; distortion 1.20 → 0.65; circular radius 0.90 → 0.45 | Broader flowing currents with less granular noise |
| Shell vein band | Absolute noise deviation 0–0.035 → 0.006–0.027 | A more deliberate bright line and shoulder |
| ShellEmit | `0.30 + 1.30 × veins` → `e × (0.30 + 0.34 × veins)` | Restore colored material body without hot veins |
| RimStrength | `2.00 × facing^2.2` → `e × 0.58 × facing^3.2` | A narrower colored rim |
| ShellAlpha | `0.32 + 0.63 × facing^1.4` → `0.28 + 0.62 × facing^1.65` | Clear center, readable edge, less opaque wash |
| M_Plasma · noise | Scale 2.4 → 2.1; detail 5 → 3; roughness 0.60 → 0.55; distortion 1.50 → 0.70; loop radius 0.80 → 0.60 | Quiet inner movement |
| Plasma density / emission | Density multiplier 0.25 → 0.15; emission 1.60 → `0.22 × e` | Keep the nucleus first in the hierarchy |
| Plasma masks | Noise 0.45–0.72 → 0.52–0.76; radial 0.95–0.35 → 0.91–0.40 | Fewer hot interior clouds |
| Plasma color | Black scattering / three emission ramp stops → accent2-to-accent scattering and emission | Consistent token-based recoloring |
| M_Nebula · ellipsoid | (0.80,0.90,1.15) → (1.02,0.95,1.14) | Fit atmosphere within the camera |
| Nebula outer / inner fade | Outer 3.30–1.50 → 2.90–1.55; inner 0.95–1.35 → 1.05–1.48 | Clear frame edges and central focal space |
| Nebula main noise | Scale 0.55 → 0.72; detail 7 → 4; distortion 1.10 → 0.75; loop radius 0.35 → 0.24; roughness 0.62 retained | More selective clouds at lower shader cost |
| Nebula wisps | Threshold 0.50–0.78 / exponent 1.60 → 0.46–0.72 / exponent 1.80 | Stronger separation of bright and dark structure |
| Nebula dust lanes | None → second looped noise, scale 1.10, detail 2, roughness 0.55, distortion 0.25; mask 0.30–0.56 mapped 0.10–1.00 | Interrupt even haze with dark lanes |
| Nebula color noise | Scale 0.90 / detail 3 → 0.60 / detail 2; loop radius 0.25 retained | Larger spectral regions |
| NebRamp | LINEAR stops 0.40 / 0.49 / 0.56 / 0.64 → EASE stops 0.30 / 0.47 / 0.63 / 0.76 | Dark nebula/bg mix → nebula → accent2 → accent; remove the pale white stop |
| Nebula scattering color | Fixed linear (0.25,0.25,0.35) → linked NebRamp | Remove fixed lavender across palettes |
| NebDensity / NebEmit / anisotropy | 0.55 / 3.00 / 0.35 → 0.16 / `1.15 × e` / 0.20 | Rich but subordinate atmosphere |
| M_Synapse · brightness hierarchy | Uniform base 0.45 and pulse +5.00 → quiet base 0.18 / pulse +1.10; hero base 0.42 / pulse +2.30 | Reserve stronger signals for UV-phase subset `v < 0.26` |
| Synapse pulse | 0.80–1.00 band, exponent 3.00 → 0.73–1.00, exponent 3.50 | Sharper head with a longer fading tail |
| Synapse pulse color | Accent + 35% white → accent + 8% white | Preserve warm signal color |
| Synapse fade | Full near radius 1.40, zero at 3.40 → full near 1.30, zero at 3.05 | More quiet outer space |
| Far-side synapses, trails, electrons | Emissive transparency alone → smooth projected-shell rear mask | Let the nucleus read without far-side lines crossing it |
| M_TrailA/B/C · tails | Fraction 0.32 → 0.44 in Calm/Friendly, 0.22 in Tech; exponent 2.20 → 2.80; peak +3.20 → +1.40 | Longer elegant tails, shorter precise Tech motion |
| Orbit base / color | A/C 0.22 → 0.10; B dashes 0.30 → 0.16; head white mix removed | Quiet orbit scaffold with colored motion cues |
| M_ElectronA/B/C | Orbit color + 25% white at strength 3.00 → color + 2.5% white at `1.05 × e` | Prevent all-channel clipping to white |
| StarDust | 650 → 380 specks; original size distribution retained | Reduce small-size visual noise |
| M_Stars · color / twinkle | Blue + 50% white and white stop → blue + 18% white, blue, accent; power 3 → 4 | More distinct, restrained glints |
| StarStrength / fade | Base 0.35, peak add 3.00 → base 0.10, peak add 1.10; zero radius 3.50 → 3.15; full radius 2.20 → 2.00 | Atmosphere stays behind the focal forms |

`e = 1` normally, `0.4` for Ivory, with an additional `0.5` multiplier for Friendly. All palette mixes occur in scene-linear RGB; exact resulting hex colors are exported per look.

## Styles, light theme, lighting, and transparency

- Calm retains original ring radii, tube widths, electron sizes, and first-orbit speed.
- Tech changes ring widths to ×0.8, electron radii to ×0.85, orbit A to 720° per loop, tails to 22% of spacing, and bloom strength to 0.38. `TechWire` adds an ico-subdivision-3 lattice at radius/scale 1.003 with wire thickness 0.0011. `TechTicks` adds 24 marks every 15°, spanning radii 2.265–2.335 with tangential width 0.006, parented to SpinA.
- Friendly changes ring widths to ×2.5, electron radii to ×1.6, shell roughness to 0.60, coat weight to 0.16, emission to ×0.5, and bloom strength to 0.025.
- Ivory adds independent pigment coverage for synapses, trails, and heads. Trail coverage is `back_mask × (0.38 + 0.50 × tail)` with brightness floor 0.40; synapses use `fade × (0.20 + 0.44 × pulse)` with floor 0.30; electrons use 0.88 × back mask. A finite soft charcoal shadow peaks at alpha 0.12 in the beauty scene. Its mask uses the plane's correct local X/Z axes.
- KeyLight: 70 → 100 W; fixed warm RGB → accent mixed with 88% white. RimLight: 150 → 75 W, accent2 retained. CoreLight: 250 → `28 × e` W, accent + 50% white → accent + 20% white. New NucleusSoftbox: 160 W, disk size 0.85, position (-1.2,-3.8,1.9), accent2 + 55% white. World panel strength: 0.35 → 0.22.
- Bloom: threshold 0.70 → 0.90; Calm strength 1.00 → 0.26; size 0.70 → 0.40; quality High and saturation 1.00 retained. The brightest-channel glow-to-alpha maximum remains intact. A Gaussian-feathered 89% box gates RGB and alpha together, with 18 px blur at native 1024. Beauty RGB below alpha 0.5/255 is cleared before 8-bit PNG encoding. The 24 delivered beauty/state/frame PNGs received a Blender compositor finish: alpha is preserved exactly and measured visible RGB error is at most 1/255. Optimized loops trim RGB below alpha `1/256 − 10⁻⁹`, retaining coverage; the affected fringe appearance is bounded by 1/255 opacity. Encoding dither can leave one-byte RGB values at zero alpha, which are discarded by RGBA compositing.
- Existing object/material identities and established node names are retained. Ring meshes are regenerated at their original radii and old unused meshes removed; style thickness changes affect the cross-section rather than the whole orbit scale.

## New production assets and source organization

New Orb objects are `NucleusSoftbox`, `TechWire`, `TechTicks`, and `IvoryShadow`, all in `Designer`. New materials are `M_TechWire`, `M_TechTicks`, and `M_IvoryShadow`. The optional realtime preset adds `AtmosphereDepth`, `AtmosphereFilaments`, and `AtmosphereKnots`, with corresponding `M_` materials in `Designer`. These three cards substitute for Nebula/Plasma visibility during optimized animation; the original volume objects remain editable and can be restored.

The supporting Blender file introduces a simplified one-jewel/one-orbit/one-electron mark, three style treatments, 60 opaque icon sizes, 30 quiet landscape/portrait backgrounds, and ten glossy map pins. They were absent from the incoming artwork package. Exact supporting geometry, colors, and surface parameters are exported in `SPEC.json`. The mark fits inside the icon's safe center region.

The theme reference was rebuilt as an offline review with actual rendered media, better type/spacing hierarchy, independent style and palette axes, local token export, accessible controls, state captions, image dialogs, loop playback, and reduced-motion behavior. It was checked across 15 themes and four viewport sizes; detailed interaction and contrast results are in `docs/theme-notes.md`.

The original handoff documents, build script, Blender file, theme reference, previews, and manifest are retained as reference material. Final specs, an updated asset manifest, review outputs, and reproducible scripts describe the returned package. The incoming script/source discrepancies are documented rather than silently treated as the baseline.

## Render presets and limits

The complete editable master contains Orb, Mark, Background, and Pins, with Orb at 64 EEVEE render samples / 96 volume samples / 2 px volume tiles. A separate animation master opens actual Midnight materials with eight samples and the realtime atmosphere enabled. Independently palette-lit stills use 16 / 32 / 4 px. Full loops use native 1024 four-sample style renders plus a Blender linear palette grade and 512 bicubic exports. Three complementary procedural atmosphere cards replace volume integration in that animation preset. The grade preserves a neutral reflection component and maps red/blue/green signals to accent/accent2/neb; palette-dependent colored reflections and background illumination are approximate. Ivory's animation grade keeps coverage independent of its dim charcoal and adds a 10% soft compositor shadow. The export uses four render threads and Blender's GPU compositor through Mesa software / llvmpipe; both can be changed for a later rendering device.

All playback sequences remain 120 frames / 30 fps, with frame-121 endpoint keys. Existing nucleus, breathing, orbit symmetry, shader circular-noise, pulse-cycle, and twinkle-cycle mathematics are preserved. New cards also complete one circular noise cycle. Standard / None / exposure 0 / gamma 1 remain unchanged.

Hardware was AMD EPYC 9V74 with five exposed logical CPUs, using software Mesa EEVEE and no hardware GPU. Concurrent native beauty renders observed approximately 25–52 seconds per frame; optimized animation timings include both concurrent rendering and the faster four-thread export, which reached approximately 5.7 seconds while writing ten PNG exports. Full timing logs are included. The original ≤6-second GPU production budget is **unverified**; the optimized batch measurement does not benchmark the full-volume beauty scene or a hardware GPU.

The main remaining quality choice is whether to rerender independent full-volume palette animation on a GPU, and at what sample count. Four-sample loop exports show small coverage differences on the finest curves compared with the eight-sample proof; the measured comparison is supplied in the batch notes. The sources support higher-sample or full-beauty rerenders without changing palettes or timing. No changes to orthographic camera type, 8° camera tilt, 13-particle nucleus count, orbit counts, frame rate, or Standard color management were needed.
