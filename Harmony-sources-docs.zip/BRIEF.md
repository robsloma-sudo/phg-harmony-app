# Harmony Core — returned design and production brief

**Perfect Harmony Group · 4 October 2026**

The returned direction concentrates attention in the nucleus and shell, gives the orbit system a clearer silhouette, and moves the nebula and star field into supporting roles. Color comes from the established five palette families, with restrained white mixing and a darker material body that lets highlights carry depth. Calm is luminous and measured; Tech adds a fine lattice, orbit ticks, shorter tails, and a faster first orbit; Friendly uses thicker orbits, larger dots, a softer shell, and less glow. Ivory receives pigment coverage and a soft shadow suitable for a cream interface.

The work expands the original polish handoff into a full asset return. The core's nucleus, glass shell, plasma, synapses, electron orbits, nebula, and dust remain identifiable and editable. Supporting assets use a simplified jewel, one orbit, and one electron for the mark; opaque icon backgrounds preserve the safe inset; quiet corner light leaves backgrounds usable behind text; pins provide a compact glossy location cue. The interface preview gives the artwork space and exposes actual rendered media for all themes.

## Sources of truth

- `source/harmony_assets.blend`: complete editable master with `Orb`, `Mark`, `Background`, and `Pins`; beauty volumes enabled in Orb.
- `source/harmony_animation.blend`: actual Midnight materials with the realtime atmosphere enabled at eight samples; a separate editable animation preset.
- `source/harmony_core_build.py`: reproducible final beauty materials, geometry adjustments, palette/state switches, lighting, and compositor.
- `source/harmony_batch_render.py` and `harmony_realtime.py`: optimized graded animation delivery.
- `source/harmony_supporting.blend` and its build script: Mark, Background, and Pins.
- `SPEC.txt` and `SPEC.json`: final dimensions, colors, material controls, lighting, and animation mathematics.
- `reference/harmony-theme-preview.html`: offline interactive review with delivered assets.

The original brief, addendum, asset specification, draft values, preview images, pending manifest, build script, theme HTML, and Blender file are retained under `reference/`. They document the incoming version; they are superseded by the returned specifications. Their embedded approval stages and workstation paths are historical context.

## Production distinction

The beauty master retains full volume materials and 64 / 96 / 2 px sampling settings. Palette-specific beauty stills use the same scene at 16 render samples, 32 volume samples, and 4 px tiles. The 15 full loops use native 1024 four-sample Blender renders of three styles, procedural atmosphere cards, and a linear compositor palette grade. Their colored lighting is an approximation of the independently lit beauty scene. The supplied sources allow full-volume, independently palette-lit animation when GPU rendering time is available.

All playback loops remain 120 frames at 30 fps. Frame 121 returns to the starting phase; rotations use linear interpolation and integer symmetry cycles. Standard color management remains in use. Transparent outputs keep glow-to-alpha and a finite clear margin. Blender clears invisible RGB before encoding; one-byte dither residue can remain at zero alpha and is discarded during RGBA compositing. The beauty PNG finish preserves alpha exactly and changes visible RGB by at most one byte. App icons and backgrounds are opaque.

## Review focus and future work

Review the 128 px specimen alongside the 1024 beauty stills, then play each style's rendered loop to assess thin-curve coverage and motion. Compare Ivory on its intended cream background. Use the independent palette stills to judge material color and the optimized loops to judge the actual delivered animation appearance.

The original ≤6-second GPU target has not been established on this CPU-only software-rendering environment. A hardware-GPU benchmark and, if desired, higher-sample independent beauty loops are the remaining production choices. The files include measured timings and reproducible presets so that decision does not require reconstructing the design.
