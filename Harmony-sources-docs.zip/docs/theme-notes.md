# Harmony interface review

Open `reference/harmony-theme-preview.html` inside the extracted handoff. The page is fully offline: its CSS and JavaScript are embedded, its fonts use local system fallbacks, and every image or video reference stays inside the package.

## Design intent

The core carries the visual complexity; the interface gives it room. A quiet canvas, measured spacing, readable secondary text, and restrained borders keep the focal order clear. Serif display typography gives Calm an editorial voice. Tech uses precise sans-serif type and small corner radii. Friendly uses warmer typography and generous rounded forms. Style and palette remain independent, so all 15 combinations work consistently.

Five palette families preserve the original direction. Interface colors use softer accent saturation and brighter secondary text in the dark palettes, with deeper secondary colors in Ivory. The minimum contrast for the normal text tokens across the four interface surfaces is 4.68:1; primary button color pairs exceed 8.43:1. These measurements cover the interface tokens, not text composited over an image.

## Rendered media

The header mark and the three asset review cards follow the active style and palette. The cards show the transparent brand mark, 512 px opaque app icon, and landscape background. Select a card to view its actual pixel dimensions and save the full PNG.

Idle uses `orb/<style>_<palette>_still.png`. Listening, Thinking, and Speaking use the three `orb/states/state_<state>.png` files. These are Calm / Midnight reference renders; the caption states this even when the surrounding interface uses another theme. The page does not approximate those state colors with a CSS hue filter.

The Rendered loop control shows the selected style’s Midnight MP4: `loop_check/orb_loop_preview.mp4` for Calm, `loop_check/tech_midnight.mp4` for Tech, and `loop_check/friendly_midnight.mp4` for Friendly. Video uses native playback controls and does not autoplay. Choosing a state returns to still mode and pauses video. The decorative motion control also pauses active video. Device reduced-motion preferences stop the CSS animation.

The gentle CSS movement of the still image is a review convenience, independent of the rendered animation. Review continuity, timing, and layer motion in the actual MP4 and frame assets. The UI never recolors a core render to imply another palette.

## Interaction and future changes

The preview includes an identity review, an illustrative Harmony conversation, a schematic Atlas map, and a component library. Tabs support arrow keys, Home, and End. Theme and asset dialogs use native dialog semantics. Controls expose pressed or checked state. The map filters and venue selections update local sample data. Conversation input is escaped as text and stays on the device. It is a design demo with no remote messaging service.

Theme selections save locally when storage is available. Stored values are validated against the supported styles and palettes. Asset errors show a readable fallback instead of a broken image.

The Design system screen exports the active interface color, typography, and shape tokens as JSON. These are interface tokens; Blender material colors and physical lighting remain controlled by the scene and render scripts. When adding a theme, update the CSS palette/style axis, selection controls, asset routing, and validation lists together. Keep the image paths stable so the same page can review subsequent renders without a markup rebuild.

The page was checked in Chromium at 320, 390, 768, and 1440 px across all 15 themes and four screens, with no horizontal overflow or JavaScript errors. Interaction checks covered state routing, loop routing and pause behavior, asset dialogs, keyboard tabs, map filters, local chat escaping, token download, saved preferences, and reduced motion. Final rendering and media playback quality remain separate checks on the delivered assets.
