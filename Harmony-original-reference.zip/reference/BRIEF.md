# Harmony Core: Design Polish Brief

**To:** Secondary graphic designer
**From:** Rob, Perfect Harmony Group
**Date:** 4 October 2026
**Return:** a zip of your work (structure in section 9), sent back to Rob for review

---

## 1. Your job in one paragraph

We've built the first full version of the **Harmony Core**, the animated orb at the center of the Harmony app.
The concept and structure are done. Your job is the **finishing pass**: take it from "very good" to
**best-in-class, premium, unmistakable**. Refine materials, light, color, depth, motion and detail.
You are **polishing, not redesigning**. Keep the concept, the layers, the palette system and the technical
rules in section 5. Everything inside those limits is yours to push. When you're done, zip your work back up
as described in section 9 so it can be reviewed before we render all 15 looks.

---

## 2. The creative direction

> **"A brain synapse's electron had a baby with a cosmic nebula and an atom."**

It should feel **alive, intelligent and vast**, like looking at a thinking mind and a galaxy at the same time.
Premium, not sci-fi cheesy. Calm enough to sit in a productivity app for hours, rich enough to make people stop and stare.

Reference keywords: neural firing, bioluminescence, atom model, deep-space nebula photography (Hubble/JWST),
glass, plasma, jewel-like light, soft volumetrics.

---

## 3. What's there now

Open `previews/core_calm_midnight_f001_on-bg.png` and `_f045_on-bg.png` first.

The orb is built from 7 layers, center outward. Object and material names are in brackets.

| # | Layer | What it does | Blender objects / materials |
|---|---|---|---|
| 1 | **Nucleus** | 13 glowing particles (gold protons, blue neutrons), slowly turning | `Nucleus` empty, `Nucleon00–12` / `M_Proton`, `M_Neutron` |
| 2 | **Glass shell** | See-through sphere with brand gradient, swirling gold energy veins, blue rim glow. Breathes 1.00 → 1.05 → 1.00 | `Shell` / `M_Shell` (child of `Core`) |
| 3 | **Plasma** | Faint glowing haze inside the shell | `Plasma` / `M_Plasma` (volume) |
| 4 | **Synapses** | About 26 branching neural tendrils. Light pulses travel outward and tips flash | `Synapses` / `M_Synapse` |
| 5 | **Electron orbits** | 3 crossing atom-style orbits, electrons with comet tails, passing behind the shell | `OrbitA/B/C`, `SpinA/B/C`, `RingA/B/C`, `ElectronA0…` / `M_TrailA/B/C`, `M_ElectronA/B/C` |
| 6 | **Nebula** | Soft 3D cloud (violet, periwinkle, a little gold), slowly churning | `Nebula` / `M_Nebula` (volume) |
| 7 | **Star dust** | About 650 twinkling specks | `StarDust` / `M_Stars` |

Lights: `KeyLight` (warm, top-left), `RimLight` (accent2, behind), `CoreLight` (point light in the center that lights the nebula).
Bloom: compositor node group `Orb Comp`, Glare node named `Bloom`.

Exact current values are in `SPEC_DRAFT.txt`.

---

## 4. Where it needs you (known weak spots, in priority order)

These are our own notes from reviewing the current renders. Fix these first, then go further wherever your eye says.

1. **The shell lost the brand gradient.** The top-left reads milky lavender-white. The brand orb is a clear
   **accent2 blue highlight top-left → gold accent across the middle → darker (40% accent + 60% bg) at the bottom**.
   The bottom darkening has almost disappeared. Bring the gradient and the depth back, and keep the glass and veins.
2. **Nucleus looks flat.** The blue neutrons are pale and chalky, and the gold protons lack depth. Make them
   jewel-like: inner glow, a crisp specular, maybe a hint of subsurface. Separate them clearly from the veins behind.
3. **Nebula is too even and too lavender.** It needs depth and drama: darker dust lanes, a few brighter knots,
   richer violet ↔ periwinkle ↔ gold variation. Think nebula photography. It **must still fade to fully
   transparent well before the frame edge**.
4. **Electrons blow out to white.** Find the balance: a hot core, with the orbit's own color clearly visible in the head and glow.
   The comet tails could be more elegant (longer, with a smoother falloff).
5. **Synapses are a bit uniform.** Everything has the same weight. Create hierarchy: a few hero tendrils
   (thicker, brighter, crisper pulses) and finer, quieter ones behind. Pulses could have a sharper leading edge and a softer tail.
   Tip flashes should feel like real synaptic sparks.
6. **Veins on the shell** are close to noisy. Make them more deliberate and flowing, like energy currents, not static.
7. **Overall light balance:** the center can feel hot and busy at the same time. Aim for a clear focal hierarchy:
   nucleus first, shell second, synapses and electrons third, nebula and dust as atmosphere.
8. **Small-size legibility:** the orb shows at 150–340 px in the app. Downscale your render to **128 px** and
   check it still reads as "glowing orb with orbits", not a smudge.
9. **Size in frame:** the shell is about 28% of the frame width, so the outer orbit and nebula fit. If you can make
   the core read larger without clipping anything, great. **Nothing may touch the frame edge.**

---

## 5. Non-negotiables (please read carefully)

Breaking any of these means the work can't go to production.

**Palette and theming**
- Every color must come from the palette tokens: **bg, panel, accent, accent2, nebula tint** (plus white or black mixes).
  No new hard-coded hues. The same scene is re-colored automatically for **15 looks**
  (3 styles × 5 palettes, in `SPEC_DRAFT.txt` and `reference/harmony-theme-preview.html`).
- One palette, **ivory**, is a **light theme** (cream bg #F6F2EA, charcoal accent). Your changes must still work there.
  On ivory we lower glow to ×0.4 and add a soft drop shadow.
- Hex colors must still read true. We use **View Transform: Standard** for that reason. If you switch to AgX,
  say so in the changelog and show that the palette colors still match.

**Animation and loop**
- **120 frames, 30 fps, frames 1–120.** Frame 120 must flow into frame 1 with **no jump**.
- Any new or changed motion must finish **whole cycles** in 120 frames:
  - Keyframed rotation: key frame 1 and frame **121** (not 120), with **linear** interpolation, using whole-turn
    amounts (360°, or a multiple of the object's symmetry, e.g. 120° for 3 evenly spaced electrons).
  - Shader animation: use the `LoopT` value node (driver `(frame-1)/120`, runs 0 → 1). Feed it through
    `sin`/`cos(2π·LoopT·k)` or `fract(x − k·LoopT)` with **whole-number k**. Copy an existing `LoopT` node into new materials.
  - Animated noise: use the circular trick already in the materials (4D noise, offset on a circle using cos/sin of LoopT).
- Orbit C turns 120° per loop, not 180°, because 180° doesn't loop cleanly with 3 electrons. Keep that kind of maths in mind.

**Output**
- Transparent background (Film → Transparent ON). PNG, RGBA, 8-bit.
- Keep the compositor glow-to-alpha setup in `Orb Comp`. It makes the glow survive on transparent backgrounds.
  If you change bloom, keep the final "alpha = max(alpha, brightest channel)" step.
- Resolution 1024 × 1024, orthographic camera, 8° tilt. Don't change the camera type.
- **No hard edges, clipped glows or dark fringes.** Check on dark, white and cream backgrounds.

**Production budget**
- We render 3,600 orb frames (15 looks × 120 frames × 2 sizes). Current cost is about **3 seconds per 1024 frame**
  in EEVEE. Please stay under **6 seconds per frame** at 1024. Note your render time in the changelog.
- Stay in **EEVEE**. No Cycles.

**File hygiene** (we regenerate all 15 looks from these names with a script)
- **Don't rename** existing objects, materials, or these nodes: `Ramp`, `NebRamp`, `BSDF`, `ShellEmit`, `ShellAlpha`,
  `RimStrength`, `PlasmaEmit`, `NebEmit`, `NebDensity`, `SynStrength`, `TrailStrength`, `StarStrength`, `Strength`, `LoopT`, `Bloom`.
- New objects go in a collection called **`Designer`**. New materials start with `M_`.
- Pack any image textures into the .blend (File → External Data → Pack Resources).
- Save with **Blender 5.2 LTS** (the compositor uses the 5.x node-group format).

---

## 6. Freedom: what you can change

Anything not locked above, for example:
- shader networks, roughness, coat, emission, gradient stops, noise settings, rim and fresnel
- light positions, sizes and power, and adding lights
- synapse count, shape, branching, thickness and pulse look (regenerate them or hand-edit)
- nucleus arrangement, size and materials
- nebula shape, density, colors and lighting
- electron and trail design, ring look and dashes
- bloom strength, size and threshold, or extra glare (keep it transparent-safe)
- adding subtle new elements (sparks, lens artifacts, particles), as long as they loop and use palette colors

If you want to change something locked (for example the orbit counts or the camera tilt), **don't do it in the main
file**. Put it in the changelog as a proposal, optionally with a separate mock-up.

---

## 7. How to work with the file

1. Install **Blender 5.2 LTS**. Open `source/harmony_assets.blend`. The scene is called **Orb**.
2. Viewport: set shading to **Rendered**. To see bloom in the viewport, set the viewport compositor to **Always**
   (shading popover → Compositor).
3. Still test: go to a frame, press **F12**. Frame 1 and frame 45 match the included previews.
4. Loop test: render frames **119, 120 and 1**, and flip through them. Frame 120 → 1 must look like any other step.
   For a quick motion check: Output Properties → 50% resolution, render the animation to a temp folder, then use
   Render → View Animation.
5. Volumes (plasma, nebula) are tuned with Render Properties → Volumes: tile size 2 px, 96 samples. Don't go coarser,
   because it gets blocky.
6. `source/harmony_core_build.py` is the script that builds the scene from scratch for any palette. **You don't need
   to touch it.** Note every value you change in the changelog, and we'll update the script to match.
   Some current values were tuned by hand after the script ran, so the .blend is the source of truth, not the script.

---

## 8. Optional: next assets (concepts welcome)

These haven't been designed yet. If you have time and ideas, add **concept frames** (not final renders) in `concepts/`:
- **Brand mark:** a simplified, bold version of the orb for the app header and the home-screen icon. Must read at
  **32 × 32 px**. The front-end currently uses a conic gradient accent → accent2 → accent with one ring and one dot.
- **App icon:** the mark on a solid square in the palette bg color, kept inside the **middle 80%** (iOS rounds corners).
- **Backgrounds:** quiet, full-screen, text goes on top. Flat bg color with two very soft glows (top-right accent2,
  bottom-left warmer) and a barely visible dot grid or contour lines. 2560 × 1440, plus a 1290 × 2796 portrait version.
- **Map pins:** 256 × 256, small glossy dot with a thin light outline and soft glow, primary (accent) and secondary (accent2).

`asset-manifest.csv` lists every final file, with names and sizes, so you can see the whole system.

---

## 9. What to send back

Zip everything into **one file** named:

```
PHG-Harmony-Core_designer-return_<your initials>_<YYYY-MM-DD>.zip
```

Structure:

```
CHANGELOG.md                 required; see below
source/
  harmony_assets.blend       your polished file, saved in Blender 5.2, resources packed
previews/                    required; calm_midnight, 1024 × 1024
  core_calm_midnight_f001_transparent.png
  core_calm_midnight_f030_transparent.png
  core_calm_midnight_f060_transparent.png
  core_calm_midnight_f090_transparent.png
  core_calm_midnight_f120_transparent.png
  core_calm_midnight_f001_on-bg.png          (same frames on #070B18)
  core_calm_midnight_f001_on-ivory.png       (frame 1 on #F6F2EA)
  core_calm_midnight_f001_128px.png          (small-size check)
comparisons/                 required; before | after, side by side
  before-after_f001.png
  before-after_f045.png
loop_check/                  recommended
  orb_loop_preview.mp4       (or .gif) 512 px, full 120 frames, played twice
palette_check/               recommended; frame 1 with the palette switched to each of these
  aurora.png  ocean.png  ember.png  ivory.png
concepts/                    optional; mark, icon, backgrounds, pins
```

**CHANGELOG.md must include:**
1. A short summary of your direction (3–5 sentences).
2. **Every change, as a list**: object/material/node name → setting → **old value → new value** → why.
   For example: `M_Shell › Ramp › stop 3 position 0.90 → 0.84 (bigger blue highlight)`.
3. New objects, materials or lights you added (all in the `Designer` collection).
4. Render time per 1024 frame on your machine, plus your CPU/GPU model.
5. Anything you'd change but didn't because it's locked (proposals).
6. Anything you're unsure about or want feedback on.

---

## 10. How your work will be reviewed

When the zip comes back, it's checked against:

| Check | Pass means |
|---|---|
| Loop | Frame 120 → 1 has no jump, pop or flicker |
| Palette | accent / accent2 / bg read true. Works on midnight, aurora, ocean, ember and **ivory** |
| Transparency | Clean on dark, white and cream. No dark halos, clipped glows or hard edges |
| Hierarchy | Clear focal order: nucleus → shell → synapses and electrons → nebula and dust |
| Small size | Still reads at 128 px |
| Budget | ≤ 6 s per 1024 frame in EEVEE |
| Hygiene | Locked names unchanged, new items in `Designer`, resources packed, changelog complete |
| Wow | Does it make you stop and stare? |

Changes that pass get folded into the build script and rendered for all 15 looks.

---

## 11. Package contents

```
BRIEF.md                    this document
SPEC_DRAFT.txt              exact current values (camera, orbits, materials, bloom, lights)
asset-manifest.csv          every final file the project will deliver (for context)
ADDENDUM.txt                app delivery requirements (512 loops, icons, portrait bgs, state colors, spec)
previews/                   current frames 1 and 45, transparent and on the midnight bg
reference/
  harmony-theme-preview.html   the live theme system; open it in a browser and switch styles and palettes
  original-asset-spec.txt      the original phase-by-phase asset spec
source/
  harmony_assets.blend         Blender 5.2 working file (scene "Orb")
  harmony_core_build.py        the scene build script (for reference)
```

Questions go to Rob. Thanks, and make it sing.
