# Final Blender master audit

Both returned Blender masters pass **all 34 read-only scene checks** in Blender 5.2.2 LTS. The files were opened with automatic scripts disabled. This audit rendered no images and saved no Blender file.

## Scene and source integrity

| Check | Verified result |
|---|---|
| Scenes | Orb, Mark, Background, Pins in both masters |
| Object counts | Orb 49; Mark 8; Background 2; Pins 8; 67 total |
| Incoming identities | All 42 original Orb object names retained |
| New Orb objects | Four design additions plus three optional atmosphere cards; all seven in Designer |
| Material assignment | Every Orb mesh has valid material slots; 26 material datablocks across all scenes |
| Dust | 380 specks, 4,560 vertices, M_Stars assigned |
| Tech ticks | 24 quads / 96 vertices, parent SpinA, radial extent 2.265–2.335 with tangential half-width 0.003 |
| Nucleus | 13 particles, effective radius 0.145, surrounding center radius 0.285 |
| Resources | No unpacked file-image dependencies |
| Embedded sources | All ten current Python source files and the current START HERE guide are embedded |
| Output paths | Beauty: `//../orb/calm_midnight_still.png`; animation: `//../orb/calm_midnight/orb_` |
| Sidecar specification | All ten source SHA-256 values in SPEC.json match the current files |

Temporary animation, finish, and video staging directories, plus Mesa/XDG cache defaults, use Python’s operating-system temporary directory. On this Linux environment their resolved paths remain unchanged; caller environment and CLI overrides remain available. The portability pass changed no numeric/material specification or render settings.

The masters contain actual Calm / Midnight materials. No temporary RGB token-basis palette or grade is saved into either editable scene.

## Render presets

| Setting | Beauty master | Editable animation master |
|---|---|---|
| Engine | EEVEE | EEVEE |
| Render samples | 64 | 8 |
| Compositor device | CPU | CPU |
| Atmosphere | Original Nebula/Plasma volumes enabled | Three realtime atmosphere cards enabled |
| Alternate atmosphere | Three cards hidden | Original volumes hidden |
| Stored volume settings | 96 samples / 2 px tiles | 96 samples / 2 px tiles, volume objects hidden |
| Output | Native 1024×1024 PNG RGBA 8-bit, transparent | Same |
| Camera | Orthographic, scale 7.2, 8° downward view | Same |
| Color management | Standard / None / exposure 0 / gamma 1 | Same |

These editable settings are separate from the delivered presets. Independent beauty stills use 16 render samples / 32 volume samples / 4 px tiles. Full delivered loops use four render samples, four render threads, and Blender's GPU compositor through Mesa software / llvmpipe. The environment has no hardware GPU. Blender generates the native 1024 palette grades and 512 bicubic exports. Palette-specific PBR interactions are approximate in the graded loops, as documented in the README and batch notes.

## Loop mathematics

- Playback remains frames 1–120 at 30 fps, for four seconds; key endpoints are frames 1 and 121.
- All four rotating hierarchies have linear keys: nucleus +360°, A +360°, B −360°, and C +120°. Orbit C's three evenly spaced identical electrons permute at the endpoint.
- All eight LoopT driver paths are valid and use `(frame-1)/120`. Active material trees evaluate to phase 0 and 1 at the endpoints.
- Shader noise completes circular integer cycles; synapse pulses use two cycles and dust twinkles three. Realtime cards use one full circular cycle.
- Endpoint particle position sets agree within **4.05e-07 scene units**. Breathing returns to the identical starting scale.

This establishes the scene's temporal mathematics. Rendered seam appearance, sampling, completed frame counts, and MP4 playback are assessed in the package's separate image/video checks. Review MP4s repeat the full 120-frame loop twice: 240 frames, eight seconds, 30 fps.

## PNG finish and documentation

The supplied `png-finish.json` records the Blender compositor finish of 24 beauty/state/frame PNGs. It verifies identical alpha and a maximum visible RGB difference of one byte. Beauty cleanup clears RGB below alpha 0.5/255; the optimized export uses 1/256 − 10⁻⁹ to trim its faintest fringe while preserving coverage. Encoding dither can leave one-byte RGB residue at zero alpha, which RGBA compositing discards.

README, BRIEF, CHANGELOG, SPEC.txt, and SPEC.json describe the complete masters, direct-palette stills, separate graded realtime loops, GPU/software production compositor, four threads, four delivered samples, and the eight-second playback reviews. The original ≤6-second full-beauty GPU production target remains unverified. This scene audit makes no hardware performance claim.

Full snapshots are `final-master-scene.json` and `final-animation-scene.json`; numeric check results and file hashes are in `final-scene-checks.json`. Verification is reproducible with `verify_final_scenes.py`.

## Verified file identities

- `source/harmony_assets.blend` — SHA-256 `11f542acbc5ed5b6929a80a17e26bc355debce181660cc8dcdb4530054c9c42b`
- `source/harmony_animation.blend` — SHA-256 `12f7ba7fb7ddab3ad4d345701fefa9a7aac7cefb3fe524f3aa9ce235867c29e2`
