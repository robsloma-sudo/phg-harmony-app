"""Validate, inventory and package the finished Harmony handoff.

Run only after rendering, final QA and source freeze:
    python audit/package_handoff.py --ready
    python audit/package_handoff.py --ready --validate-only

This standard-library-only script never renders or edits production artwork.
--ready is mandatory; no filesystem scan runs without it. ZIP creation is atomic.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import sys
import tempfile
import time
from datetime import datetime, timezone
import zipfile
import zlib

DEFAULT_ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_NAME = 'PHG-Harmony-Core_designer-return_CDX_2026-10-04.zip'
MANIFEST = 'asset-manifest.csv'
INVENTORY = 'audit/package-inventory.json'
FOLDERS = 'audit/folder-sizes.txt'
VALIDATION = 'audit/package-validation.json'
GENERATED = {MANIFEST, INVENTORY, FOLDERS, VALIDATION}
LOOP_KINDS = {'orb_loop_1024', 'orb_loop_512'}
STORED_SUFFIXES = {'.png', '.mp4', '.blend', '.jpg', '.jpeg', '.webp', '.gif', '.zip', '.gz', '.pdf'}
PROOF_DIRECTORY = re.compile(r'^batch(?:-.*)?-?test$')
PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
EXPECTED_COUNTS = {'animation_pngs': 3600, 'static_pngs': 133, 'manifest_entries': 3735}
REQUIRED = {
    'README.md', 'CHANGELOG.md', 'SPEC.txt', 'SPEC.json',
    'source/harmony_assets.blend', 'source/harmony_animation.blend',
    'source/harmony_supporting.blend', 'source/harmony_core_build.py',
    'source/harmony_batch_render.py', 'source/harmony_batch_render_NOTES.md',
    'source/harmony_supporting_build.py', 'reference/harmony-theme-preview.html',
    'audit/original-preservation.json', 'audit/final-scene-checks.json',
    'audit/static-assets-validation.json', 'audit/animation-final-qa.json',
    'audit/theme-preview-qa.json', 'audit/video-build.json',
    'loop_check/orb_loop_preview.mp4', 'loop_check/tech_midnight.mp4',
    'loop_check/friendly_midnight.mp4',
}

class PackageError(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise PackageError(message)

def relative_path(value):
    p = PurePosixPath(value)
    require('\\' not in value and not re.match(r'^[A-Za-z]:', value)
            and not p.is_absolute() and '..' not in p.parts and str(p) not in ('', '.'),
            f'Unsafe relative path: {value!r}')
    return p.as_posix()

def read_json(root, relative):
    return json.loads((root / relative_path(relative)).read_text())

def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def png_info(path):
    """Read actual IHDR metadata and verify every PNG chunk CRC and complete IEND."""
    result = None
    idat = False
    with path.open('rb') as stream:
        require(stream.read(8) == PNG_SIGNATURE, f'Invalid PNG signature: {path}')
        first = True
        while True:
            header = stream.read(8)
            require(len(header) == 8, f'Truncated PNG chunk: {path}')
            length, kind = struct.unpack('>I4s', header)
            require(not first or (kind == b'IHDR' and length == 13), f'Invalid PNG IHDR: {path}')
            require(length <= path.stat().st_size, f'Invalid PNG chunk length: {path}')
            crc = zlib.crc32(kind)
            remaining = length
            ihdr = b''
            while remaining:
                chunk = stream.read(min(remaining, 1024 * 1024))
                require(chunk, f'Truncated PNG payload: {path}')
                crc = zlib.crc32(chunk, crc)
                if kind == b'IHDR':
                    ihdr += chunk
                remaining -= len(chunk)
            trailer = stream.read(4)
            require(len(trailer) == 4 and struct.unpack('>I', trailer)[0] == crc & 0xffffffff,
                    f'PNG CRC mismatch: {path}')
            if kind == b'IHDR':
                require(result is None, f'Duplicate PNG IHDR: {path}')
                w, h, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', ihdr)
                require(w > 0 and h > 0 and compression == 0 and filtering == 0 and interlace in (0, 1),
                        f'Invalid PNG dimensions/encoding: {path}')
                result = {'width': w, 'height': h, 'bit_depth': depth, 'color_type': color,
                          'mode': {0: 'L', 2: 'RGB', 3: 'P', 4: 'LA', 6: 'RGBA'}.get(color, 'unknown')}
            if kind == b'IDAT':
                idat = True
            if kind == b'IEND':
                require(length == 0 and idat and not stream.read(1), f'Invalid PNG ending: {path}')
                return result
            first = False

def load_manifest(root):
    seed = root / 'reference/asset-manifest-original.csv'
    with seed.open(newline='') as stream:
        reader = csv.DictReader(stream)
        fields = list(reader.fieldnames or [])
        rows = list(reader)
    require(len(rows) == EXPECTED_COUNTS['manifest_entries'], 'Original manifest must contain 3735 entries.')
    paths = set()
    for row in rows:
        row['original_path'] = relative_path(row['path'])
        if row['path'] == 'blend/harmony_assets.blend':
            row['path'] = 'source/harmony_assets.blend'
        row['path'] = relative_path(row['path'])
        require(row['path'] not in paths, f'Duplicate manifest path: {row["path"]}')
        paths.add(row['path'])
    require(sum(r['kind'] in LOOP_KINDS for r in rows) == 3600, 'Expected 3600 animation entries.')
    require(sum(r['path'].endswith('.png') and r['kind'] not in LOOP_KINDS for r in rows) == 133,
            'Expected 133 static PNG entries.')
    return fields, rows

def verify_originals(root):
    proof = read_json(root, 'audit/original-preservation.json')
    mapping = proof.get('mapping', [])
    require(proof.get('all_original_files_preserved_byte_identically') is True and len(mapping) == 12,
            'Original preservation evidence must account for all 12 uploaded files.')
    for entry in mapping:
        relative = 'reference/' + relative_path(entry['preserved_at'])
        path = root / relative
        require(entry.get('byte_identical') is True and path.is_file(), f'Original missing: {relative}')
        require(sha256(path) == entry['sha256'], f'Preserved original changed: {relative}')
    return mapping

def verify_qa(root):
    animation = read_json(root, 'audit/animation-final-qa.json')
    required_flags = ['passed', 'all_expected_frames_present', 'all_PNG_headers_and_endings_valid',
                      'all_PNG_chunk_CRCs_valid', 'all_sampled_edges_fully_transparent',
                      'endpoint_comparisons_pass']
    require(all(animation.get(k) is True for k in required_flags), 'Final animation QA has not passed.')
    require(animation.get('actual_image_count') == animation.get('expected_image_count') == 3600
            and animation.get('sequence_folder_count') == 30, 'Final animation QA counts are incomplete.')
    require(len(animation.get('looks', [])) == 30 and len(animation.get('endpoint_comparisons', [])) == 30,
            'Final animation QA must cover all 30 sequences and endpoints.')
    static = read_json(root, 'audit/static-assets-validation.json')
    require(static.get('status') == 'passed' and static.get('files') == 133, 'Static asset QA has not passed.')
    scene = read_json(root, 'audit/final-scene-checks.json')
    require(scene.get('passed') is True and len(scene.get('masters', [])) == 2, 'Final master scene QA has not passed.')
    for master in scene['masters']:
        require(master.get('passed') is True, f'Master QA failed: {master.get("path")}')
        path = root / relative_path(master['path'])
        require(sha256(path) == master['sha256'], f'Master changed since final QA: {master["path"]}')
    theme = read_json(root, 'audit/theme-preview-qa.json')
    require(theme.get('status') == 'passed' and not theme.get('failures') and not theme.get('missing_assets'),
            'Final actual-asset browser QA has not passed.')
    require(len(theme.get('png_assets', [])) >= 63 and len(theme.get('video_assets', [])) == 3
            and theme.get('browser', {}).get('combinations') == 240,
            'Browser QA must cover actual PNGs, all three movies and 240 combinations.')
    require(not theme['browser'].get('javascript_errors') and not theme['browser'].get('http_errors')
            and not theme['browser'].get('request_failures'), 'Browser QA contains runtime/network errors.')
    video = read_json(root, 'audit/video-build.json')
    outputs = video.get('outputs', [])
    expected_movies = {'loop_check/orb_loop_preview.mp4', 'loop_check/tech_midnight.mp4',
                       'loop_check/friendly_midnight.mp4'}
    require({o.get('path') for o in outputs} == expected_movies, 'All three rendered playback movies are required.')
    video_metadata = {}
    for output in outputs:
        movie = output.get('movie', {})
        require(output.get('source_loop_frames') == 120 and output.get('composited_frames') == 120
                and output.get('playbacks') == 2, f'Incomplete movie source: {output.get("path")}')
        require(movie.get('width') == movie.get('height') == 512 and movie.get('fps') == 30
                and movie.get('frames') == 240 and abs(movie.get('duration', 0) - 8) <= .03,
                f'Invalid movie duration/dimensions: {output.get("path")}')
        require((root / output['path']).stat().st_size == movie['bytes'],
                f'Movie changed since Blender composition/encode: {output["path"]}')
        video_metadata[output['path']] = movie
    return video_metadata

def pipeline(row=None, path=''):
    if row and not path:
        path = row['path']
    if row and row['kind'] in LOOP_KINDS:
        return ('Blender5.2.2 EEVEE realtime atmosphere; scene-linear palette grade; native1024; '
                + ('Blender bicubic512 export' if row['kind'] == 'orb_loop_512' else 'native1024 export'))
    if row and row['kind'] in {'orb_still', 'orb_state_still'}:
        return 'Blender5.2.2 EEVEE palette-specific beauty; scene-linear PNG finish'
    if row and row['path'].endswith('.png'):
        return 'Blender5.2.2 EEVEE native supporting render'
    if path.startswith('reference/'):
        return 'preserved original handoff' if '-original' in path or path.endswith('original-asset-spec.txt') else 'handoff reference'
    if path.endswith('.mp4'):
        return 'Blender rendered-frame composition; FFmpeg H264 playback encode'
    if path.startswith('audit/loop/'):
        return 'Blender optimized graded frame121 seam reference'
    if path.endswith('.blend'):
        return 'editable Blender5.2.2 scene'
    return 'source/documentation/audit'

def archive_path(relative):
    """Discard generated work files; relocate small benchmark evidence logs."""
    p = PurePosixPath(relative)
    if '__pycache__' in p.parts or p.suffix.lower() in {'.pyc', '.pyo'}:
        return None
    if re.search(r'\.blend\d+$', p.name, re.I) or p.name in {'.DS_Store', 'Thumbs.db'}:
        return None
    if relative == 'audit/polished-scene.json':
        return None
    for i, part in enumerate(p.parts):
        if PROOF_DIRECTORY.fullmatch(part):
            if p.suffix.lower() not in {'.json', '.jsonl'}:
                return None
            return PurePosixPath('audit/proof-evidence', part, *p.parts[i + 1:]).as_posix()
    return relative

def snapshot(root, source, archive, metadata=None, render_pipeline=None):
    path = root / source
    require(not path.is_symlink(), f'Symlinks are not packaged: {source}')
    before = path.stat()
    record = {'path': archive, 'bytes': before.st_size, 'sha256': sha256(path),
              'pipeline': render_pipeline or pipeline(path=archive)}
    if source != archive:
        record['source_path'] = source
    if metadata:
        record.update(metadata)
    after = path.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            f'File changed during scan; freeze sources/renders first: {source}')
    return record, (before.st_size, before.st_mtime_ns)

def validate_production(root, rows):
    expected_pngs = {r['path'] for r in rows if r['path'].endswith('.png')}
    actual_pngs = {p.relative_to(root).as_posix() for folder in ['orb', 'mark', 'backgrounds', 'pins']
                   for p in (root / folder).rglob('*.png')}
    require(actual_pngs == expected_pngs,
            f'Production PNG mismatch. Missing: {sorted(expected_pngs - actual_pngs)[:15]}; '
            f'unexpected: {sorted(actual_pngs - expected_pngs)[:15]}')
    cache = {}
    stamps = {}
    for index, row in enumerate(rows, 1):
        path = root / row['path']
        require(path.is_file() and path.stat().st_size > 0, f'Required manifest file missing/empty: {row["path"]}')
        metadata = png_info(path) if path.suffix == '.png' else {}
        if metadata:
            require((metadata['width'], metadata['height']) == (int(row['width']), int(row['height']))
                    and metadata['bit_depth'] == 8, f'PNG dimensions/depth mismatch: {row["path"]}')
            require(metadata['mode'] == ('RGBA' if row['transparent'] == 'yes' else 'RGB'),
                    f'PNG mode mismatch: {row["path"]}')
        record, stamp = snapshot(root, row['path'], row['path'], metadata, pipeline(row))
        cache[row['path']] = record; stamps[row['path']] = stamp
        row.update({'actual_width': metadata.get('width', ''), 'actual_height': metadata.get('height', ''),
                    'mode': metadata.get('mode', ''), 'bytes': record['bytes'], 'sha256': record['sha256'],
                    'pipeline': record['pipeline'],
                    'status': 'rendered_graded' if row['kind'] in LOOP_KINDS else
                              'rendered' if metadata else 'complete'})
        if index % 200 == 0:
            print(f'PRODUCTION_VALIDATED {index}/{len(rows)}', flush=True)
    return cache, stamps

def write_manifest(root, fields, rows):
    columns = fields + ['original_path', 'actual_width', 'actual_height', 'mode', 'bytes', 'sha256', 'pipeline']
    with (root / MANIFEST).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader(); writer.writerows(rows)

def folder_stats(records):
    stats = collections.defaultdict(lambda: {'files': 0, 'bytes': 0})
    for entry in records:
        parts = PurePosixPath(entry['path']).parts[:-1]
        for i in range(1, len(parts) + 1):
            key = '/'.join(parts[:i]);stats[key]['files'] += 1;stats[key]['bytes'] += entry['bytes']
        if not parts:
            stats['(root files)']['files'] += 1;stats['(root files)']['bytes'] += entry['bytes']
    return {k: {**v, 'decimal_MB': round(v['bytes'] / 1e6, 6)} for k, v in sorted(stats.items())}

def folder_report(inventory):
    lines = ['PHG Harmony Core — completed delivery inventory',
             'Handoff date: 2026-10-04',
             f'Files: {inventory["file_count"]}',
             f'Uncompressed bytes: {inventory["total_bytes"]}',
             f'Uncompressed decimal MB: {inventory["total_bytes"] / 1e6:.6f}',
             'Production: 3600 animation PNGs + 133 static PNGs.',
             'Animation pipeline: native1024 Blender EEVEE, scene-linear palette grade, Blender512 downsample.',
             '12 incoming files preserved byte-identically under reference/.',
             '', 'Folder counts include descendants; nested rows must not be added together.',
             'Folder | files | bytes | decimal MB']
    lines += [f'{k} | {v["files"]} | {v["bytes"]} | {v["decimal_MB"]:.6f}'
              for k, v in inventory['folders'].items()]
    return '\n'.join(lines) + '\n'

def write_inventory(root, records, excluded, preservation):
    # The inventory lists its own byte size, but cannot hash itself. Its hash is
    # included in the external archive receipt. The text report is fully hashed.
    records = sorted(records, key=lambda e: e['path'])
    own = {'path': INVENTORY, 'bytes': 0, 'sha256': None, 'pipeline': 'generated inventory',
           'integrity_note': 'Self-hash is in the archive receipt beside the ZIP.'}
    text = {'path': FOLDERS, 'bytes': 0, 'sha256': '', 'pipeline': 'generated folder inventory'}
    records += [own, text];records.sort(key=lambda e: e['path'])
    inventory = {'schema_version': 1, 'handoff_date': '2026-10-04',
                 'created_utc': datetime.now(timezone.utc).isoformat(),
                 'archive_name': ARCHIVE_NAME, 'production_counts': EXPECTED_COUNTS,
                 'preserved_originals': preservation, 'excluded_work_files': excluded,
                 'file_count': len(records), 'files': records}
    for _ in range(50):
        inventory['total_bytes'] = sum(e['bytes'] for e in records)
        inventory['folders'] = folder_stats(records)
        report = folder_report(inventory).encode('utf-8')
        state = (own['bytes'], text['bytes'], text['sha256'])
        text.update(bytes=len(report), sha256=hashlib.sha256(report).hexdigest())
        data = (json.dumps(inventory, indent=2, ensure_ascii=False) + '\n').encode('utf-8')
        own['bytes'] = len(data)
        if state == (own['bytes'], text['bytes'], text['sha256']):
            break
    else:
        raise PackageError('Inventory byte-size fixed point did not converge.')
    (root / FOLDERS).write_bytes(report);(root / INVENTORY).write_bytes(data)
    return inventory

def build_zip(root, output, records, stamps, replace):
    require(replace or not output.exists(), f'Archive exists; use --replace to replace it: {output}')
    output.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix=output.name + '.partial-', dir=output.parent)
    os.close(handle);temporary = Path(temporary)
    try:
        with zipfile.ZipFile(temporary, 'w', allowZip64=True) as archive:
            for index, entry in enumerate(records, 1):
                source = entry.get('source_path', entry['path']);path = root / source
                stat = path.stat()
                require((stat.st_size, stat.st_mtime_ns) == stamps[source], f'File changed before ZIP: {source}')
                info = zipfile.ZipInfo.from_file(path, arcname=entry['path'], strict_timestamps=False)
                info.compress_type = zipfile.ZIP_STORED if path.suffix.lower() in STORED_SUFFIXES else zipfile.ZIP_DEFLATED
                info._compresslevel = 6
                digest = hashlib.sha256()
                with path.open('rb') as stream, archive.open(info, 'w', force_zip64=True) as target:
                    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                        digest.update(chunk);target.write(chunk)
                require(digest.hexdigest() == entry['sha256'], f'File changed while archiving: {source}')
                if index % 200 == 0:
                    print(f'ZIP_WRITTEN {index}/{len(records)}', flush=True)
        with zipfile.ZipFile(temporary) as archive:
            require(len(archive.infolist()) == len(records), 'ZIP entry count mismatch.')
            bad = archive.testzip();require(bad is None, f'ZIP CRC verification failed: {bad}')
        with temporary.open('rb') as stream:
            os.fsync(stream.fileno())
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {'path': str(output), 'bytes': output.stat().st_size, 'sha256': sha256(output),
            'files': len(records), 'inventory_sha256': sha256(root / INVENTORY),
            'compression': 'PNG/MP4/BLEND stored; text deflated', 'all_archive_CRCs_valid': True}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ready', action='store_true', help='Root/operator confirms all renders, QA and source freeze complete.')
    parser.add_argument('--root', type=Path, default=DEFAULT_ROOT)
    parser.add_argument('--output', type=Path, default=DEFAULT_ROOT.parent / 'output' / ARCHIVE_NAME)
    parser.add_argument('--validate-only', action='store_true', help='Generate complete inventories without the ZIP.')
    parser.add_argument('--replace', action='store_true', help='Atomically replace an existing final ZIP.')
    args = parser.parse_args()
    if not args.ready:
        parser.error('--ready is required. Hold until root confirms final rendering, QA and source freeze.')
    root = args.root.resolve();started = time.monotonic()
    require(root.is_dir(), f'Handoff root not found: {root}')
    require(not args.output.resolve().is_relative_to(root), 'The ZIP destination must be outside the payload root.')
    missing = [p for p in sorted(REQUIRED) if not (root / p).is_file() or (root / p).stat().st_size == 0]
    require(not missing, 'Required handoff files missing: ' + ', '.join(missing))
    fields, rows = load_manifest(root)
    preservation = verify_originals(root)
    video_metadata = verify_qa(root)
    cache, stamps = validate_production(root, rows)
    for style in ['calm', 'tech', 'friendly']:
        for palette in ['midnight', 'aurora', 'ocean', 'ember', 'ivory']:
            for size in [1024, 512]:
                folder = f'{style}_{palette}' + ('_512' if size == 512 else '')
                p = root / 'audit/loop' / folder / 'loop_f121.png'
                require(p.is_file(), f'Final endpoint audit asset missing: {p.relative_to(root)}')
                info = png_info(p)
                require(info['width'] == info['height'] == size and info['mode'] == 'RGBA', f'Invalid seam asset: {p}')
    write_manifest(root, fields, rows)
    validation = {'passed': True, **EXPECTED_COUNTS, 'originals_preserved': 12,
                  'PNG_chunk_CRCs_valid': True, 'required_modes_and_dimensions_valid': True,
                  'all_final_QA_gates_passed': True, 'endpoint_reference_pngs': 30,
                  'scope': 'Structural PNG integrity/counts and current QA hashes; full pixel/browser/scene QA is in cited reports.',
                  'QA_reports': ['audit/animation-final-qa.json', 'audit/static-assets-validation.json',
                                 'audit/final-scene-checks.json', 'audit/theme-preview-qa.json', 'audit/video-build.json']}
    (root / VALIDATION).write_text(json.dumps(validation, indent=2) + '\n')
    records = [];excluded = [];seen = set()
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        source = path.relative_to(root).as_posix()
        if source in {INVENTORY, FOLDERS}:
            continue
        target = archive_path(source)
        if target is None:
            excluded.append(source);continue
        require(target not in seen, f'Archive name collision: {target}');seen.add(target)
        if source in cache:
            record = cache[source]
        else:
            metadata = png_info(path) if path.suffix.lower() == '.png' else video_metadata.get(source)
            record, stamp = snapshot(root, source, target, metadata)
            stamps[source] = stamp
        records.append(record)
    inventory = write_inventory(root, records, excluded, preservation)
    for relative in [INVENTORY, FOLDERS]:
        record, stamp = snapshot(root, relative, relative)
        records.append(record);stamps[relative] = stamp
    records.sort(key=lambda e: e['path'])
    require(sum(e['bytes'] for e in records) == inventory['total_bytes'], 'Inventory final byte total mismatch.')
    print(json.dumps({'validation': 'passed', 'files': len(records), 'uncompressed_bytes': inventory['total_bytes'],
                      'excluded_work_files': len(excluded), 'seconds': round(time.monotonic() - started, 3)}), flush=True)
    if not args.validate_only:
        receipt = build_zip(root, args.output.resolve(), records, stamps, args.replace)
        receipt['seconds'] = round(time.monotonic() - started, 3)
        args.output.with_suffix('.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        args.output.with_suffix('.zip.sha256').write_text(receipt['sha256'] + '  ' + args.output.name + '\n')
        print(json.dumps(receipt), flush=True)

if __name__ == '__main__':
    try:
        main()
    except (PackageError, OSError, ValueError, TypeError, KeyError, struct.error, csv.Error, zipfile.BadZipFile) as error:
        print(f'PACKAGE_REFUSED: {error}', file=sys.stderr, flush=True)
        sys.exit(1)
