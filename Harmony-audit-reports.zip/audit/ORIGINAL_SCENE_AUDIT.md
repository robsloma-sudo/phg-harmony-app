# Original Blender scene audit

The supplied `harmony_assets.blend` opens successfully in Blender **5.2.2 LTS**, using the official `bpy` Python module. It was loaded with `use_scripts=False` and was never saved or modified on disk. The scene contains **42 objects** and **13 materials**. `original-scene.json` records objects, transforms, mesh extents, material properties, node sockets and defaults, ramps, links, drivers, keyframes, camera, lights, render settings, world, compositor, and evaluated frames 1, 30, 60, 61, 90, 119, 120 and 121.

`script-vs-source.json` records a separate, unsaved reconstruction from the supplied build script and its differences from the original scene. The saved Blender file is the appropriate baseline for the polish.

## Verified settings

- EEVEE, 64 render samples, 1024 square, PNG RGBA 8-bit, Film Transparent, Standard view transform, no look, exposure 0, gamma 1.
- Volumes use 2 px tiles, 96 samples, distribution 0.8 and volumetric shadows.
- Camera remains orthographic, scale 7.2, rotation X 82 degrees, position approximately (0, -19.8054, 2.78346).
- Core breathes 1.00 at frame 1, 1.05 at 61 and 1.00 at 121, with auto-clamped Bezier interpolation.
- Nucleus turns 360 degrees and orbit A 360, B -360 and C 120, all linear between frames 1 and 121.
- Nucleon meshes have local radius 0.13, object scale 1.30, giving effective radius 0.169. Their centers are radius 0.27 from the origin.
- Material LoopT drivers evaluate correctly as `(frame-1)/120`, including when the file is opened with scripts disabled.
- The shell gradient is present in its shader: 0.22 dark gold, 0.60 accent, 0.90 accent2, 1.00 accent2 plus 35% white. Shell emission is 0.30 + 1.30 × veins. Alpha is 0.32 + 0.63 × facing^1.4. Blue rim emission is 2.00 × facing^2.2.
- Nucleus emissive Principled materials use roughness 0.25, coat 1.00, coat roughness 0.03 and emission 1.80 for protons / 1.60 for neutrons.
- Key / rim / core lights are 70 / 150 / 250 W.
- Bloom is high quality, threshold 0.70, strength 1.00, size 0.70, saturation 1.00.
- The compositor adds glare to the render RGB, then sets alpha to the greater of render alpha and the brightest resulting channel, clipped at 1.00.

## Differences that matter

The original script produces a materially different scene. Its key and core lights are 120 and 900 W; its nucleus uses additive emission-only spheres with radius 0.13 and center radius 0.20; its shell emits 0.45 + 2.20 × veins with center alpha 0.50; its plasma density multiplier is 3.00 and emission 6.00; its nebula density multiplier is 0.90 and emission 1.10. The saved scene instead uses the values above, plasma density multiplier 0.25 and emission 1.60, and nebula density multiplier 0.55 and emission 3.00.

The draft correctly describes many saved changes, but its nebula color-ramp positions differ. The actual NebRamp is **LINEAR** with stops **0.40, 0.49, 0.56 and 0.64**; the script uses EASE at 0.30, 0.50, 0.66 and 0.78. The saved third ramp color mixes accent2 with 25% white; the script uses 20% white.

The saved nebula Principled Volume **Color socket is unlinked**, fixed at linear RGBA **(0.25, 0.25, 0.35, 1.0)**. Only its emission color is linked to the palette ramp. This is a significant source of uniform lavender scattering and must be changed to a palette-derived color or linked color for reliable theming. The plasma Volume Color is fixed black, so it behaves mainly as a faint emission haze.

## Loop assessment

No mathematical loop defects were found in the saved scene. All transform endpoints correctly use frame **121**, and rotating orbit C by 120 degrees permutes its three identical, evenly spaced electrons. Each animated material uses integer cycles. Noise follows the existing circular sin/cos offset through 4D noise, synapses travel two full cycles and dust twinkles three. Rendered seam comparison remains necessary because correct mathematics does not rule out stochastic flicker.

## Transparency and framing defects

Both supplied transparent previews contain nonzero alpha on the image edge:

| Frame | Maximum edge alpha | Nonzero edge pixels | Maximum alpha within the outer 10 pixels |
|---|---:|---:|---:|
| 1 | 16 / 255 | 2,056 | 17 / 255 |
| 45 | 15 / 255 | 2,552 | 19 / 255 |

The nebula ellipsoid multiplies world coordinates by (0.8, 0.9, 1.15), then fades to zero at radius 3.3. Its theoretical X extent is **3.3 / 0.8 = 4.125**, beyond the camera half-width of **3.6**. This is a geometry/shader framing problem as well as a bloom problem. Correcting the volume envelope is the first step; a finite final compositor mask protects against glow reaching the edges.

Blender 5.2 uses socket-based compositor settings. `CompositorNodeEllipseMask` offers Position and Size in normalized frame coordinates. `CompositorNodeBlur` Size is a two-dimensional **PIXEL** socket. `CompositorNodeSetAlpha` with Type `Apply Mask` multiplies both premultiplied RGB and alpha. A feathered finite ellipse after the existing brightest-channel alpha stage therefore preserves glow-to-alpha while creating a truly clear margin. A normalized width/height near 0.84 and Gaussian blur radius around 30 pixels at 1024 is a useful starting point; scale the blur with output resolution. Validate the outer margin after rendering. Avoid changing only alpha while leaving premultiplied RGB untouched.

## Design and performance recommendations

1. Restore deliberate shell color by lowering blue rim emission and reducing white admixture, then moving the blue gradient stop slightly inward. Make the bottom a darker palette-derived gold/background mix. Reduce vein noise detail and distortion for broader, flowing currents instead of granular filaments. Preserve `Ramp`, `BSDF`, `ShellEmit`, `ShellAlpha` and `RimStrength` names.
2. Give nucleus spheres darker palette-derived body color, low metallic weight, tighter roughness and a crisp coat highlight. Lower constant emission so shading survives. Use a small normal-dependent inner-light modulation rather than more additive white. Preserve the existing nucleus geometry arrangement and 360-degree rotation.
3. Electron A's current linear color (0.7704, 0.5839, 0.3358) at strength 3.00 exceeds 1.00 in every RGB channel. Standard clips that to white before additional glow. Remove most white mixing and use emission near 1.00–1.20 for the colored body, with any small hot center treated separately. Longer tails with lower peaks improve motion cues without increasing glare.
4. Replace fixed lavender nebula scattering with palette-derived color. Keep broad darker nebula regions, add a limited number of brighter knots, and reserve warm accent color for selected areas. A world radial safety mask at radius approximately 3.1–3.2 ensures the ellipsoid cannot exceed the camera frame.
5. Split synapse brightness and thickness into a few hero strands and many quieter fine branches. Make pulses narrow at the leading edge with a longer fading tail; the existing UV length/phase system supports this without changing loop time.
6. Reduce bloom strength and size before increasing light power. The nucleus should own the brightest large form; ring heads and synaptic sparks should be small accents. Preserve Standard so recoloring remains predictable.
7. Preserve EEVEE 2 px / 96 volume settings initially. Optimize redundant noise detail, oversized empty volume bounds, and unnecessary volume-light interactions before changing locked quality. Actual render times depend strongly on hardware and must be measured rather than inferred from the original 3-second reference.

All recommendations are technical and visual observations for the main implementation. This audit produced no renders and changed no original assets.
