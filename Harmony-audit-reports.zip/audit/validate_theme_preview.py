#!/usr/bin/env python3
"""Audit the delivered offline Harmony page against its real package assets.

No fixtures, replacements, intercepted image responses, or generated artwork are
used. Browser screenshots are documentary HTML captures, saved only in
``audit/browser-screenshots``. Run after all 15 still sets, three state PNGs, and
three Midnight MP4s have finished rendering:

    python audit/validate_theme_preview.py

Dependencies: Pillow, Playwright with Chromium, and ffprobe. An installed system
Chromium is preferred; otherwise Playwright's installed browser is used.
``--static-only`` reports incomplete assets without launching a browser.
``--wait-assets 1800`` optionally polls real files for up to 30 minutes.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from fractions import Fraction
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import re
from pathlib import Path
import shutil
import subprocess
import sys
from threading import Thread
import time
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
STYLES = ('calm', 'tech', 'friendly')
PALETTES = ('midnight', 'aurora', 'ocean', 'ember', 'ivory')
VIEWS = ('studio', 'harmony', 'atlas', 'kit')
WIDTHS = (320, 390, 768, 1440)
STATES = ('listening', 'thinking', 'speaking')
LOOPS = {'calm': 'loop_check/orb_loop_preview.mp4',
         'tech': 'loop_check/tech_midnight.mp4',
         'friendly': 'loop_check/friendly_midnight.mp4'}


def expected_assets():
    assets = {'reference/harmony-theme-preview.html': 'html'}
    for style in STYLES:
        for palette in PALETTES:
            look = f'{style}_{palette}'
            assets[f'orb/{look}_still.png'] = 'orb'
            assets[f'mark/mark_{look}.png'] = 'mark'
            assets[f'mark/icons/mark_{look}_512.png'] = 'icon'
            assets[f'backgrounds/bg_{look}.png'] = 'background'
    for state in STATES:
        assets[f'orb/states/state_{state}.png'] = 'state'
    assets.update({path: 'video' for path in LOOPS.values()})
    return assets


def inventory(root):
    return [relative for relative in expected_assets()
            if not (root / relative).is_file() or (root / relative).stat().st_size == 0]


def png_checks(root):
    from PIL import Image
    results, failures = [], []
    for relative, kind in expected_assets().items():
        if not relative.endswith('.png'):
            continue
        path = root / relative
        try:
            with Image.open(path) as image:
                image.verify()
            with Image.open(path) as image:
                image.load()
                result = {'path': relative, 'size': list(image.size), 'mode': image.mode,
                          'bytes': path.stat().st_size}
                if kind in ('orb', 'mark', 'state'):
                    if image.size != (1024, 1024):
                        failures.append(f'{relative}: expected 1024 × 1024, got {image.size}')
                    if image.mode != 'RGBA':
                        failures.append(f'{relative}: expected RGBA transparency')
                    else:
                        alpha = image.getchannel('A')
                        w, h = image.size
                        perimeter = (list(alpha.crop((0, 0, w, 1)).getdata()) +
                                     list(alpha.crop((0, h - 1, w, h)).getdata()) +
                                     list(alpha.crop((0, 0, 1, h)).getdata()) +
                                     list(alpha.crop((w - 1, 0, w, h)).getdata()))
                        result['maximum_edge_alpha'] = max(perimeter)
                        if result['maximum_edge_alpha']:
                            failures.append(f'{relative}: nonzero alpha at outer canvas edge')
                elif kind == 'icon':
                    if image.size != (512, 512):
                        failures.append(f'{relative}: expected 512 × 512 app icon')
                    if 'A' in image.getbands() and image.getchannel('A').getextrema() != (255, 255):
                        failures.append(f'{relative}: app icon is not fully opaque')
                elif kind == 'background':
                    if image.width <= image.height:
                        failures.append(f'{relative}: expected landscape background')
                    if 'A' in image.getbands() and image.getchannel('A').getextrema() != (255, 255):
                        failures.append(f'{relative}: background is not fully opaque')
                results.append(result)
        except Exception as error:
            failures.append(f'{relative}: {error}')
    return results, failures


def video_checks(root, expected_duration):
    ffprobe = shutil.which('ffprobe')
    if not ffprobe:
        return [], ['ffprobe is required to verify video frame rate and frame count']
    results, failures = [], []
    for style, relative in LOOPS.items():
        result = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'v:0',
                                 '-show_entries',
                                 'stream=width,height,codec_name,pix_fmt,r_frame_rate,avg_frame_rate,nb_frames:format=duration',
                                 '-of', 'json', str(root / relative)], capture_output=True,
                                text=True, timeout=30)
        if result.returncode:
            failures.append(f'{relative}: ffprobe failed: {result.stderr.strip()}')
            continue
        data = json.loads(result.stdout)
        stream = data['streams'][0]
        duration = float(data['format']['duration'])
        fps = float(Fraction(stream['avg_frame_rate']))
        frames = int(stream.get('nb_frames', 0))
        entry = {'style': style, 'path': relative, 'duration': duration,
                 'fps': fps, 'frames': frames, 'width': stream['width'],
                 'height': stream['height'], 'codec': stream['codec_name'],
                 'pixel_format': stream.get('pix_fmt')}
        results.append(entry)
        if abs(duration - expected_duration) > .03:
            failures.append(f'{relative}: expected {expected_duration}s, got {duration}s')
        if fps != 30 or frames != round(expected_duration * 30):
            failures.append(f'{relative}: expected 30 fps / {round(expected_duration * 30)} frames, got {fps} / {frames}')
        if (stream['width'], stream['height']) != (512, 512):
            failures.append(f'{relative}: expected native 512 × 512 review video')
        if stream['codec_name'] != 'h264' or stream.get('pix_fmt') != 'yuv420p':
            failures.append(f'{relative}: expected H.264 / yuv420p for browser playback')
    return results, failures


def local_package_handler(root):
    """Serve actual package files with byte-range support for native MP4 seeking."""
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(root), **kwargs)

        def log_message(self, *args):
            pass

        def do_GET(self):
            if urlparse(self.path).path == '/favicon.ico':
                self.send_response(204)
                self.end_headers()
                return
            path = Path(self.translate_path(self.path))
            if path.suffix.lower() != '.mp4' or not path.is_file():
                super().do_GET()
                return
            size = path.stat().st_size
            start, end, status = 0, size - 1, 200
            requested = self.headers.get('Range')
            if requested:
                match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested.strip())
                if not match or not any(match.groups()):
                    self.send_error(416, 'Unsupported byte range')
                    return
                first, last = match.groups()
                if first:
                    start = int(first)
                    end = min(int(last), size - 1) if last else size - 1
                else:
                    start = max(0, size - int(last))
                if start >= size or start > end:
                    self.send_response(416)
                    self.send_header('Content-Range', f'bytes */{size}')
                    self.end_headers()
                    return
                status = 206
            self.send_response(status)
            self.send_header('Content-Type', 'video/mp4')
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Content-Length', str(end - start + 1))
            if status == 206:
                self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
            self.end_headers()
            try:
                with path.open('rb') as stream:
                    stream.seek(start)
                    remaining = end - start + 1
                    while remaining:
                        chunk = stream.read(min(65536, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass  # Browser canceled a superseded media request.
    return Handler


def browser_checks(root, port, browser_path, expected_duration):
    from playwright.sync_api import sync_playwright
    failures, requests, responses, errors, playback = [], [], [], [], []
    screenshots = []

    server = ThreadingHTTPServer(('127.0.0.1', port), local_package_handler(root))
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    screenshot_dir = root / 'audit/browser-screenshots'
    screenshot_dir.mkdir(parents=True, exist_ok=True)
    (screenshot_dir / 'README.md').write_text(
        '# Browser review captures\n\n'
        'These PNGs are documentary Chromium screenshots of the offline HTML '
        'theme preview, including the actual Blender-rendered assets. They are '
        'not new artwork or Blender render outputs.\n', encoding='utf-8')

    try:
        with sync_playwright() as playwright:
            launch = {'headless': True, 'args': ['--no-sandbox']}
            selected_browser = browser_path or shutil.which('chromium') or shutil.which('chromium-browser')
            if selected_browser:
                launch['executable_path'] = selected_browser
            browser = playwright.chromium.launch(**launch)
            page = browser.new_page(viewport={'width': 1440, 'height': 1100}, device_scale_factor=1)
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.on('requestfailed', lambda request: requests.append(
                {'url': request.url, 'failure': request.failure}))
            page.on('response', lambda response: responses.append(
                {'url': response.url, 'status': response.status}) if response.status >= 400 else None)

            def allow_local(route):
                parsed = urlparse(route.request.url)
                if parsed.scheme in ('data', 'blob') or (parsed.hostname == '127.0.0.1' and parsed.port == server.server_port):
                    route.continue_()
                else:
                    failures.append('External network dependency: ' + route.request.url)
                    route.abort()
            # No image response is intercepted or replaced. The route only
            # enforces that the page stays within its actual local package.
            page.route('**/*', allow_local)
            page.goto(base + '/reference/harmony-theme-preview.html', wait_until='networkidle')
            page.evaluate("document.querySelectorAll('img').forEach(img => img.loading = 'eager')")
            page.emulate_media(reduced_motion='reduce')
            page.wait_for_function("document.body.dataset.motion === 'paused'")

            def images_ready():
                page.wait_for_function("""() => [...document.querySelectorAll('img[src]')]
                    .filter(img => img.getAttribute('src'))
                    .every(img => img.complete && img.naturalWidth > 0)""", timeout=20000)

            for width in WIDTHS:
                page.set_viewport_size({'width': width, 'height': 1000})
                for style in STYLES:
                    page.locator(f'.segment[data-style-opt="{style}"]').click()
                    for palette in PALETTES:
                        page.locator(f'.palette-button[data-pal-opt="{palette}"]').click()
                        images_ready()
                        expected = {
                            '#brandImage': f'../mark/mark_{style}_{palette}.png',
                            '#assetMark': f'../mark/mark_{style}_{palette}.png',
                            '#assetIcon': f'../mark/icons/mark_{style}_{palette}_512.png',
                            '#assetBackground': f'../backgrounds/bg_{style}_{palette}.png',
                            '.core-image': f'../orb/{style}_{palette}_still.png'}
                        for selector, source in expected.items():
                            if page.locator(selector).first.get_attribute('src') != source:
                                failures.append(f'Wrong image source at {width}/{style}/{palette}: {selector}')
                        for view in VIEWS:
                            page.locator(f'.tab[data-view="{view}"]').click()
                            if not page.locator('#v-' + view).is_visible():
                                failures.append(f'Inactive screen at {width}/{style}/{palette}/{view}')
                            if page.evaluate('document.documentElement.scrollWidth > innerWidth'):
                                failures.append(f'Horizontal overflow at {width}/{style}/{palette}/{view}')
            print('BROWSER: 240 actual theme/screen/viewport combinations checked', flush=True)

            page.set_viewport_size({'width': 1440, 'height': 1100})
            page.locator('.tab[data-view="studio"]').click()
            page.locator('.segment[data-style-opt="calm"]').click()
            page.locator('.palette-button[data-pal-opt="midnight"]').click()
            images_ready()
            for state in STATES:
                page.locator(f'[data-state-opt="{state}"]').click()
                images_ready()
                actual = page.locator('.core-image').first.get_attribute('src')
                if actual != f'../orb/states/state_{state}.png':
                    failures.append('Wrong rendered state source: ' + state)
                if 'CALM / MIDNIGHT' not in page.locator('#coreLook').inner_text():
                    failures.append('State reference theme is not labeled: ' + state)
            page.locator('.palette-button[data-pal-opt="ocean"]').click()
            if page.locator('.core-image').first.get_attribute('src') != '../orb/states/state_speaking.png':
                failures.append('Changing the interface palette changed the fixed state reference')
            page.locator('[data-state-opt="idle"]').click()
            images_ready()

            for style in STYLES:
                page.locator(f'.segment[data-style-opt="{style}"]').click()
                page.locator('[data-core-mode="loop"]').click()
                video = page.locator('#coreVideo')
                if video.get_attribute('src') != '../' + LOOPS[style]:
                    failures.append('Wrong loop source: ' + style)
                video.evaluate('(video) => video.load()')
                page.wait_for_function("document.querySelector('#coreVideo').readyState >= 2", timeout=30000)
                duration = video.evaluate('(video) => video.duration')
                if abs(duration - expected_duration) > .03:
                    failures.append(f'Browser duration mismatch: {style} / {duration}')
                video.evaluate('(video) => video.play()')
                page.wait_for_function("document.querySelector('#coreVideo').currentTime > .15", timeout=15000)
                progress = video.evaluate('(video) => ({time:video.currentTime, frames:video.getVideoPlaybackQuality().totalVideoFrames})')
                video.evaluate('(video) => video.pause()')
                target = duration * .37
                seeked = video.evaluate("""(video, target) => new Promise((resolve, reject) => {
                    const timer = setTimeout(() => reject(new Error('Seeking timed out')), 15000);
                    video.addEventListener('seeked', () => { clearTimeout(timer); resolve(video.currentTime); }, {once:true});
                    video.currentTime = target;
                })""", target)
                if abs(seeked - target) > .1 or progress['frames'] < 1:
                    failures.append('Native video playback / seeking failed: ' + style)
                playback.append({'style': style, 'duration': duration, 'played_time': progress['time'],
                                 'decoded_frames': progress['frames'], 'seek_target': target,
                                 'seek_position': seeked})
                video.evaluate('(video) => video.play()')
                page.locator('[data-state-opt="thinking"]').click()
                if not video.evaluate('(video) => video.paused') or video.is_visible():
                    failures.append('Choosing a state did not pause/hide rendered video: ' + style)
                page.locator('[data-state-opt="idle"]').click()
            print('BROWSER: three real MP4s played, decoded, sought, and paused', flush=True)

            page.locator('.segment[data-style-opt="calm"]').click()
            page.locator('.palette-button[data-pal-opt="midnight"]').click()
            images_ready()
            for kind in ('mark', 'icon', 'background'):
                page.locator(f'[data-asset-open="{kind}"]').click()
                if not page.locator('#assetInspector').evaluate('(dialog) => dialog.open'):
                    failures.append('Asset inspector failed to open: ' + kind)
                if 'px' not in page.locator('#inspectorLabel').inner_text():
                    failures.append('Asset inspector lacks actual dimensions: ' + kind)
                page.keyboard.press('Escape')
            page.locator('#openPicker').click()
            if not page.locator('#picker').evaluate('(dialog) => dialog.open'):
                failures.append('Theme dialog failed to open')
            page.keyboard.press('Escape')
            page.locator('.tab[data-view="studio"]').focus()
            page.keyboard.press('ArrowRight')
            if page.locator('.tab[data-view="harmony"]').get_attribute('aria-selected') != 'true':
                failures.append('Arrow-key tab navigation failed')
            page.locator('#chatInput').fill('<script>neverExecute()</script>')
            page.locator('#composer button').click()
            if '<script>neverExecute()</script>' not in page.locator('#messages').inner_text():
                failures.append('Local chat did not preserve escaped user text')
            page.locator('#chatInput').fill('show the map')
            page.locator('#composer button').click()
            if not page.locator('#v-atlas').is_visible():
                failures.append('Local sample map interaction failed')
            page.locator('[data-filter="restaurant"]').click()
            if page.locator('.pin:visible').count() != 1 or page.locator('#venueName').inner_text() != 'The Pier House':
                failures.append('Map filtering / selection failed')
            page.locator('[data-filter="all"]').click()
            page.locator('.pin[data-venue="saltwater"]').click()
            if page.locator('#venueName').inner_text() != 'Saltwater Bar':
                failures.append('Map pin selection failed')
            page.locator('.tab[data-view="kit"]').click()
            page.locator('.switch').first.click()
            if page.locator('.switch').first.get_attribute('aria-checked') != 'false':
                failures.append('Accessible switch state failed')
            with page.expect_download() as downloaded:
                page.locator('#exportTokens').click()
            token_path = root / 'audit/theme-preview-exported-tokens.json'
            downloaded.value.save_as(token_path)
            exported = json.loads(token_path.read_text())
            if exported['style'] != 'calm' or exported['palette'] != 'midnight':
                failures.append('Token export did not match the selected theme')
            page.locator('.segment[data-style-opt="tech"]').click()
            page.locator('.palette-button[data-pal-opt="ivory"]').click()
            page.reload(wait_until='networkidle')
            if page.locator('body').get_attribute('data-style') != 'tech' or page.locator('body').get_attribute('data-palette') != 'ivory':
                failures.append('Theme persistence failed')
            page.evaluate("document.querySelectorAll('img').forEach(img => img.loading = 'eager')")
            page.locator('.tab[data-view="studio"]').click()
            page.locator('.segment[data-style-opt="calm"]').click()
            for palette in ('midnight', 'ivory'):
                page.locator(f'.palette-button[data-pal-opt="{palette}"]').click()
                images_ready()
                page.evaluate('scrollTo(0,0)')
                path = screenshot_dir / f'theme-preview-{palette}.png'
                page.screenshot(path=str(path), full_page=True)
                screenshots.append(str(path.relative_to(root)))
            if page.locator('.core-image').first.evaluate('(image) => getComputedStyle(image).animationName') != 'none':
                failures.append('Device reduced-motion preference did not stop CSS animation')
            failures.extend('JavaScript: ' + error for error in errors)
            # A canceled superseded PNG load during fast theme switches is an
            # expected browser lifecycle event; other request failures are not.
            network_failures = [entry for entry in requests if entry['failure'] != 'net::ERR_ABORTED']
            failures.extend('Network: ' + json.dumps(entry) for entry in network_failures)
            failures.extend('HTTP: ' + json.dumps(entry) for entry in responses)
            browser.close()
            return {'browser': 'Chromium', 'combinations': len(WIDTHS) * len(STYLES) * len(PALETTES) * len(VIEWS),
                    'widths': list(WIDTHS), 'javascript_errors': errors,
                    'http_errors': responses, 'request_failures': network_failures,
                    'video_playback': playback, 'screenshots': screenshots,
                    'screenshots_provenance': 'Documentary Chromium captures of the HTML page and actual Blender assets; no fixtures.'}, failures
    finally:
        server.shutdown()
        server.server_close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--port', type=int, default=8083)
    parser.add_argument('--browser', help='Optional Chromium executable path')
    parser.add_argument('--expected-duration', type=float, default=8)
    parser.add_argument('--static-only', action='store_true')
    parser.add_argument('--wait-assets', type=float, default=0,
                        help='Seconds to wait for actual missing assets before auditing')
    args = parser.parse_args()
    root = args.root.resolve()
    report_path = root / 'audit/theme-preview-qa.json'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report = {'checked_at_utc': datetime.now(timezone.utc).isoformat(),
              'fixture_policy': 'Actual package files only. No replacement assets or fake responses.',
              'expected_assets': len(expected_assets()), 'expected_video_duration': args.expected_duration,
              'status': 'waiting_for_assets', 'failures': []}
    deadline = time.monotonic() + args.wait_assets
    missing = inventory(root)
    while missing and time.monotonic() < deadline:
        print(f'WAITING: {len(missing)} real assets remain missing', flush=True)
        time.sleep(min(15, max(0, deadline - time.monotonic())))
        missing = inventory(root)
    if missing:
        report['missing_assets'] = missing
        report_path.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'status': report['status'], 'missing_assets': missing}, indent=2))
        return 2
    try:
        report['png_assets'], png_failures = png_checks(root)
        report['video_assets'], video_failures = video_checks(root, args.expected_duration)
        report['failures'].extend(png_failures + video_failures)
        if not args.static_only and not report['failures']:
            report['browser'], browser_failures = browser_checks(root, args.port, args.browser,
                                                               args.expected_duration)
            report['failures'].extend(browser_failures)
        report['status'] = ('failed' if report['failures'] else
                            'static_checks_passed' if args.static_only else 'passed')
    except Exception as error:
        report['status'] = 'failed'
        report['failures'].append(f'{type(error).__name__}: {error}')
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'png_assets': len(report.get('png_assets', [])),
                      'video_assets': len(report.get('video_assets', [])),
                      'browser_combinations': report.get('browser', {}).get('combinations', 0),
                      'failures': report['failures'], 'report': str(report_path)}, indent=2))
    return 1 if report['failures'] else 0


if __name__ == '__main__':
    sys.exit(main())
