"""Read-only verification of final Harmony Blender masters; no renders or saves."""
import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
ORIGINAL=json.loads((ROOT/'audit/original-scene.json').read_text())
EXPECTED_ORIGINAL=set(ORIGINAL['objects'])
EXPECTED_ORB_ADDED={'NucleusSoftbox','TechWire','TechTicks','IvoryShadow',
                    'AtmosphereDepth','AtmosphereFilaments','AtmosphereKnots'}

def close(a,b,eps=1e-5):return abs(a-b)<eps

def fcurves(ob):
    action=ob.animation_data.action
    out=[]
    for layer in action.layers:
        for strip in layer.strips:
            for bag in strip.channelbags:out.extend(bag.fcurves)
    return out

def check(path,animation):
    bpy.ops.wm.open_mainfile(filepath=str(path),use_scripts=False)
    s=bpy.data.scenes['Orb'];checks={}
    checks['four_expected_scenes']=set(bpy.data.scenes.keys())=={'Orb','Mark','Background','Pins'}
    checks['orb_49_expected_objects']=set(s.objects.keys())==EXPECTED_ORIGINAL|EXPECTED_ORB_ADDED
    checks['original_42_names_retained']=EXPECTED_ORIGINAL<=set(s.objects.keys())
    checks['all_orb_meshes_have_materials']=all(o.data.materials and all(m is not None for m in o.data.materials)
                                               for o in s.objects if o.type=='MESH')
    checks['new_orb_objects_in_designer']=all(any(c.name=='Designer' for c in bpy.data.objects[n].users_collection)
                                             for n in EXPECTED_ORB_ADDED)
    checks['no_accidental_object_name_suffixes']=not any(o.name.endswith('.001') for o in s.objects)
    checks['eevee']=s.render.engine=='BLENDER_EEVEE'
    checks['cpu_compositor']=s.render.compositor_device=='CPU'
    checks['render_resolution']=s.render.resolution_x==s.render.resolution_y==1024 and s.render.resolution_percentage==100
    checks['png_rgba8_transparent']=(s.render.image_settings.file_format=='PNG' and s.render.image_settings.color_mode=='RGBA'
                                  and s.render.image_settings.color_depth=='8' and s.render.film_transparent)
    checks['standard_color_management']=(s.view_settings.view_transform=='Standard' and s.view_settings.look=='None'
                                      and close(s.view_settings.exposure,0) and close(s.view_settings.gamma,1))
    checks['four_seconds_30fps']=s.frame_start==1 and s.frame_end==120 and s.render.fps==30
    checks['orthographic_8_degree_camera']=(s.camera.data.type=='ORTHO' and close(s.camera.data.ortho_scale,7.2)
                                         and close(math.degrees(s.camera.rotation_euler.x),82))
    checks['preset_samples']=s.eevee.taa_render_samples==(8 if animation else 64)
    checks['beauty_volume_settings_retained']=s.eevee.volumetric_samples==96 and s.eevee.volumetric_tile_size=='2'
    checks['atmosphere_visibility_matches_preset']=(all(bpy.data.objects[n].hide_render==animation for n in ['Nebula','Plasma'])
        and all(bpy.data.objects[n].hide_render!=(animation) for n in ['AtmosphereDepth','AtmosphereFilaments','AtmosphereKnots']))
    checks['actual_midnight_palette']=json.loads(s['HarmonyPaletteTokens'])['accent']=='#D9B25F'
    mats=bpy.data.materials
    checks['actual_midnight_nucleus_color']=all(close(a,b) for a,b in zip(mats['M_Proton'].node_tree.nodes['BSDF'].inputs['Emission Color'].default_value,
                                                                      (.6938717365,.4452011883,.1144353747,1)))
    checks['no_temporary_basis_saved']=not any('basis' in n.name.lower() for n in s.compositing_node_group.nodes)
    checks['stars_380_assigned']=len(bpy.data.objects['StarDust'].data.vertices)==380*12 and bpy.data.objects['StarDust'].data.materials[0].name=='M_Stars'
    ticks=bpy.data.objects['TechTicks'];checks['24_tech_ticks']=len(ticks.data.polygons)==24 and len(ticks.data.vertices)==96 and ticks.parent.name=='SpinA'
    rad=[math.hypot(v.co.x,v.co.y) for v in ticks.data.vertices]
    checks['tick_radial_range']=close(min(rad),math.hypot(2.265,.003)) and close(max(rad),math.hypot(2.335,.003))
    checks['13_particles_radius_145']=len([o for o in s.objects if o.name.startswith('Nucleon')])==13 and all(close(o.scale.x*.13,.145) for o in s.objects if o.name.startswith('Nucleon'))
    checks['nucleus_center_radius_285']=all(close(o.location.length,.285) for o in s.objects if o.name.startswith('Nucleon') and o.name!='Nucleon00')
    phase_mats=[m for m in mats if m.node_tree and m.node_tree.nodes.get('LoopT')]
    checks['eight_unique_valid_loop_drivers']=len(phase_mats)==8 and all(len(m.node_tree.animation_data.drivers)==1
        and m.node_tree.animation_data.drivers[0].is_valid and m.node_tree.animation_data.drivers[0].driver.expression=='(frame-1)/120' for m in phase_mats)
    checks['rotation_keys_linear_at_1_and_121']=all([k.co.x for k in fc.keyframe_points]==[1,121]
        and all(k.interpolation=='LINEAR' for k in fc.keyframe_points) for n in ['Nucleus','SpinA','SpinB','SpinC'] for fc in fcurves(bpy.data.objects[n]))
    expected_degrees={'Nucleus':360,'SpinA':360,'SpinB':-360,'SpinC':120}
    checks['rotation_symmetry_degrees']=all(close(math.degrees(fcurves(bpy.data.objects[n])[0].evaluate(121)-fcurves(bpy.data.objects[n])[0].evaluate(1)),d,1e-4)
                                         for n,d in expected_degrees.items())
    points={};phases={};scales={}
    for f in [1,121]:
        s.frame_set(f)
        points[f]={prefix:[o.matrix_world.translation.copy() for o in s.objects if o.name.startswith(prefix)]
                   for prefix in ['Nucleon','ElectronA','ElectronB','ElectronC']}
        phases[f]={m.name:m.node_tree.nodes['LoopT'].outputs[0].default_value for m in phase_mats}
        scales[f]=tuple(bpy.data.objects['Core'].scale)
    maximum=0
    for prefix in points[1]:
        for a in points[1][prefix]:maximum=max(maximum,min((a-b).length for b in points[121][prefix]))
    checks['endpoint_particle_positions_close']=maximum<1e-5
    checks['endpoint_breathing_equal']=scales[1]==scales[121]
    active_materials={m.name for o in s.objects if o.type=='MESH' and not o.hide_render for m in o.data.materials}
    # Blender does not necessarily evaluate drivers on hidden, unused material
    # trees. Their driver expressions are checked above; active layers evaluate.
    checks['active_endpoint_driver_phase_0_and_1']=all(close(x,0) for n,x in phases[1].items() if n in active_materials) and all(close(x,1) for n,x in phases[121].items() if n in active_materials)
    checks['no_unpacked_file_images']=not any(i.source=='FILE' and i.packed_file is None for i in bpy.data.images)
    expected_scripts={p.name:p.read_text() for p in (ROOT/'source').glob('*.py')}
    scripts={t.name:t.as_string() for t in bpy.data.texts}
    missing=[n for n in expected_scripts if n not in scripts]
    stale=[n for n in expected_scripts if n in scripts and scripts[n]!=expected_scripts[n]]
    checks['embedded_current_scripts']=not missing and not stale
    checks['embedded_current_readme']=scripts.get('START HERE')==(ROOT/'README.md').read_text()
    checks['portable_orb_output_path']=s.render.filepath.startswith('//') and 'state_' not in s.render.filepath
    return {'path':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'blender':bpy.app.version_string,'checks':checks,'passed':all(checks.values()),
            'scenes':{x.name:len(x.objects) for x in bpy.data.scenes},'materials':len(mats),
            'endpoint_max_position_error':maximum,'missing_embedded_scripts':missing,'stale_embedded_scripts':stale,
            'orb_output_path':s.render.filepath,'no_render_performed':True}

reports=[check(ROOT/'source/harmony_assets.blend',False),check(ROOT/'source/harmony_animation.blend',True)]
report={'masters':reports,'passed':all(r['passed'] for r in reports),'scope':'Read-only scene and mathematical verification; PNG/video QA and hardware performance are separate'}
(ROOT/'audit/final-scene-checks.json').write_text(json.dumps(report,indent=2))
for r in reports:print(r['path'],'failed_checks',[n for n,v in r['checks'].items() if not v])
