import bpy, json, math, os, pathlib, sys
from mathutils import Vector, Euler, Matrix, Quaternion, Color

SOURCE = os.environ.get('HARMONY_AUDIT_SOURCE', '/workspace/harmony-handoff/source/harmony_assets.blend')
OUTPUT = os.environ.get('HARMONY_AUDIT_OUTPUT', '/workspace/harmony-polished/audit/original-scene.json')
bpy.ops.wm.open_mainfile(filepath=SOURCE, use_scripts=False)

def plain(v):
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, (Vector, Euler, Quaternion, Color)):
        return list(v)
    if isinstance(v, Matrix):
        return [list(row) for row in v]
    if isinstance(v, bpy.types.ID):
        return {'id':v.name, 'type':v.bl_rna.identifier}
    try:
        if isinstance(v, (bpy.types.bpy_prop_array, tuple, list)):
            return [plain(x) for x in v]
    except Exception:
        pass
    return str(v)

def props(x):
    d={}
    if not x:
        return d
    for p in x.bl_rna.properties:
        if p.identifier=='rna_type' or p.type=='COLLECTION':
            continue
        try:
            v=getattr(x,p.identifier)
            if p.type=='POINTER':
                if v is not None and isinstance(v, bpy.types.ID):
                    d[p.identifier]=plain(v)
            else:
                d[p.identifier]=plain(v)
        except Exception as e:
            d[p.identifier]={'error':str(e)}
    try:
        d['_custom']={str(k):plain(x[k]) for k in x.keys()}
    except Exception:
        pass
    return d

def fcurve(fc):
    r=props(fc)
    r['keyframes']=[dict(props(kp), co=list(kp.co), handle_left=list(kp.handle_left), handle_right=list(kp.handle_right)) for kp in fc.keyframe_points]
    r['modifiers']=[props(m) for m in fc.modifiers]
    r['samples']={str(f):fc.evaluate(f) for f in [1,30,60,61,90,119,120,121]}
    if fc.driver:
        d=fc.driver
        r['driver']=dict(props(d),variables=[dict(props(v),targets=[props(t) for t in v.targets]) for v in d.variables])
    return r

def action_fcurves(action):
    try:
        return list(action.fcurves)
    except Exception:
        out=[]
        for layer in action.layers:
            for strip in layer.strips:
                if hasattr(strip,'channelbags'):
                    for bag in strip.channelbags:
                        out.extend(bag.fcurves)
        return out

def animation(x):
    ad=x.animation_data if hasattr(x,'animation_data') else None
    if not ad:
        return None
    r=props(ad)
    r['drivers']=[fcurve(f) for f in ad.drivers]
    if ad.action:
        r['action']=dict(props(ad.action),fcurves=[fcurve(f) for f in action_fcurves(ad.action)])
    return r

def socket(s):
    p=props(s)
    if hasattr(s,'default_value'):
        p['default_value']=plain(s.default_value)
    return p

def node_tree(nt):
    if not nt:
        return None
    r=dict(props(nt), nodes={},links=[])
    r['animation']=animation(nt)
    for n in nt.nodes:
        d=props(n)
        d['inputs']=[socket(s) for s in n.inputs]
        d['outputs']=[socket(s) for s in n.outputs]
        if hasattr(n,'color_ramp'):
            d['color_ramp']=dict(props(n.color_ramp),elements=[props(e) for e in n.color_ramp.elements])
        if hasattr(n,'mapping'):
            d['mapping']=dict(props(n.mapping),curves=[dict(props(c),points=[props(p) for p in c.points]) for c in n.mapping.curves])
        r['nodes'][n.name]=d
    for l in nt.links:
        r['links'].append({'from_node':l.from_node.name,'from_socket':l.from_socket.name,'from_identifier':l.from_socket.identifier,'to_node':l.to_node.name,'to_socket':l.to_socket.name,'to_identifier':l.to_socket.identifier})
    if hasattr(nt,'interface'):
        r['interface']=[props(i) for i in nt.interface.items_tree]
    return r

result={'blender_version':bpy.app.version_string,'file':SOURCE,'collections':{},'scenes':{},'objects':{},'materials':{},'worlds':{},'node_groups':{}}
for c in bpy.data.collections:
    result['collections'][c.name]={'properties':props(c),'objects':[o.name for o in c.objects],'children':[cc.name for cc in c.children]}
for sc in bpy.data.scenes:
    d={'properties':props(sc),'object_names':[o.name for o in sc.objects],'render':props(sc.render),'image_settings':props(sc.render.image_settings),'eevee':props(sc.eevee),'view_settings':props(sc.view_settings),'display_settings':props(sc.display_settings),'sequencer_colorspace_settings':props(sc.sequencer_colorspace_settings),'animation':animation(sc),'view_layers':[]}
    for vl in sc.view_layers:
        d['view_layers'].append({'properties':props(vl),'eevee':props(vl.eevee) if hasattr(vl,'eevee') else None})
    if sc.compositing_node_group:
        d['compositor']=node_tree(sc.compositing_node_group)
    result['scenes'][sc.name]=d
for o in bpy.data.objects:
    d={'properties':props(o),'matrix_world':plain(o.matrix_world),'matrix_local':plain(o.matrix_local),'matrix_parent_inverse':plain(o.matrix_parent_inverse),'bound_box':plain([tuple(b) for b in o.bound_box]),'collections':[c.name for c in o.users_collection],'animation':animation(o),'material_slots':[{'name':s.name,'material':s.material.name if s.material else None,'link':s.link} for s in o.material_slots],'constraints':[props(c) for c in o.constraints],'modifiers':[props(m) for m in o.modifiers]}
    if o.data:
        d['data']=props(o.data)
        d['data_animation']=animation(o.data)
        if hasattr(o.data,'node_tree') and o.data.node_tree:
            d['data_nodes']=node_tree(o.data.node_tree)
        if isinstance(o.data,bpy.types.Camera):
            d['depth_of_field']=props(o.data.dof)
        if isinstance(o.data,bpy.types.Mesh):
            d['mesh_statistics']={'vertices':len(o.data.vertices),'edges':len(o.data.edges),'polygons':len(o.data.polygons),'loops':len(o.data.loops),'uv_layers':[props(l) for l in o.data.uv_layers],'attributes':[props(a) for a in o.data.attributes]}
            if o.data.vertices:
                d['local_extents']={axis:[min(v.co[i] for v in o.data.vertices),max(v.co[i] for v in o.data.vertices)] for i,axis in enumerate('xyz')}
    result['objects'][o.name]=d
for m in bpy.data.materials:
    result['materials'][m.name]={'properties':props(m),'animation':animation(m),'nodes':node_tree(m.node_tree)}
for w in bpy.data.worlds:
    result['worlds'][w.name]={'properties':props(w),'animation':animation(w),'nodes':node_tree(w.node_tree)}
for nt in bpy.data.node_groups:
    result['node_groups'][nt.name]=node_tree(nt)

# Evaluate transforms and driven socket values independently of render.
result['evaluated_frames']={}
sc=bpy.data.scenes['Orb']
for f in [1,30,60,61,90,119,120,121]:
    sc.frame_set(f)
    dg=bpy.context.evaluated_depsgraph_get()
    result['evaluated_frames'][str(f)]={'objects':{o.name:{'location':plain(o.location),'rotation_euler':plain(o.rotation_euler),'scale':plain(o.scale),'matrix_world':plain(o.matrix_world)} for o in sc.objects},'loop_nodes':{m.name:plain(m.node_tree.nodes['LoopT'].outputs[0].default_value) for m in bpy.data.materials if m.use_nodes and m.node_tree.nodes.get('LoopT')}}
pathlib.Path(OUTPUT).write_text(json.dumps(result,indent=2))
print('WROTE',OUTPUT,os.path.getsize(OUTPUT),'bytes')
print('Scenes',list(result['scenes']),'objects',len(result['objects']),'materials',list(result['materials']))
