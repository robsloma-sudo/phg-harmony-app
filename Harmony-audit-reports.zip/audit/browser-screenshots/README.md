# Browser review captures

These PNGs are documentary Chromium screenshots of the offline HTML theme preview, including the actual Blender-rendered assets. They are not new artwork or Blender render outputs.
