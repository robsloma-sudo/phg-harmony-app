import bpy, runpy, json, math
bpy.ops.wm.open_mainfile(filepath='/workspace/harmony-handoff/source/harmony_assets.blend',use_scripts=False)
def plain(v):
 try:return list(v)
 except TypeError:return v

def snap():
 d={}
 for o in bpy.data.objects:
  for x in ['location','rotation_euler','scale']:d[f'{o.name}.{x}']=list(getattr(o,x))
  if o.type=='LIGHT':
   for x in ['energy','color','size' if o.data.type=='AREA' else 'shadow_soft_size']:d[f'{o.name}.data.{x}']=plain(getattr(o.data,x))
 for m in bpy.data.materials:
  d[f'{m.name}.surface_render_method']=m.surface_render_method
  for n in m.node_tree.nodes:
   d[f'{m.name}.{n.name}.type']=n.bl_idname
   for x in ['operation','interpolation_type','noise_dimensions','data_type','gradient_type','blend_type']:
    if hasattr(n,x):d[f'{m.name}.{n.name}.{x}']=getattr(n,x)
   for i,s in enumerate(n.inputs):
    if hasattr(s,'default_value'):d[f'{m.name}.{n.name}.inputs[{i}].{s.name}']=plain(s.default_value)
   for i,s in enumerate(n.outputs):
    if hasattr(s,'default_value'):d[f'{m.name}.{n.name}.outputs[{i}].{s.name}']=plain(s.default_value)
   if hasattr(n,'color_ramp'):
    d[f'{m.name}.{n.name}.interpolation']=n.color_ramp.interpolation
    for i,e in enumerate(n.color_ramp.elements):
     d[f'{m.name}.{n.name}.ramp[{i}].position']=e.position
     d[f'{m.name}.{n.name}.ramp[{i}].color']=list(e.color)
 return d
bpy.context.scene.frame_set(1)
saved=snap()
bpy.ops.wm.read_factory_settings(use_empty=True)
b=runpy.run_path('/workspace/harmony-handoff/source/harmony_core_build.py',run_name='audit')
s=bpy.context.scene;s.name='Orb'
b['setup_render'](s,1024,1024,True,(1,120));b['build_core'](s);b['setup_bloom'](s)
s.frame_set(1)
built=snap()
def same(a,b):
 if isinstance(a,(int,float)) and isinstance(b,(int,float)):return abs(a-b)<1e-6
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):return all(same(x,y) for x,y in zip(a,b))
 return a==b
changes=[]
for k in sorted(set(saved)|set(built)):
 a=saved.get(k);b=built.get(k)
 if not same(a,b):changes.append({'property':k,'saved_blend':a,'build_script':b})
json.dump(changes,open('/workspace/harmony-polished/audit/script-vs-source.json','w'),indent=2)
for c in changes:
 if c['saved_blend'] is not None and c['build_script'] is not None:print(c)
